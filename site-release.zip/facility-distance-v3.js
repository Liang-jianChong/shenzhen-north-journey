(function(global){
 'use strict';
 const TYPE={vertical_connector_candidate:['楼扶梯候选','候','#785f9b'],escalator:['扶梯','扶','#447b9e'],stair:['楼梯','梯','#80698f'],elevator:['直梯','电','#438577'],rail_exit_gate:['国铁出站闸机','闸','#bd7b42'],metro_security:['地铁安检','检','#ae675d'],metro_fare_gate:['地铁闸机','闸','#a78a45'],rail_security:['国铁安检','检','#ae675d'],rail_exit:['出站口','出','#617d88'],service_requirement:['服务环节','服','#6e7c86'],accessible_toilet:['无障碍卫生间','卫','#548d88'],corridor_interface:['连廊接口','廊','#617d88'],parking:['停车场','停','#617d88'],boarding_area:['上客区','乘','#617d88'],special_passage:['专用通道','通','#617d88'],toilet:['卫生间','卫','#548d88']};
 const STATUS={model_geometry_candidate:'模型几何候选',source_label_unverified:'文件标签待实地核对',hypothesized:'推定位置',geometry_conflict:'位置资料存在冲突',unlocated:'待定位',official_area_only:'官方仅确认区域'};
 const fmt=n=>Number.isFinite(n)?Math.round(n).toLocaleString('zh-CN'):'—';
 const precise=n=>Number.isFinite(n)?Number(n.toFixed(1)).toLocaleString('zh-CN'):'—';
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const safeUrl=u=>/^https?:\/\//i.test(u||'')?u:null;
 const posValid=p=>Array.isArray(p)&&p.length===3&&p.every(Number.isFinite);
 const methodLabel=m=>({FBX_PLATFORM_SCENARIO:'FBX 台面 · 路径推定',FBX_MODEL_CONNECTOR_CHORD:'FBX 楼扶梯端点弦长',CSV_SCALE_ASSUMPTION:'CSV 初始尺度假设',UNREGISTERED_CORRIDOR_SCENARIO:'未配准连廊 · 情景尺度',SUPPLEMENTAL_GEOMETRY_SCENARIO:'补画几何 · 情景尺度',COLOCATED_SEMANTIC_ZERO:'同一边界 · 不增加移动',alight_model_axis:'下车位置沿台模型轴线'}[m]||String(m||'待估计').replace(/_/g,' '));
 function adjustedEdges(snapshot,data){
  const map=new Map((data.edges||[]).map(e=>[e.edge_id,e]));
  return (snapshot.edges||[]).map((edge,i)=>{
   const source=map.get(edge.id);const row=source?{...source}:{edge_id:edge.id,estimated_length_m:null,lower_m:null,upper_m:null,method:'unresolved',measured_length_m:null};
   row.from_label=snapshot.nodes[i]?.label||edge.from;row.to_label=snapshot.nodes[i+1]?.label||edge.to;row.sequence=i+1;
   if(i===0&&source&&Number(snapshot.scenario_parameters.alight_z)!==0){
    const target=snapshot.nodes[1]?.position?.[2],z=Number(snapshot.scenario_parameters.alight_z);
    if(Number.isFinite(target)&&Number.isFinite(z)){
     const adjustment=data.chains?.find(c=>c.chain_id===snapshot.scenario_id)?.alight_adjustment||{};
     const meters=adjustment.metres_per_z_unit??1,lo=adjustment.lower_multiplier??.9,hi=adjustment.upper_multiplier??1.1;
     row.estimated_length_m=Math.abs(target-z)*meters;row.horizontal_m=row.estimated_length_m;row.lower_m=row.estimated_length_m*lo;row.upper_m=row.estimated_length_m*hi;
     row.horizontal_lower_m=row.lower_m;row.horizontal_upper_m=row.upper_m;
     row.method='alight_model_axis';row.alight_z=z;row.recomputed_for_alight_position=true;
    }
   }
   row.measured_length_m=null;return row;
  });
 }
 function totals(rows){const valid=rows.filter(e=>Number.isFinite(e.estimated_length_m));const sum=k=>valid.reduce((s,e)=>s+(Number.isFinite(e[k])?e[k]:0),0);return{estimated_length_m:sum('estimated_length_m'),lower_m:sum('lower_m'),upper_m:sum('upper_m'),estimated_covered_edges:valid.length,total_edges:rows.length,unresolved_edge_ids:rows.filter(e=>!Number.isFinite(e.estimated_length_m)).map(e=>e.edge_id),measured_length_m:null,range_kind:'sensitivity_not_confidence'};}
 function related(f,snapshot){const nodes=new Set(snapshot.nodes.map(n=>n.id)),edges=new Set(snapshot.edges.map(e=>e.id)),objects=new Set(snapshot.nodes.flatMap(n=>[n.facility_id,n.object_id,n.source_object_id]).filter(Boolean));return(f.associated_chain_ids||[]).includes(snapshot.scenario_id)||(f.associated_node_ids||[]).some(id=>nodes.has(id))||(f.associated_edge_ids||[]).some(id=>edges.has(id))||(f.source_object_ids||[]).some(id=>objects.has(id));}
 function chainIssues(snapshot,calibration,registry){
  const chain=calibration.chains?.find(c=>c.chain_id===snapshot.scenario_id),set=(registry.facilities||[]).filter(f=>related(f,snapshot)),issues=[];
  const exits=set.filter(f=>f.type==='rail_exit'&&chain?.exit_id&&f.facility_id!==chain.exit_id);
  if(exits.length)issues.push('源 CSV 出口标记存在冲突（'+[...new Set([chain.exit_id,...exits.map(f=>f.facility_id)])].map(s=>s.replace(/^Exit/,'')).sort().join('/')+'），未完成现场核对；保留原始几何，不能据此确认可通行。');
  if(chain?.conflict)issues.push('本链含源数据冲突标记，距离仅用于情景测试，需先核对对应分段。');
  const conflicts=set.filter(f=>f.status==='geometry_conflict');if(conflicts.length)issues.push('设施位置存在冲突：'+conflicts.map(f=>f.facility_id).join('、')+'。已保留证据并移入待定位清单，不绘制推测中心点。');
  return issues;
 }
 function create(api){
  const root=api.root,$=id=>root.querySelector('#s3-'+id),data=global.stationResearchData||{},calibration=data.distances||{},registry=data.facilities||{},allFacilities=registry.facilities||[],facilities=allFacilities.filter(f=>f.type!=='service_requirement');
  let snapshot=null,rows=[],selected=null,hits=[],visibleFacilities=[],lastListKey='';
  const evidenceLabels={model_geometry:'模型几何',source_label:'源文件标签',hypothesis:'情景推定',official_area:'官方区域说明',unlocated:'无定位证据'};
  const evidenceName=f=>evidenceLabels[f.evidence_level]||STATUS[f.status]||f.evidence_level||'待核对';
  const labelType=f=>f.type_label||TYPE[f.type]?.[0]||f.type;
  const floorName=id=>api.D.floors.find(f=>f.id===id)?.name||id||'楼层待核';
  const addOption=(el,v,t)=>{const o=document.createElement('option');o.value=v;o.textContent=t;el.append(o);};
  [...new Set(facilities.map(f=>f.type))].sort().forEach(t=>addOption($('facility-type'),t,TYPE[t]?.[0]||facilities.find(f=>f.type===t).type_label||t));
  [...new Set(facilities.map(f=>f.evidence_level).filter(Boolean))].sort().forEach(t=>addOption($('facility-evidence'),t,evidenceName(facilities.find(f=>f.evidence_level===t))));
  function baseFacilities(){return facilities.filter(f=>($('facility-scope').value==='all'||snapshot&&related(f,snapshot))&&($('facility-type').value==='all'||f.type===$('facility-type').value)&&($('facility-evidence').value==='all'||f.evidence_level===$('facility-evidence').value));}
  function allowed(f){const floor=$('floor').value,scene=$('scene').value,levels=[f.floor,f.to_floor,...f.floors||[]].filter(Boolean);if(floor!=='all'&&!levels.includes(floor))return false;if(scene==='rail'&&!levels.some(x=>['NP','NC'].includes(x)))return false;if(scene==='transfer'&&f.type==='vertical_connector_candidate')return false;return true;}
  function choose(id){selected=facilities.find(f=>f.facility_id===id)||null;renderSelected();renderList(true);api.redraw();}
  function renderSelected(){
   const box=$('facility-detail');
   if(!selected){box.innerHTML='<div class="s3-empty-detail">点击地图标记或设施清单，查看位置、关联路线和证据。</div>';return;}
   const f=selected,p=f.display_position,source=(f.source||[]),status=STATUS[f.status]||f.status;
   box.innerHTML='<div class="s3-facility-detail-heading"><div><span class="s3-data-kicker">设施记录 · '+escape(f.facility_id)+'</span><h3>'+escape(f.name||labelType(f))+'</h3></div><span class="s3-evidence-pill">'+escape(status)+'</span></div><div class="s3-detail-facts"><span>类型 <strong>'+escape(labelType(f))+'</strong></span><span>楼层 <strong>'+escape((f.floors?.length?f.floors:[f.floor]).filter(Boolean).map(floorName).join(' ↔ ')||'待核对')+'</strong></span><span>显示坐标 <strong>'+escape(posValid(p)?p.map(v=>v.toFixed(2)).join(', '):'尚未定位 · 不在地图放点')+'</strong></span></div><p class="s3-detail-note">'+escape(f.uncertainty||'该记录用于位置核对，尚非现场验收的设备清单。')+'</p><details class="s3-source-details"><summary>查看来源与定位依据（'+source.length+'）</summary><ul>'+source.map(s=>'<li>'+ (safeUrl(s.url)?'<a target="_blank" rel="noopener noreferrer" href="'+escape(s.url)+'">'+escape(s.title||s.id)+'</a>':escape(s.title||s.id))+(s.locator?' · '+escape(s.locator):'')+(s.claim?'<div>'+escape(s.claim)+'</div>':'')+'</li>').join('')+'</ul><p class="text-small">显示坐标沿用当前地图。设备存在、类型、位置和运行状态为不同核验项目；一组上下端点不代表两台设备。</p></details>';
  }
  function renderList(force=false){
   const set=baseFacilities(),allLocated=set.filter(f=>posValid(f.display_position)),located=allLocated.filter(allowed),unlocated=set.filter(f=>!posValid(f.display_position)&&(allowed(f)||![f.floor,f.to_floor,...f.floors||[]].some(Boolean)));
   visibleFacilities=located;
   if(selected&&![...located,...unlocated].some(f=>f.facility_id===selected.facility_id)){selected=null;renderSelected();}
   const key=[snapshot?.scenario_id,$('facility-scope').value,$('facility-type').value,$('facility-evidence').value,$('floor').value,$('scene').value,selected?.facility_id].join('|');
   $('facility-count').textContent='当前视图 '+visibleFacilities.length+' 条定位记录 · 待定位 '+unlocated.length+' 条'+(allLocated.length>located.length?' · '+(allLocated.length-located.length)+' 条位于视图外':'');
   $('facility-list-title').textContent='当前视图清单（定位 '+located.length+' / 待定位 '+unlocated.length+'）';
   if(!force&&key===lastListKey)return;lastListKey=key;
   const body=$('facility-list');body.replaceChildren();
   if(!located.length&&!unlocated.length){body.innerHTML='<p class="text-small">当前筛选没有设施记录，可切换“全站设施”或“全部楼层”查看。</p>';return;}
   for(const [title,list]of [['有定位依据',located],['未定位 · 仅列表展示',unlocated]]){
    if(!list.length)continue;const h=document.createElement('h4');h.textContent=title;body.append(h);
    for(const f of list){const b=document.createElement('button');b.type='button';b.className='s3-facility-list-item';b.setAttribute('aria-pressed',String(f.facility_id===selected?.facility_id));b.innerHTML='<span class="s3-device-glyph" style="--device-color:'+(TYPE[f.type]?.[2]||'#657b86')+'">'+escape(TYPE[f.type]?.[1]||'设')+'</span><span><strong>'+escape(f.name||f.facility_id)+'</strong><small>'+escape(f.facility_id)+' · '+escape(evidenceName(f))+'</small></span>';b.onclick=()=>choose(f.facility_id);body.append(b);}
   }
  }
  function renderDistance(){
   if(!snapshot)return;rows=adjustedEdges(snapshot,calibration);const total=totals(rows),ready=total.estimated_covered_edges>0;
   $('distance-number').textContent=ready?fmt(total.estimated_length_m):'—';
   $('distance-range').textContent=ready?fmt(total.lower_m)+'–'+fmt(total.upper_m)+' m':'待载入估计数据';
   $('distance-coverage').textContent=ready?('已估计 '+total.estimated_covered_edges+'/'+total.total_edges+' 段'+(total.unresolved_edge_ids.length?' · 总值为已覆盖部分':'')):'距离数据尚未载入';
   const issues=chainIssues(snapshot,calibration,registry);$('research-conflicts').hidden=!issues.length;$('research-conflicts').textContent=issues.join(' ');
   $('distance-table-title').textContent='逐段距离估计 · '+snapshot.scenario_id+'（'+rows.length+' 段）';
   $('distance-table-body').replaceChildren();
   rows.forEach((r,i)=>{const tr=document.createElement('tr');tr.innerHTML='<td>'+String(i+1).padStart(2,'0')+'</td><td><button type="button" class="s3-edge-select">'+escape(r.from_label)+' → '+escape(r.to_label)+'</button><small>'+escape(r.edge_id)+'</small></td><td class="s3-numeric">'+precise(r.estimated_length_m)+'</td><td class="s3-numeric">'+precise(r.lower_m)+'–'+precise(r.upper_m)+'</td><td>'+escape(methodLabel(r.method))+(r.is_semantic?'<small>语义衔接，不增加物理移动</small>':'')+'</td>';tr.querySelector('button').onclick=()=>api.selectNode(i+1);$('distance-table-body').append(tr);});
   const groups=[['国铁前段',rows.slice(0,7)],['同层接续',rows.slice(7,8)],['城市接驳',rows.slice(8)]];
   $('distance-segments').innerHTML=groups.map(([name,rs])=>'<div><span>'+name+'</span><strong>'+fmt(totals(rs).estimated_length_m)+' <small>m</small></strong></div>').join('');
  }
  function update(current){snapshot=current;renderDistance();if(selected&&!baseFacilities().some(f=>f.facility_id===selected.facility_id))selected=null;renderSelected();renderList(true);}
  function drawSymbol(ctx,x,y,f,on){
   const type=TYPE[f.type]||['设施','设','#657b86'],r=on?10:8;
   ctx.save();ctx.fillStyle='#fff';ctx.strokeStyle=type[2];ctx.lineWidth=on?2.5:1.6;if(['hypothesized','geometry_conflict'].includes(f.status))ctx.setLineDash([3,2]);ctx.beginPath();ctx.roundRect(x-r,y-r,r*2,r*2,3);ctx.fill();ctx.stroke();ctx.setLineDash([]);ctx.fillStyle=type[2];ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=(on?'bold ':'')+'10px "Microsoft YaHei",sans-serif';ctx.fillText(type[1],x,y+.5);if(on){ctx.globalAlpha=.25;ctx.beginPath();ctx.arc(x,y,15,0,Math.PI*2);ctx.stroke();}ctx.restore();
  }
  function render({ctx,screen,path,label}){
   renderList();hits=[];if(!$('facility-visible').checked)return;
   const positions=[];
   for(const f of visibleFacilities.slice().sort((a,b)=>(a.facility_id===selected?.facility_id)-(b.facility_id===selected?.facility_id))){
    const anchor=screen(f.display_position),on=f.facility_id===selected?.facility_id;let x=anchor[0],y=anchor[1];
    const neighbors=positions.filter(p=>Math.hypot(p[0]-x,p[1]-y)<17).length;if(neighbors){const offset=(neighbors%2?1:-1)*Math.ceil(neighbors/2)*12;x+=offset;y-=Math.min(neighbors*4,12);ctx.save();ctx.strokeStyle=TYPE[f.type]?.[2]||'#657b86';ctx.globalAlpha=.5;ctx.beginPath();ctx.moveTo(anchor[0],anchor[1]);ctx.lineTo(x,y);ctx.stroke();ctx.restore();}
    positions.push([x,y]);
    if(on&&f.points?.length>1&&f.points.every(posValid))path(f.points,TYPE[f.type]?.[2]||'#657b86',3,['hypothesized','geometry_conflict'].includes(f.status)?[4,3]:[],.8);
    drawSymbol(ctx,x,y,f,on);hits.push({id:f.facility_id,p:[x,y]});
    if(on)label(f.facility_id+' · '+labelType(f),f.display_position,true,-31);
   }
  }
  function hit(x,y){const item=hits.map(h=>({...h,d:Math.hypot(h.p[0]-x,h.p[1]-y)})).sort((a,b)=>a.d-b.d)[0];if(item?.d<=13){choose(item.id);return true;}return false;}
  for(const id of ['facility-scope','facility-type','facility-evidence'])$(id).addEventListener('change',()=>{if(selected&&!baseFacilities().some(f=>f.facility_id===selected.facility_id))selected=null;renderSelected();renderList(true);api.redraw();});
  for(const id of ['facility-visible','route-visible'])$(id).addEventListener('change',()=>api.redraw());
  return{update,render,hit,showRoutes:()=>$('route-visible').checked,getResearchSnapshot:()=>({chain_id:snapshot?.scenario_id,distance_estimate:totals(rows),segments:rows,facilities:allFacilities.filter(f=>snapshot&&related(f,snapshot))}),selectFacility:choose};
 }
 global.StationResearchOverlay={create,adjustedEdges,totals,related,chainIssues};
})(typeof window==='undefined'?globalThis:window);
