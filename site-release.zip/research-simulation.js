/* Reproducible parameter scenarios, not empirical passenger predictions.
 * All input and result objects stay in memory. No networking or persistence.
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./research-engine.js'));
  } else {
    root.StationSimulation = factory(root.StationResearch);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function (research) {
  'use strict';

  const LIMITS = Object.freeze({ minIterations: 20, maxIterations: 1000, maxRoutes: 6 });
  const DRAW_FIELDS = Object.freeze([
    'distance', 'speed', 'vertical', 'queue', 'processing', 'wayfinding', 'roadWait'
  ]);
  const finite = value => typeof value === 'number' && Number.isFinite(value);
  const nonnegative = value => finite(value) && value >= 0;
  const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
  const clamp = (value, lower, upper) => Math.min(upper, Math.max(lower, value));

  function defaultSettings() {
    return {
      routeIds: [],
      iterations: 200,
      seed: 20261017,
      speedCv: 0.1,
      timeCv: 0.2,
      sampleDistance: true,
      targetDepartureSec: null,
      measure: { queueReductionSec: 0, wayfindingReductionSec: 0 }
    };
  }

  function normalizeSettings(input, options) {
    input = input && typeof input === 'object' ? input : {};
    options = options || {};
    const defaults = defaultSettings();
    const warnings = [];
    function bounded(key, lower, upper) {
      if (!own(input, key)) return defaults[key];
      if (!finite(input[key])) {
        warnings.push(key + ' 无效，已采用默认值。');
        return defaults[key];
      }
      const result = clamp(input[key], lower, upper);
      if (result !== input[key]) warnings.push(key + ' 已限制在允许范围内。');
      return result;
    }
    const iterations = Math.round(bounded('iterations', LIMITS.minIterations, LIMITS.maxIterations));
    const seed = finite(input.seed) ? Math.trunc(input.seed) >>> 0 : defaults.seed;
    const routeIds = [];
    const requested = Array.isArray(input.routeIds) && input.routeIds.length
      ? input.routeIds : [options.routeId];
    for (const id of requested) {
      if (typeof id === 'string' && id && !routeIds.includes(id)) routeIds.push(id);
    }
    const measureInput = input.measure && typeof input.measure === 'object' ? input.measure : {};
    const measure = {};
    for (const key of ['queueReductionSec', 'wayfindingReductionSec']) {
      measure[key] = nonnegative(measureInput[key]) ? measureInput[key] : 0;
      if (own(measureInput, key) && !nonnegative(measureInput[key])) {
        warnings.push(key + ' 必须为非负数，已采用 0 秒。');
      }
    }
    return {
      routeIds,
      iterations,
      seed,
      speedCv: bounded('speedCv', 0, 0.5),
      timeCv: bounded('timeCv', 0, 1),
      sampleDistance: input.sampleDistance !== false,
      targetDepartureSec: nonnegative(input.targetDepartureSec) ? input.targetDepartureSec : null,
      measure,
      warnings
    };
  }

  // Mulberry32: an integer seed produces the same uniform sequence across runs.
  function createRandom(seed) {
    let state = Math.trunc(finite(seed) ? seed : 0) >>> 0;
    return function random() {
      state = (state + 0x6D2B79F5) >>> 0;
      let value = state;
      value = Math.imul(value ^ value >>> 15, value | 1);
      value ^= value + Math.imul(value ^ value >>> 7, value | 61);
      return ((value ^ value >>> 14) >>> 0) / 4294967296;
    };
  }

  function createDraws(iterations, seed) {
    const random = createRandom(seed);
    const draws = [];
    for (let index = 0; index < iterations; index += 1) {
      const draw = {};
      for (const field of DRAW_FIELDS) draw[field] = random();
      draws.push(draw);
    }
    return draws;
  }

  function quantile(values, probability) {
    if (!finite(probability) || probability < 0 || probability > 1) return null;
    const sorted = (Array.isArray(values) ? values : []).filter(finite).sort((a, b) => a - b);
    if (!sorted.length) return null;
    const position = (sorted.length - 1) * probability;
    const lower = Math.floor(position);
    const fraction = position - lower;
    return sorted[lower] * (1 - fraction) + sorted[Math.ceil(position)] * fraction;
  }

  function summarize(values) {
    const valid = (Array.isArray(values) ? values : []).filter(finite);
    if (!valid.length) {
      return { count: 0, mean: null, median: null, p90: null, min: null, max: null };
    }
    // Incremental mean avoids overflow when many large, finite values are added.
    let mean = 0;
    let min = Infinity;
    let max = -Infinity;
    valid.forEach((value, index) => {
      const difference = value - mean;
      mean = Number.isFinite(difference)
        ? mean + difference / (index + 1)
        : mean * (index / (index + 1)) + value / (index + 1);
      min = Math.min(min, value);
      max = Math.max(max, value);
    });
    return {
      count: valid.length,
      mean,
      median: quantile(valid, 0.5),
      p90: quantile(valid, 0.9),
      min,
      max
    };
  }

  // Inverse CDF for triangular uncertainty: bounds are not confidence intervals.
  function sampleTriangular(lower, mode, upper, uniform) {
    if (![lower, mode, upper].every(nonnegative) || lower > mode || mode > upper) return null;
    if (!finite(uniform) || uniform < 0 || uniform > 1) return null;
    if (lower === upper) return mode;
    const width = upper - lower;
    const split = (mode - lower) / width;
    if (uniform <= split) return lower + Math.sqrt(uniform) * Math.sqrt(width) * Math.sqrt(mode - lower);
    return upper - Math.sqrt(1 - uniform) * Math.sqrt(width) * Math.sqrt(upper - mode);
  }

  // A bounded log-uniform multiplier has mean 1 after normalization and
  // CV² = a*coth(a)-1. Calibrate a once per batch, not once per trial.
  // This remains strictly positive even at the maximum supported time CV.
  function multiplierDistribution(cv) {
    if (!finite(cv) || cv <= 0) {
      return { sample: () => 1, lower: 1, upper: 1, cv: 0 };
    }
    const target = cv * cv;
    let lower = 0;
    let upper = 4;
    for (let iteration = 0; iteration < 64; iteration += 1) {
      const middle = (lower + upper) / 2;
      const variance = middle < 1e-4
        ? middle * middle / 3 - Math.pow(middle, 4) / 45
        : middle / Math.tanh(middle) - 1;
      if (variance < target) lower = middle;
      else upper = middle;
    }
    const width = (lower + upper) / 2;
    const normalizer = Math.sinh(width) / width;
    return {
      sample: uniform => Math.exp(width * (2 * uniform - 1)) / normalizer,
      lower: Math.exp(-width) / normalizer,
      upper: Math.exp(width) / normalizer,
      cv
    };
  }

  function safeEvaluate(dataset, routeId, options) {
    try {
      const result = research.evaluateRoute(dataset, routeId, options);
      return result && typeof result === 'object'
        ? result : { feasible: false, status: 'invalid', reasons: ['empty_evaluation'] };
    } catch (_) {
      return { feasible: false, status: 'invalid', reasons: ['evaluation_failed'] };
    }
  }

  function safeMetrics(dataset, routeId, options) {
    try {
      return research.chainMetrics(dataset, options.platformId, routeId, options.alightZ) || {};
    } catch (_) {
      return {};
    }
  }

  function distanceDistribution(metrics, settings, warnings) {
    const estimate = metrics.walkM;
    const lower = metrics.walkLowerM;
    const upper = metrics.walkUpperM;
    if (!settings.sampleDistance) return null;
    if ([lower, estimate, upper].every(nonnegative) && lower <= estimate && estimate <= upper) {
      return { lower, estimate, upper };
    }
    warnings.push('步行距离区间缺失或顺序异常，本路线未进行距离抽样。');
    return null;
  }

  function resolveOptions(input) {
    const defaults = research && typeof research.defaultOptions === 'function'
      ? research.defaultOptions() : {};
    return Object.assign({}, defaults, input || {});
  }

  function scaled(value, multiplier) {
    return nonnegative(value) ? value * multiplier : value;
  }

  function trialOptions(base, draw, distributions, distance, measure) {
    const result = Object.assign({}, base);
    result.speedMps = scaled(base.speedMps, distributions.speed.sample(draw.speed));
    result.verticalPerTransitionSec = scaled(
      base.verticalPerTransitionSec, distributions.time.sample(draw.vertical)
    );
    result.queueSec = scaled(
      nonnegative(base.queueSec) ? Math.max(0, base.queueSec - measure.queueReductionSec) : base.queueSec,
      distributions.time.sample(draw.queue)
    );
    result.processingSec = scaled(base.processingSec, distributions.time.sample(draw.processing));
    result.wayfindingSec = scaled(
      nonnegative(base.wayfindingSec)
        ? Math.max(0, base.wayfindingSec - measure.wayfindingReductionSec) : base.wayfindingSec,
      distributions.time.sample(draw.wayfinding)
    );
    result.roadWaitSec = scaled(base.roadWaitSec, distributions.time.sample(draw.roadWait));
    if (distance) {
      result.walkDistanceOverrideM = sampleTriangular(
        distance.lower, distance.estimate, distance.upper, draw.distance
      );
    }
    return result;
  }

  function successful(result) {
    return result.feasible === true && result.status === 'complete' && nonnegative(result.totalSec);
  }

  function outcomeCategory(result) {
    if (successful(result)) return 'valid';
    if (result.status === 'excluded') return 'excluded';
    const missingGeometry = result.metrics && Array.isArray(result.metrics.missing)
      && result.metrics.missing.length > 0;
    const multipleProblems = Array.isArray(result.reasons) && result.reasons.length > 1;
    if (result.status === 'unavailable' && nonnegative(result.readySec)
      && !missingGeometry && !multipleProblems) return 'censored';
    return 'invalid';
  }

  function listValues(value) {
    if (Array.isArray(value)) return value;
    if (value && typeof value === 'object') return Object.values(value);
    return [];
  }

  function routeById(dataset, routeId) {
    if (dataset && dataset.routeById && own(dataset.routeById, routeId)) return dataset.routeById[routeId];
    return listValues(dataset && dataset.routes).find(route =>
      route && (route.id === routeId || route.routeId === routeId)
    );
  }

  function planById(dataset, planId) {
    if (dataset && dataset.planById && own(dataset.planById, planId)) return dataset.planById[planId];
    return listValues(dataset && dataset.plans).find(plan =>
      plan && (plan.id === planId || plan.planId === planId)
    );
  }

  function selectComparableRoutes(dataset, options, settings) {
    const selected = routeById(dataset, options.routeId);
    if (!selected || !selected.destination || !selected.mode) {
      settings.routeIds = [];
      settings.warnings.push('基准路线缺少有效目的地或接驳方式，未运行路线比较。');
      return;
    }
    settings.routeIds = settings.routeIds.filter(routeId => {
      const candidate = routeById(dataset, routeId);
      if (!candidate) {
        settings.warnings.push('未运行不存在的路线：' + routeId);
        return false;
      }
      if (candidate.destination !== selected.destination || candidate.mode !== selected.mode) {
        settings.warnings.push('已排除目的地或接驳方式不同的路线：' + routeId);
        return false;
      }
      return true;
    });
    if (settings.routeIds.length > LIMITS.maxRoutes) {
      settings.routeIds.length = LIMITS.maxRoutes;
      settings.warnings.push('一次最多比较 6 条路线；本批次已截取前 6 条。');
    }
  }

  // Target validity is separate from whether a later train remains available.
  // Missing the last departure must count as a miss, not disappear from the rate.
  function validateTarget(dataset, routeId, options, settings) {
    if (settings.targetDepartureSec === null) return { valid: false, reason: 'not_specified' };
    const route = routeById(dataset, routeId);
    const plan = planById(dataset, options.metroPlanId);
    if (!route || !plan) return { valid: false, reason: 'route_or_plan_missing' };
    if (!['metro', '地铁'].includes(route.mode)) return { valid: false, reason: 'not_scheduled_metro_route' };
    const routeLine = typeof research.routeLine === 'function'
      ? research.routeLine(route) : route.line ?? route.metroLine ?? route.lineId;
    const planLine = plan.line ?? plan.metroLine ?? plan.lineId;
    if (routeLine === undefined || routeLine === null || planLine === undefined
      || planLine === null || String(routeLine) !== String(planLine)) {
      return { valid: false, reason: 'line_not_verified' };
    }
    const events = Array.isArray(plan.events) ? plan.events : [];
    const exists = events.some(event => event && event.departureSec === settings.targetDepartureSec);
    return exists
      ? { valid: true, reason: null }
      : { valid: false, reason: 'departure_not_in_selected_plan' };
  }

  function wilsonInterval(misses, count) {
    if (!Number.isInteger(count) || count <= 0 || !Number.isInteger(misses) || misses < 0 || misses > count) {
      return null;
    }
    const z = 1.959963984540054;
    const rate = misses / count;
    const divisor = 1 + z * z / count;
    const center = (rate + z * z / (2 * count)) / divisor;
    const radius = z * Math.sqrt(rate * (1 - rate) / count + z * z / (4 * count * count)) / divisor;
    return { lower: Math.max(0, center - radius), upper: Math.min(1, center + radius), level: 0.95 };
  }

  function emptyAccumulator(routeId, trials) {
    return {
      routeId,
      trials,
      samples: [],
      validTrials: 0,
      unavailableTrials: 0,
      censoredTrials: 0,
      excludedTrials: 0,
      invalidTrials: 0,
      targetEvidenceTrials: 0,
      targetMissCount: 0,
      reasons: Object.create(null),
      warnings: []
    };
  }

  function recordOutcome(accumulator, result, target, options, settings) {
    const category = outcomeCategory(result);
    if (category === 'valid') {
      accumulator.validTrials += 1;
      accumulator.samples.push(result.totalSec);
    } else {
      accumulator.unavailableTrials += 1;
      accumulator[category + 'Trials'] += 1;
      const reasons = Array.isArray(result.reasons) && result.reasons.length ? result.reasons : [result.status];
      for (const reason of new Set(reasons.map(String))) {
        accumulator.reasons[reason] = (accumulator.reasons[reason] || 0) + 1;
      }
    }
    const usableReadyTime = category === 'valid' || category === 'censored';
    if (target.valid && usableReadyTime && nonnegative(result.readySec) && nonnegative(options.bufferSec)) {
      const threshold = result.readySec + options.bufferSec;
      if (Number.isFinite(threshold)) {
        accumulator.targetEvidenceTrials += 1;
        if (threshold > settings.targetDepartureSec) accumulator.targetMissCount += 1;
      }
    }
  }

  function finishAccumulator(accumulator, target) {
    const stats = summarize(accumulator.samples);
    return Object.assign(accumulator, {
      meanSec: stats.mean,
      medianSec: stats.median,
      p90Sec: stats.p90,
      minSec: stats.min,
      maxSec: stats.max,
      targetValidated: target.valid,
      targetReason: target.reason,
      targetMissRate: accumulator.targetEvidenceTrials
        ? accumulator.targetMissCount / accumulator.targetEvidenceTrials : null,
      targetUnavailableTrials: accumulator.trials - accumulator.targetEvidenceTrials,
      targetMissInterval: wilsonInterval(accumulator.targetMissCount, accumulator.targetEvidenceTrials),
      conditionalOnAvailable: accumulator.unavailableTrials > 0,
      quantileMethod: 'linear_interpolation_type_7'
    });
  }

  function emptyPair(routeId, trials) {
    return {
      routeId,
      totalTrials: trials,
      baseline: [],
      measure: [],
      savings: [],
      baselineOnlyTrials: 0,
      measureOnlyTrials: 0,
      neitherTrials: 0,
      baselineCensoredTrials: 0,
      measureCensoredTrials: 0,
      departureComparableTrials: 0,
      sameDepartureTrials: 0
    };
  }

  function recordPair(pair, baseline, measure) {
    const beforeValid = successful(baseline);
    const afterValid = successful(measure);
    if (outcomeCategory(baseline) === 'censored') pair.baselineCensoredTrials += 1;
    if (outcomeCategory(measure) === 'censored') pair.measureCensoredTrials += 1;
    if (beforeValid && afterValid) {
      pair.baseline.push(baseline.totalSec);
      pair.measure.push(measure.totalSec);
      pair.savings.push(baseline.totalSec - measure.totalSec);
      if (nonnegative(baseline.departureSec) && nonnegative(measure.departureSec)) {
        pair.departureComparableTrials += 1;
        if (baseline.departureSec === measure.departureSec) pair.sameDepartureTrials += 1;
      }
    } else if (beforeValid) pair.baselineOnlyTrials += 1;
    else if (afterValid) pair.measureOnlyTrials += 1;
    else pair.neitherTrials += 1;
  }

  function finishPair(pair) {
    const baseline = summarize(pair.baseline);
    const measure = summarize(pair.measure);
    const saving = summarize(pair.savings);
    return {
      routeId: pair.routeId,
      totalTrials: pair.totalTrials,
      baselineMeanSec: baseline.mean,
      measureMeanSec: measure.mean,
      meanSavingSec: saving.mean,
      p90SavingSec: saving.p90,
      pairedTrials: saving.count,
      sameDepartureRate: pair.departureComparableTrials
        ? pair.sameDepartureTrials / pair.departureComparableTrials : null,
      sameDepartureTrials: pair.sameDepartureTrials,
      departureComparableTrials: pair.departureComparableTrials,
      baselineOnlyTrials: pair.baselineOnlyTrials,
      measureOnlyTrials: pair.measureOnlyTrials,
      neitherTrials: pair.neitherTrials,
      baselineCensoredTrials: pair.baselineCensoredTrials,
      measureCensoredTrials: pair.measureCensoredTrials,
      savingsSamples: pair.savings,
      conditionalOnPairedAvailability: saving.count < pair.totalTrials
    };
  }

  function assertEngine() {
    if (!research || typeof research.evaluateRoute !== 'function' || typeof research.chainMetrics !== 'function') {
      throw new Error('StationResearch must be loaded before StationSimulation.');
    }
  }

  function runBatch(dataset, inputOptions, inputSettings) {
    assertEngine();
    const options = resolveOptions(inputOptions);
    const settings = normalizeSettings(inputSettings, options);
    selectComparableRoutes(dataset, options, settings);
    const draws = createDraws(settings.iterations, settings.seed);
    const distributions = {
      speed: multiplierDistribution(settings.speedCv),
      time: multiplierDistribution(settings.timeCv)
    };
    const pairRouteId = settings.routeIds.includes(options.routeId)
      ? options.routeId : settings.routeIds[0] || null;
    const pair = emptyPair(pairRouteId, pairRouteId ? settings.iterations : 0);
    const routes = [];
    const noMeasure = { queueReductionSec: 0, wayfindingReductionSec: 0 };
    for (const routeId of settings.routeIds) {
      const accumulator = emptyAccumulator(routeId, settings.iterations);
      const metrics = safeMetrics(dataset, routeId, options);
      const distance = distanceDistribution(metrics, settings, accumulator.warnings);
      const target = validateTarget(dataset, routeId, options, settings);
      if (settings.targetDepartureSec !== null && !target.valid) {
        accumulator.warnings.push('指定目标班次无法与该路线的时刻计划核对，不计算目标错过率。');
      }
      for (const draw of draws) {
        const baselineOptions = trialOptions(options, draw, distributions, distance, noMeasure);
        const baseline = safeEvaluate(dataset, routeId, baselineOptions);
        if (Array.isArray(baseline.warnings)) {
          for (const warning of baseline.warnings) {
            if (!accumulator.warnings.includes(warning)) accumulator.warnings.push(warning);
          }
        }
        recordOutcome(accumulator, baseline, target, baselineOptions, settings);
        if (routeId === pairRouteId) {
          const measureOptions = trialOptions(options, draw, distributions, distance, settings.measure);
          recordPair(pair, baseline, safeEvaluate(dataset, routeId, measureOptions));
        }
      }
      routes.push(finishAccumulator(accumulator, target));
    }
    const assumptions = [
      '结果来自参数情景抽样，未经实测校准，不能解释为真实旅客行为概率或服务措施因果效果。',
      '步行距离采用给定下限、估计值和上限的三角分布；区间缺失时保留既有距离设定。',
      '速度与耗时使用均值为 1 的有界对数均匀乘子；各因素独立，跨路线及措施前后复用同一组随机数。',
      '措施在抽样前减少设定的排队或寻路耗时，下限为 0；其他参数及目标班次保持不变。',
      '平均值和分位数仅基于完整可计算试次；超出末班计划、资料缺失及约束排除另行计数。',
      '目标错过率按就绪时间加预留时间是否超过同一指定班次计算，不代表限流、容量不足或拒绝登乘。',
      '已知就绪时间但错过所选计划末班的试次仍计入目标错过率；不自动循环次日时刻表。',
      '所选时刻计划的适用日期及方向需人工确认，本模块不自动判定计划适用性。',
      '目标错过率的 95% Wilson 区间只描述本批次随机抽样误差，不反映模型及输入数据误差。'
    ];
    return {
      routes,
      paired: finishPair(pair),
      assumptions,
      warnings: settings.warnings,
      seed: settings.seed,
      iterations: settings.iterations,
      settings: Object.assign({}, settings, { warnings: undefined }),
      multiplierBounds: {
        speed: { lower: distributions.speed.lower, upper: distributions.speed.upper },
        time: { lower: distributions.time.lower, upper: distributions.time.upper }
      }
    };
  }

  function sensitivity(dataset, inputOptions) {
    assertEngine();
    const options = resolveOptions(inputOptions);
    const routeId = options.routeId;
    const metrics = safeMetrics(dataset, routeId, options);
    const route = routeById(dataset, routeId);
    const scenarios = [];
    function add(parameter, label, lowValue, highValue, unit) {
      scenarios.push({ parameter, label, lowValue, highValue, unit });
    }
    add('speedMps', '步行速度',
      nonnegative(options.speedMps) ? options.speedMps * 0.8 : null,
      nonnegative(options.speedMps) ? options.speedMps * 1.2 : null, 'm/s');
    add('walkDistanceOverrideM', '步行距离区间', metrics.walkLowerM ?? null, metrics.walkUpperM ?? null, 'm');
    for (const [parameter, label, increment] of [
      ['verticalPerTransitionSec', '每次跨层耗时', 15],
      ['queueSec', '排队耗时', 30],
      ['processingSec', '闸机及检查处理', 15],
      ['wayfindingSec', '寻路耗时', 30]
    ]) {
      const value = options[parameter];
      add(parameter, label, nonnegative(value) ? value * 0.5 : null,
        nonnegative(value) ? Math.max(value * 1.5, value + increment) : null, 's');
    }
    if (route && ['metro', '地铁'].includes(route.mode)) {
      add('bufferSec', '登乘预留时间',
        nonnegative(options.bufferSec) ? Math.max(0, options.bufferSec - 30) : null,
        nonnegative(options.bufferSec) ? options.bufferSec + 30 : null, 's');
    } else {
      add('roadWaitSec', '城市端候车耗时',
        nonnegative(options.roadWaitSec) ? options.roadWaitSec * 0.5 : null,
        nonnegative(options.roadWaitSec) ? Math.max(options.roadWaitSec * 1.5, options.roadWaitSec + 60) : null, 's');
    }
    return scenarios.map(scenario => {
      const low = scenario.lowValue === null ? null
        : safeEvaluate(dataset, routeId, Object.assign({}, options, { [scenario.parameter]: scenario.lowValue }));
      const high = scenario.highValue === null ? null
        : safeEvaluate(dataset, routeId, Object.assign({}, options, { [scenario.parameter]: scenario.highValue }));
      const lowTotalSec = low && successful(low) ? low.totalSec : null;
      const highTotalSec = high && successful(high) ? high.totalSec : null;
      return Object.assign({}, scenario, {
        lowTotalSec,
        highTotalSec,
        spanSec: lowTotalSec !== null && highTotalSec !== null ? Math.abs(highTotalSec - lowTotalSec) : null,
        lowStatus: low ? low.status : 'missing_parameter',
        highStatus: high ? high.status : 'missing_parameter',
        lowReasons: low && Array.isArray(low.reasons) ? low.reasons : [],
        highReasons: high && Array.isArray(high.reasons) ? high.reasons : []
      });
    });
  }

  return Object.freeze({
    LIMITS,
    defaultSettings,
    runBatch,
    sensitivity,
    createRandom,
    sampleTriangular,
    quantile,
    summarize
  });
});
