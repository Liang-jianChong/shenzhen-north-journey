(function () {
  "use strict";
  const $ = (id) => document.getElementById(id),
    E = window.ServiceEngine;
  const esc = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    );
  const number = (n) => (Number.isFinite(n) ? Math.round(n).toLocaleString("zh-CN") : "—");
  const minutes = (s) => (Number.isFinite(s) ? (s / 60).toFixed(1) : "—");
  const duration = (s) => (Number.isFinite(s) ? minutes(s) + " 分钟" : "未提供");
  const val = (id) => ($(id).value.trim() === "" ? null : Number($(id).value));
  const clock = (s) => E.formatClock(s);
  const typeName = {
    followed: "旅客跟拍",
    simulated: "人工模拟",
    unspecified: "性质未注明",
    scenario: "情景假设",
  };
  const labels = {
    walkSec: "步行",
    verticalSec: "垂直交通",
    queueSec: "排队",
    processingSec: "检查／办理",
    wayfindingSec: "寻路停顿",
    waitSec: "接驳候车",
  };
  const missingNames = {
    startSec: "起始时刻",
    walkDistanceM: "步行距离",
    speedMps: "步行速度",
    verticalSec: "垂直交通",
    queueSec: "排队",
    processingSec: "检查办理",
    wayfindingSec: "寻路停顿",
    roadWaitSec: "接驳候车",
    metroPlan: "运行图",
    boardingBufferSec: "登乘预留",
    waitSec: "接驳候车",
  };
  let D,
    C,
    timer = null,
    currentTab = "flow",
    lastResult = null,
    lastComparison = null,
    handlersBound = false;
  const demoFields = new Set();
  let observations = [];
  let lifecycle = 0;
  const emptyAppMarkup = $("app").innerHTML;

  function clearPrivateState() {
    lifecycle += 1;
    clearResearchWorkbench();
    if (timer) clearInterval(timer);
    timer = null;
    D = null;
    C = null;
    observations = [];
    lastResult = null;
    lastComparison = null;
    demoFields.clear();
    handlersBound = false;
    // Restore only the original static template, removing private DOM as well
    // as references before the page can enter the back-forward cache.
    const workbench = $("research-workbench");
    $("app").innerHTML = emptyAppMarkup;
    if (workbench) $("research-workbench").replaceWith(workbench);
    $("app").hidden = true;
    $("private-loader").hidden = false;
    $("clear-data").hidden = true;
    $("research-file").value = "";
    $("research-file").disabled = false;
    $("loading").textContent = "本次研究数据已清除，请重新选择本机研究包。";
  }
  const selectOptions = (id, rows, selection) => {
    $(id).replaceChildren(
      ...rows.map(([value, label]) => {
        const o = document.createElement("option");
        o.value = value;
        o.textContent = label;
        return o;
      }),
    );
    if (rows.some((r) => r[0] === selection)) $(id).value = selection;
  };
  const currentRoute = () => C.routes.find((r) => r.id === $("route").value);
  const currentChain = () => C.chains[$("platform").value + "__" + $("route").value];
  const metroLine = () =>
    currentRoute().mode === "地铁"
      ? Number(currentRoute().destination.match(/[456]/)?.[0]) || null
      : null;
  const startSec = () => E.parseClock($("clock").value);
  const effectiveSec = (t) => (Number.isFinite(t.actualSec) ? t.actualSec : t.plannedSec);
  const datedClock = (iso, seconds) =>
    iso && iso.slice(0, 10) !== $("date").value
      ? iso.slice(5, 10) + " " + clock(seconds)
      : clock(seconds);
  function geometry() {
    const c = currentChain(),
      a = c.alight_adjustment,
      z = val("alight-z"),
      delta = a
        ? Math.abs(a.target_platform_z - z) * (a.metres_per_z_unit ?? 1) - a.first_edge_default_m
        : 0;
    return {
      total: c.distance.estimate_m + delta,
      lower: c.distance.lower_m + delta * (a?.lower_multiplier ?? 0.9),
      upper: c.distance.upper_m + delta * (a?.upper_multiplier ?? 1.1),
      walk: c.walk.estimate_m + delta,
      walkLower: c.walk.lower_m + delta * (a?.lower_multiplier ?? 0.9),
      walkUpper: c.walk.upper_m + delta * (a?.upper_multiplier ?? 1.1),
      verticalCount: c.vertical.count,
      complete: c.distance.complete_as_estimate,
      conflict: c.conflict,
    };
  }
  function routeChanged() {
    const r = currentRoute(),
      g = geometry(),
      params = new URLSearchParams({
        route: r.id,
        platform: $("platform").value,
        z: $("alight-z").value,
      });
    history.replaceState(null, "", "?" + params.toString() + "#" + currentTab);
    $("map-link").href = "index.html?" + params;
    $("chain-label").textContent =
      $("platform").value + " → " + r.exit_id.replace("Exit", "") + " → " + r.destination;
    $("distance-label").textContent = "全链约 " + number(g.total) + " m";
    const line = metroLine(),
      oldPlan = $("plan").value;
    selectOptions(
      "plan",
      [
        ["", "请选择运行图（不自动认定日期适用）"],
        ...D.metro.plans
          .filter((p) => p.line === line)
          .map((p) => [p.id, `${p.line} 号线 · ${p.version} · ${p.dayType} · ${p.direction}`]),
      ],
      oldPlan,
    );
    $("metro-box").hidden = !line;
    $("shared-plan").hidden = !line;
    $("road-wait-label").hidden = !!line;
    $("distance-detail").textContent =
      `步行约 ${number(g.walk)} m（情景范围 ${number(g.walkLower)}–${number(g.walkUpper)} m），另有 ${g.verticalCount} 个跨层段。设备段全长从步行距离排除；时间范围不是统计置信区间。${g.conflict ? "当前路线含源数据冲突，需先核对。" : ""}`;
    renderTime();
    renderVideos();
    renderObservations();
  }
  function updateTrainList() {
    const list = D.hsr.days[$("date").value] || [];
    selectOptions(
      "train",
      [
        ["", "手动设置时刻"],
        ...list
          .filter((t) => Number.isFinite(effectiveSec(t)))
          .sort((a, b) => effectiveSec(a) - effectiveSec(b))
          .map((t) => [
            t.id,
            `${clock(effectiveSec(t)).slice(0, 5)} · ${t.train} · 下车 ${t.down} 人${t.actualSec === null ? "（图定）" : ""}`,
          ]),
      ],
      "",
    );
    $("train-note").textContent = "手动设置起始时刻；客流回放与时间试验共享该时刻。";
    renderFlow();
    renderTime();
  }
  function chooseTrain(id) {
    const t = (D.hsr.days[$("date").value] || []).find((x) => x.id === id);
    if (!t) return;
    const seconds = effectiveSec(t);
    if (seconds < 0 || seconds >= 86400) {
      $("train-note").textContent = "该事件跨自然日，请手动选择对应日期和时刻。";
      return;
    }
    $("clock").value = clock(seconds);
    $("train").value = t.id;
    $("train-note").textContent =
      `${t.actualSec === null ? "图定到达，实际时刻缺失" : "源表实际到达"}；下车 ${t.down} 人；站台 ${t.sourcePlatform || "缺失"}。到站时刻暂作情景起点，下车延迟需调整。${t.sourceDate !== $("date").value ? "源业务日 " + t.sourceDate + "；按实际自然日回放。" : ""}地图站台不自动对应。`;
    renderFlow();
    renderTime();
  }
  function metric(label, value, note = "") {
    return `<div class="metric"><div class="metric-label">${esc(label)}</div><div class="metric-value">${esc(value)}</div><small>${esc(note)}</small></div>`;
  }
  function renderFlow() {
    if (startSec() === null) {
      $("flow-metrics").innerHTML = '<p class="notice">请选择有效的起始时刻。</p>';
      $("flow-chart").replaceChildren();
      $("arrivals").replaceChildren();
      $("bin-label").textContent = "时刻未填";
      $("arrival-window").textContent = "";
      return;
    }
    const day = D.afc.days.find((x) => x.date === $("date").value),
      s = startSec(),
      bin = Math.min(287, Math.floor(s / 300)),
      trains = D.hsr.days[$("date").value] || [],
      inWindow = trains.filter(
        (t) => effectiveSec(t) >= bin * 300 && effectiveSec(t) < (bin + 1) * 300,
      );
    $("timeline").value = bin;
    $("bin-label").textContent =
      clock(bin * 300).slice(0, 5) + "–" + clock((bin + 1) * 300).slice(0, 5);
    $("flow-metrics").innerHTML =
      metric("当前 5 分钟 · AFC 进站", number(day.in[bin]), "全站刷卡人次") +
      metric("当前 5 分钟 · AFC 出站", number(day.out[bin]), "全站刷卡人次") +
      metric(
        "当前 5 分钟 · 高铁下车",
        number(inWindow.reduce((a, t) => a + t.down, 0)),
        `${inWindow.length} 班；实际优先，缺失用图定`,
      ) +
      metric(
        "当日高铁到达下车",
        number(trains.reduce((a, t) => a + t.down, 0)),
        `${trains.length} 条正客流记录`,
      );
    const w = 1000,
      h = 240,
      p = { l: 55, r: 20, t: 12, b: 30 },
      max = Math.max(...day.in, ...day.out, 1),
      top = Math.ceil(max / 500) * 500,
      x = (i) => p.l + (i / 287) * (w - p.l - p.r),
      y = (v) => h - p.b - (v / top) * (h - p.t - p.b);
    let svg = "";
    for (let j = 0; j <= 4; j++) {
      const v = (top * j) / 4;
      svg += `<line x1="${p.l}" y1="${y(v)}" x2="${w - p.r}" y2="${y(v)}" stroke="#e6eef1"/><text x="${p.l - 10}" y="${y(v) + 4}" text-anchor="end" fill="#788c94" font-size="10">${Math.round(v)}</text>`;
    }
    for (let hour = 0; hour <= 24; hour += 4) {
      const xx = x(Math.min(287, hour * 12));
      svg += `<text x="${xx}" y="233" text-anchor="middle" fill="#788c94" font-size="10">${String(hour).padStart(2, "0")}:00</text>`;
    }
    for (const [key, color] of [
      ["in", "#267b96"],
      ["out", "#ba8050"],
    ])
      svg += `<path d="${day[key].map((v, i) => (i ? "L" : "M") + x(i).toFixed(1) + "," + y(v).toFixed(1)).join(" ")}" stroke="${color}" fill="none" stroke-width="2"/>`;
    svg += `<line x1="${x(bin)}" x2="${x(bin)}" y1="10" y2="${h - p.b}" stroke="#274d5c" stroke-dasharray="4 4"/><circle cx="${x(bin)}" cy="${y(day.in[bin])}" r="4" fill="#267b96"/>`;
    $("flow-chart").innerHTML = svg;
    $("flow-chart").setAttribute(
      "aria-label",
      `${day.date} 全站 AFC 五分钟客流，当前进站 ${day.in[bin]}，出站 ${day.out[bin]} 人次`,
    );
    const nearby = trains
      .filter((t) => Math.abs(effectiveSec(t) - s) <= 1800)
      .sort((a, b) => effectiveSec(a) - effectiveSec(b));
    $("arrival-window").textContent = "所选时刻前后 30 分钟 · " + nearby.length + " 班";
    $("arrivals").innerHTML = nearby.length
      ? nearby
          .map(
            (t) =>
              `<tr><td>${esc(t.train)}</td><td>${datedClock(t.plannedISO, t.plannedSec)}</td><td>${datedClock(t.actualISO, t.actualSec)}</td><td>${number(t.down)}</td><td>${esc(t.sourcePlatform || "未提供")}</td><td><button data-train="${esc(t.id)}">用于时间估计</button></td></tr>`,
          )
          .join("")
      : '<tr><td colspan="6">此时段没有源表到达记录。</td></tr>';
  }
  function inputs() {
    const g = geometry(),
      line = metroLine(),
      civil = startSec(),
      service = line && civil !== null && civil < 14400 ? civil + 86400 : civil;
    return {
      startSec: service,
      walkDistanceM: g.complete ? g.walk : null,
      speedMps: val("speed"),
      verticalSec: val("vertical"),
      queueSec: val("queue"),
      processingSec: val("processing"),
      wayfindingSec: val("wayfinding"),
      waitingMode: line ? "metro" : "road",
      metroPlan: line ? D.metro.plans.find((p) => p.id === $("plan").value) || null : null,
      boardingBufferSec: line ? val("buffer") : null,
      roadWaitSec: line ? null : val("road-wait"),
    };
  }
  function bars(result) {
    const values = Object.values(result.components).filter(Number.isFinite),
      max = Math.max(...values, 1);
    return Object.entries(labels)
      .map(
        ([k, label]) =>
          `<div class="bar-row"><span>${label}</span><div class="bar-track"><i style="width:${Number.isFinite(result.components[k]) ? (result.components[k] / max) * 100 : 0}%"></i></div><span>${Number.isFinite(result.components[k]) ? minutes(result.components[k]) + " 分" : "待补充"}</span></div>`,
      )
      .join("");
  }
  function publishResearchContext() {
    if (!D || !C) return;
    const civil = startSec();
    const service = metroLine() && civil !== null && civil < 14400 ? civil + 86400 : civil;
    window.dispatchEvent(
      new CustomEvent("station:context-changed", {
        detail: {
          routeId: $("route").value,
          platformId: $("platform").value,
          alightZ: val("alight-z"),
          startSec: service,
          date: $("date").value,
          metroPlanId: $("plan").value,
        },
      }),
    );
  }
  function clearResearchWorkbench() {
    window.dispatchEvent(new CustomEvent("station:bundle-cleared"));
  }
  function renderTime() {
    const input = inputs(),
      result = E.computeJourney(input);
    lastResult = result;
    const complete = Number.isFinite(result.totalSec),
      invalid = result.invalidFields.length > 0,
      missing = result.missingFields.map((k) => missingNames[k] || k).join("、");
    $("journey-result").innerHTML =
      `<div class="large-number">${minutes(complete ? result.totalSec : result.knownTotalSec)}<small>分钟${complete ? "" : "（已知部分）"}</small></div><p class="status-line">${complete ? "完整情景估计 · 非实测全链耗时" : invalid ? "输入无效：" + esc(result.invalidFields.map((k) => missingNames[k] || k).join("、")) : result.status === "unavailable" ? "所选运行图内无可衔接发车，完整时间不可计算" : missing ? "待补充：" + esc(missing) : "完整时间不可计算"}</p>`;
    $("time-bars").innerHTML = bars(result);
    const plan = input.metroPlan;
    $("plan-note").textContent =
      (plan
        ? `${plan.line} 号线 ${plan.version} / ${plan.dayType} / ${plan.direction}，${plan.events.length} 班。生效日期及方向对应终点站未提供，需自行核实适用性。${plan.version === "559" ? "该版本源文件与标题的日型存在冲突，勿直接作为工作日实况。" : ""}`
        : "尚未选运行图，地铁候车时间暂不计算。文件未提供 7 号线时刻。") +
      (startSec() !== null && startSec() < 14400
        ? " 当前为凌晨：按前一运营日的 24:00–28:00 处理，请选择前一运营日适用运行图。"
        : "");
    $("next-train").textContent = result.nextTrain
      ? `预计 ${clock(result.readySec)} 到达候车位置 → 计划 ${clock(result.nextTrain.departureSec)} 发车；候车 ${duration(result.nextTrain.waitSec)}`
      : result.readySec !== null
        ? `预计 ${clock(result.readySec)} 到达候车位置；${result.status === "unavailable" ? "所选运行图内没有可衔接的下一班。" : plan ? "补齐登乘预留等参数后计算计划班次。" : "选择运行图后计算计划候车。"}`
        : "补齐各段时间后计算可衔接的计划班次。";
    $("parameter-note").textContent = demoFields.size
      ? "当前仍含 " +
        demoFields.size +
        " 项演示参数，请按调查结果逐项替换；演示值不代表深圳北站实测。"
      : missing
        ? "未填写项保留为未知，不会当作 0。填写调查值或明确的情景假设后计算全链。"
        : "当前为自定义情景参数；除明确引用的源表字段外，不作为实测结果。";
    renderComparison();
    publishResearchContext();
  }
  function renderComparison() {
    const base = inputs(),
      sq = val("save-queue"),
      sw = val("save-wayfinding");
    if (
      sq === null ||
      sw === null ||
      sq < 0 ||
      sw < 0 ||
      (base.queueSec !== null && sq > base.queueSec) ||
      (base.wayfindingSec !== null && sw > base.wayfindingSec)
    ) {
      $("comparison").innerHTML =
        '<p class="notice error">减少量必须为非负数，且不能超过基准中的对应时间。</p>';
      lastComparison = null;
      return;
    }
    const overrides = {
        queueSec: base.queueSec === null ? null : base.queueSec - sq,
        wayfindingSec: base.wayfindingSec === null ? null : base.wayfindingSec - sw,
      },
      c = E.compareJourneys(base, overrides);
    lastComparison = c;
    const b = c.baseline || E.computeJourney(base),
      v = c.intervention || c.scenario || E.computeJourney({ ...base, ...overrides });
    $("comparison").innerHTML =
      `<div class="compare-grid"><div class="compare-cell"><h3>基准情景</h3><strong>${minutes(b.totalSec)} <small>分钟</small></strong><p>${b.nextTrain ? "计划发车 " + clock(b.nextTrain.departureSec) : "完整参数未齐或无可衔接班次"}</p></div><div class="compare-cell"><h3>${esc($("measure-name").value || "措施情景")}</h3><strong>${minutes(v.totalSec)} <small>分钟</small></strong><p>${v.nextTrain ? "计划发车 " + clock(v.nextTrain.departureSec) : "完整参数未齐或无可衔接班次"}</p></div><div class="compare-cell"><h3>全链时间减少</h3><strong>${minutes(c.savingsSec)} <small>分钟</small></strong><p>步行与排队节省不等于全链节省</p></div></div><div class="two-col"><div>${bars(b)}</div><div>${bars(v)}</div></div>`;
  }
  function filteredVideos() {
    let list = D.videos.records;
    const type = $("video-type").value,
      r = currentRoute();
    if (type !== "all") list = list.filter((v) => v.observationType === type);
    const pathType = $("video-path").value;
    if (pathType !== "all") list = list.filter((v) => v.pathType === pathType);
    if ($("video-scope").value === "route") {
      const exit = r.exit_id.replace("Exit", "");
      list = list.filter(
        (v) => (v.exitTags || []).includes(exit) && v.direction === "出站" && v.mode === r.mode,
      );
      const line = metroLine(),
        dest = r.destination;
      let tags = line
        ? [line === 5 ? "metro_5" : "metro_4_6"]
        : dest.includes("公交")
          ? ["bus_east_l2"]
          : dest.includes("网约车A")
            ? ["ride_hailing_a"]
            : dest.includes("网约车B")
              ? ["ride_hailing_b"]
              : dest.includes("停车场-1")
                ? ["parking_b1"]
                : dest.includes("停车场-2")
                  ? ["parking_b2"]
                  : dest.includes("停车场")
                    ? ["parking_east"]
                    : dest.includes("出租车2")
                      ? ["taxi_2f"]
                      : dest.includes("出租车1")
                        ? ["taxi_1f_left", "taxi_1f_right"]
                        : dest.includes("出租车")
                          ? ["taxi_west"]
                          : [];
      if (tags.length)
        list = list.filter((v) => (v.destinationTags || []).some((t) => tags.includes(t)));
    }
    return list;
  }
  function renderVideos() {
    const list = filteredVideos(),
      eligible = list.filter((v) => v.completionStatus !== "incomplete"),
      walk = E.statistics(eligible, "walkSec"),
      wait = E.statistics(eligible, "waitSec"),
      total = E.statistics(eligible, "totalSec");
    const mixed =
      $("video-type").value === "all" ||
      $("video-scope").value === "all" ||
      $("video-path").value === "all";
    $("video-stats").innerHTML =
      metric("筛选记录", number(list.length), "候选匹配，需逐段核对") +
      metric(
        "源表步行字段中位数",
        mixed ? "不混合统计" : minutes(walk.median),
        mixed ? "请选择当前路线及单一性质／路径" : `分钟 · 有值 n=${walk.count}`,
      ) +
      metric(
        "等待中位数",
        mixed ? "不混合统计" : minutes(wait.median),
        mixed ? "请选择当前路线及单一性质／路径" : `分钟 · 有值 n=${wait.count}`,
      ) +
      metric(
        "总换乘中位数",
        mixed ? "不混合统计" : minutes(total.median),
        mixed ? "请选择当前路线及单一性质／路径" : `分钟 · 有值 n=${total.count}`,
      );
    $("video-rows").innerHTML = list.length
      ? list
          .map(
            (v) =>
              `<tr><td>${esc(v.id)}<small>${esc(v.date)}</small></td><td>${esc(v.from)} → ${esc(v.to)}<small>${esc(v.mode)} · ${esc(v.pathType || "路径类型未注明")} · 源表第 ${v.sourceRow} 行</small></td><td>${esc(typeName[v.observationType])}<small>${v.completionStatus === "incomplete" ? "录像未完成 · 不纳入统计" : v.completionStatus === "complete" ? "片段完成（非全链）" : "片段完整性未注明"}</small></td><td>${duration(v.walkSec)}</td><td>${duration(v.waitSec)}</td><td>${duration(v.totalSec)}</td></tr>`,
          )
          .join("")
      : '<tr><td colspan="6">当前筛选没有观测记录。可切换记录性质或查看全部索引。</td></tr>';
  }
  function renderObservations() {
    $("observations").innerHTML = observations.length
      ? observations
          .slice()
          .reverse()
          .map(
            (o) =>
              `<div class="observation-item">${esc(o.sourceId)} · ${esc(o.locationId)} · ${esc(o.chainId)} · ${esc(typeName[o.observationType])}<br><small>${esc(o.component)}：${o.startSec}–${o.endSec} 秒，用时 ${o.durationSec} 秒</small></div>`,
          )
          .join("")
      : '<p class="muted">本次会话还没有新增分段观测。</p>';
  }
  function setTab(name) {
    currentTab = ["flow", "time", "evidence", "compare", "workbench"].includes(name)
      ? name
      : "flow";
    document.querySelectorAll("[data-tab]").forEach((b) => {
      const yes = b.dataset.tab === currentTab;
      b.setAttribute("aria-selected", String(yes));
      b.tabIndex = yes ? 0 : -1;
    });
    document.querySelectorAll(".panel").forEach((p) => (p.hidden = p.id !== "panel-" + currentTab));
    history.replaceState(null, "", location.pathname + location.search + "#" + currentTab);
  }
  function init(bundle) {
    D = bundle.serviceData;
    C = bundle.routeContext;
    const q = new URLSearchParams(location.search);
    selectOptions(
      "route",
      C.routes.map((r) => [r.id, `${r.id} · ${r.exit_id.replace("Exit", "")} → ${r.destination}`]),
      q.get("route") || "M01-01",
    );
    selectOptions(
      "platform",
      C.platforms.map((p) => [p.id, p.id + " 候选"]),
      q.get("platform") || "P06",
    );
    const z = Number(q.get("z") || 0);
    $("alight-z").value = Number.isFinite(z) ? Math.max(-200, Math.min(200, z)) : 0;
    $("alight-z").min = -200;
    $("alight-z").max = 200;
    selectOptions(
      "date",
      D.afc.days.map((d) => [d.date, d.date]),
      "2026-03-02",
    );
    $("provenance").innerHTML =
      "<ul>" +
      D.provenance
        .map(
          (p) =>
            `<li>${esc(p.file)}：${p.sheetRanges.map((r) => esc(r.sheet + "!" + r.range)).join("；")}。${p.dateStart ? esc(p.dateStart + " 至 " + p.dateEnd) : "生效时间未提供"}。来源：用户提供工作簿，未独立核验。</li>`,
        )
        .join("") +
      "</ul><p>视频记录按旅客跟拍、人工模拟和性质未注明分别展示。缺失值保留为空；视频时长不作为完整换乘耗时。数据来自本次选择的本机研究包；网页不包含默认研究数据，也不提供原始工作簿或视频附件。</p>";
    if (!handlersBound) {
      for (const id of ["route", "platform", "alight-z"])
        $(id).addEventListener("change", () => {
          if (id === "alight-z") {
            const z = val(id);
            if (z === null || !Number.isFinite(z) || z < -200 || z > 200) {
              $(id).value = 0;
            }
          }
          routeChanged();
        });
      $("date").addEventListener("change", updateTrainList);
      $("train").addEventListener("change", () => chooseTrain($("train").value));
      $("clock").addEventListener("input", () => {
        $("train").value = "";
        $("train-note").textContent = "手动设置起始时刻；地图站台仍为候选选择。";
        renderFlow();
        renderTime();
      });
      $("timeline").addEventListener("input", () => {
        $("clock").value = clock(Number($("timeline").value) * 300);
        $("train").value = "";
        $("train-note").textContent = "按 5 分钟时段浏览历史数据。";
        renderFlow();
        renderTime();
      });
      $("play").onclick = () => {
        if (timer) {
          clearInterval(timer);
          timer = null;
          $("play").textContent = "播放";
          $("play").setAttribute("aria-pressed", "false");
          return;
        }
        timer = setInterval(() => {
          const b = Number($("timeline").value);
          if (b === 287) {
            clearInterval(timer);
            timer = null;
            $("play").textContent = "播放";
            $("play").setAttribute("aria-pressed", "false");
            return;
          }
          $("timeline").value = b + 1;
          $("timeline").dispatchEvent(new Event("input"));
        }, 900);
        $("play").textContent = "暂停";
        $("play").setAttribute("aria-pressed", "true");
      };
      $("arrivals").onclick = (e) => {
        const b = e.target.closest("[data-train]");
        if (b) {
          chooseTrain(b.dataset.train);
          setTab("time");
        }
      };
      for (const id of [
        "speed",
        "vertical",
        "queue",
        "processing",
        "wayfinding",
        "road-wait",
        "buffer",
        "plan",
      ])
        $(id).addEventListener(id === "plan" ? "change" : "input", () => {
          demoFields.delete(id);
          renderTime();
        });
      for (const id of ["measure-name", "save-wayfinding", "save-queue"])
        $(id).addEventListener("input", renderComparison);
      $("demo").onclick = () => {
        for (const [k, v] of Object.entries({
          speed: 1.2,
          vertical: geometry().verticalCount ? 120 : 0,
          queue: 60,
          processing: 30,
          wayfinding: 30,
          "road-wait": 300,
          buffer: 15,
        })) {
          $(k).value = v;
          demoFields.add(k);
        }
        renderTime();
      };
      for (const id of ["video-scope", "video-type", "video-path"]) $(id).onchange = renderVideos;
      document.querySelectorAll("[data-tab]").forEach((b, i, all) => {
        b.onclick = () => setTab(b.dataset.tab);
        b.onkeydown = (e) => {
          if (["ArrowLeft", "ArrowRight"].includes(e.key)) {
            e.preventDefault();
            const next = all[(i + (e.key === "ArrowRight" ? 1 : all.length - 1)) % all.length];
            setTab(next.dataset.tab);
            next.focus();
          }
        };
      });
      $("observation-form").onsubmit = (e) => {
        e.preventDefault();
        const a = val("obs-start"),
          b = val("obs-end");
        if (a === null || b === null || a < 0 || b < a) {
          $("obs-message").textContent = "结束时间必须大于或等于开始时间。";
          return;
        }
        const o = {
          id: crypto.randomUUID(),
          chainId: currentChain().chain_id,
          alightZ: val("alight-z"),
          sourceId: $("obs-source").value.trim(),
          locationId: $("obs-location").value.trim(),
          component: $("obs-kind").value,
          observationType: $("obs-type").value,
          startSec: a,
          endSec: b,
          durationSec: Math.round((b - a) * 1000) / 1000,
          createdAt: new Date().toISOString(),
          storage: "page_memory_only",
          mappingStatus: "user_annotation_not_independently_verified",
        };
        if (!o.sourceId || !o.locationId) {
          $("obs-message").textContent = "请填写证据和位置编号。";
          return;
        }
        observations.push(o);
        $("obs-message").textContent = "已加入本次观测；刷新或关闭后清除。";
        renderObservations();
      };
      handlersBound = true;
    }
    setTab(location.hash.slice(1));
    updateTrainList();
    routeChanged();
    $("private-loader").hidden = true;
    $("app").hidden = false;
    $("clear-data").hidden = false;
    window.dispatchEvent(new CustomEvent("station:bundle-loaded", { detail: { bundle } }));
    publishResearchContext();
  }
  function validateBundle(bundle) {
    const d = bundle && bundle.serviceData,
      c = bundle && bundle.routeContext;
    if (
      !d ||
      !c ||
      !Array.isArray(d.afc?.days) ||
      !d.afc.days.length ||
      !d.hsr?.days ||
      !Array.isArray(d.metro?.plans) ||
      !Array.isArray(d.videos?.records) ||
      !Array.isArray(d.provenance) ||
      !Array.isArray(c.routes) ||
      !c.routes.length ||
      !Array.isArray(c.platforms) ||
      !c.platforms.length ||
      !c.chains
    )
      throw new Error("文件需要包含完整的 serviceData 和 routeContext。");
    if (
      d.afc.days.some(
        (day) =>
          typeof day.date !== "string" ||
          !Array.isArray(day.in) ||
          !Array.isArray(day.out) ||
          day.in.length !== 288 ||
          day.out.length !== 288 ||
          [...day.in, ...day.out].some(
            (v) => typeof v !== "number" || !Number.isFinite(v) || v < 0,
          ),
      )
    )
      throw new Error("AFC 数据需要每自然日 288 个有效的五分钟记录。");
    if (
      c.routes.some(
        (r) => !r.id || typeof r.exit_id !== "string" || typeof r.destination !== "string",
      ) ||
      c.platforms.some((p) => !p.id)
    )
      throw new Error("路线或站台索引不完整。");
    for (const p of c.platforms)
      for (const r of c.routes) {
        const chain = c.chains[p.id + "__" + r.id];
        if (!chain?.distance || !chain.walk || !chain.vertical)
          throw new Error("研究包中缺少对应的出行链距离记录。");
      }
    if (
      d.provenance.some((p) => !Array.isArray(p.sheetRanges)) ||
      d.metro.plans.some((p) => !Array.isArray(p.events))
    )
      throw new Error("数据来源或地铁计划字段不完整。");
  }
  const initialParams = new URLSearchParams(location.search),
    mapParams = new URLSearchParams();
  for (const key of ["route", "platform", "z"])
    if (initialParams.has(key)) mapParams.set(key, initialParams.get(key));
  $("map-link").href = "index.html" + (mapParams.size ? "?" + mapParams.toString() : "");
  $("clear-data").onclick = () => {
    clearPrivateState();
    location.reload();
  };
  $("research-file").onchange = async (event) => {
    const input = event.target,
      file = input.files && input.files[0];
    if (!file) return;
    const loadLifecycle = ++lifecycle;
    input.disabled = true;
    $("loading").classList.remove("error");
    $("loading").textContent = "正在本机读取研究包…";
    try {
      if (file.size > 100 * 1024 * 1024) throw new Error("文件超过 100 MB，请使用对应的研究包。");
      const text = await file.text();
      if (loadLifecycle !== lifecycle) return;
      const bundle = JSON.parse(text);
      validateBundle(bundle);
      init(bundle);
      input.value = "";
      $("loading").textContent = "本机研究包已加载，仅本次会话可见；数据未上传，关闭页面后清除。";
    } catch (error) {
      if (loadLifecycle !== lifecycle) return;
      clearPrivateState();
      $("loading").classList.add("error");
      $("loading").textContent =
        "无法读取研究包：" + (error instanceof SyntaxError ? "JSON 格式无效。" : error.message);
      input.value = "";
      input.disabled = false;
    }
  };
  window.addEventListener("pagehide", () => {
    clearPrivateState();
  });
  window.addEventListener("pageshow", (event) => {
    if (event.persisted) location.reload();
  });
})();
