(() => {
  // Let native links work in the exported website without the conversation
  // host's HTTPS-only external-link interception (also supports local preview).
  window.addEventListener("message", (event) => {
    if (event.source !== window.parent || event.data?.type !== "station-select-route") return;
    window.stationJourney?.select({
      route: event.data.route,
      platform: event.data.platform,
      z: event.data.z,
    });
  });
  window.parent.postMessage({ type: "station-route-link-ready" }, "*");
})();
