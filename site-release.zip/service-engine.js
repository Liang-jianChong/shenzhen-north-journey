/* Deterministic scenario calculations. Timetable times are service-day seconds.
 * These functions estimate parameter scenarios; they do not predict capacity,
 * crowding, or whether a passenger can actually board a train. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.ServiceEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const finiteNonnegative = value => typeof value === 'number' && Number.isFinite(value) && value >= 0;
  const isMissing = value => value === null || value === undefined || value === '';
  const has = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

  // Hours may exceed 23, so 24:05 denotes the next day of the SAME service plan.
  function parseClock(value) {
    if (typeof value === 'number') return finiteNonnegative(value) ? value : null;
    if (typeof value !== 'string') return null;
    const match = /^\s*(\d+):([0-5]\d)(?::([0-5]\d)(\.\d{1,3})?)?\s*$/.exec(value);
    if (!match) return null;
    const result = Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0) + Number(match[4] || 0);
    return finiteNonnegative(result) ? result : null;
  }

  function formatClock(value, options) {
    if (!finiteNonnegative(value)) return '—';
    const seconds = Math.round(value);
    const hour = Math.floor(seconds / 3600);
    const minute = Math.floor(seconds % 3600 / 60);
    const second = seconds % 60;
    const pad = number => String(number).padStart(2, '0');
    return pad(hour) + ':' + pad(minute) + ((options && options.seconds === false) ? '' : ':' + pad(second));
  }

  function nextDeparture(events, readySec, bufferSec = 0) {
    if (!Array.isArray(events) || !finiteNonnegative(readySec) || !finiteNonnegative(bufferSec)) return null;
    const threshold = readySec + bufferSec;
    if (!Number.isFinite(threshold)) return null;
    let chosen = null;
    for (const event of events) {
      if (!event || !finiteNonnegative(event.departureSec) || event.departureSec < threshold) continue;
      if (!chosen || event.departureSec < chosen.departureSec) chosen = event;
    }
    if (!chosen) return null;
    return {
      event: Object.assign({}, chosen),
      departureSec: chosen.departureSec,
      arrivalSec: finiteNonnegative(chosen.arrivalSec) ? chosen.arrivalSec : null,
      readySec,
      bufferSec,
      waitSec: chosen.departureSec - readySec,
      boardingSlackSec: chosen.departureSec - threshold
    };
  }

  function computeJourney(input) {
    input = input && typeof input === 'object' ? input : {};
    const missingFields = [];
    const invalidFields = [];
    const warnings = [];
    function read(key, positive) {
      const value = input[key];
      if (isMissing(value)) { missingFields.push(key); return null; }
      if (!finiteNonnegative(value) || (positive && value === 0)) { invalidFields.push(key); return null; }
      return value;
    }
    const startSec = read('startSec');
    const walkDistanceM = read('walkDistanceM');
    const speedMps = read('speedMps', true);
    let walkSec = walkDistanceM !== null && speedMps !== null ? walkDistanceM / speedMps : null;
    if (walkSec !== null && !Number.isFinite(walkSec)) { invalidFields.push('walkDurationOverflow'); walkSec = null; }
    const components = {
      walkSec,
      verticalSec: read('verticalSec'),
      queueSec: read('queueSec'),
      processingSec: read('processingSec'),
      wayfindingSec: read('wayfindingSec'),
      waitSec: null
    };
    const preWait = [components.walkSec, components.verticalSec, components.queueSec, components.processingSec, components.wayfindingSec];
    let preWaitSec = preWait.every(value => value !== null) ? preWait.reduce((a, b) => a + b, 0) : null;
    if (preWaitSec !== null && !Number.isFinite(preWaitSec)) { invalidFields.push('preWaitDurationOverflow'); preWaitSec = null; }
    let readySec = startSec !== null && preWaitSec !== null ? startSec + preWaitSec : null;
    if (readySec !== null && !Number.isFinite(readySec)) { invalidFields.push('readyTimeOverflow'); readySec = null; }
    const mode = input.waitingMode || (input.metroPlan !== null && input.metroPlan !== undefined ? 'metro' : 'road');
    let nextTrain = null;
    let unavailableReason = null;
    if (mode === 'metro') {
      const boardingBufferSec = read('boardingBufferSec');
      if (!input.metroPlan) {
        missingFields.push('metroPlan');
      } else if (!Array.isArray(input.metroPlan.events)) {
        invalidFields.push('metroPlan.events');
      } else {
        const skipped = input.metroPlan.events.filter(event => !event || !finiteNonnegative(event.departureSec)).length;
        if (skipped) warnings.push('Skipped ' + skipped + ' timetable events without a valid departure time.');
        if (readySec !== null && boardingBufferSec !== null) {
          nextTrain = nextDeparture(input.metroPlan.events, readySec, boardingBufferSec);
          if (nextTrain) components.waitSec = nextTrain.waitSec;
          else unavailableReason = 'no_departure_in_selected_service_plan';
        }
      }
      if (!nextTrain) missingFields.push('waitSec');
    } else if (mode === 'road') {
      components.waitSec = read('roadWaitSec');
    } else {
      invalidFields.push('waitingMode');
      missingFields.push('waitSec');
    }
    let knownTotalSec = Object.values(components).filter(value => value !== null).reduce((a, b) => a + b, 0);
    if (!Number.isFinite(knownTotalSec)) { invalidFields.push('totalDurationOverflow'); knownTotalSec = null; }
    const complete = invalidFields.length === 0 && missingFields.length === 0 && knownTotalSec !== null;
    const totalSec = complete ? knownTotalSec : null;
    const boardingSec = complete ? startSec + totalSec : null;
    return {
      status: invalidFields.length ? 'invalid' : complete ? 'complete' : unavailableReason ? 'unavailable' : 'partial',
      mode,
      components,
      startSec,
      readySec,
      preWaitSec,
      nextTrain,
      totalSec,
      knownTotalSec,
      boardingSec,
      missingFields: [...new Set(missingFields)],
      invalidFields: [...new Set(invalidFields)],
      unavailableReason,
      warnings
    };
  }

  // Overrides are explicit assumptions, never inferred effects of a measure.
  // Recomputing the next departure is essential: saved walking can become waiting.
  function compareJourneys(baselineInput, interventionOverrides) {
    const baseline = computeJourney(baselineInput);
    const intervention = computeJourney(Object.assign({}, baselineInput, interventionOverrides));
    const comparable = baseline.status === 'complete' && intervention.status === 'complete';
    const componentSavingsSec = {};
    for (const key of Object.keys(baseline.components)) {
      const before = baseline.components[key], after = intervention.components[key];
      componentSavingsSec[key] = before !== null && after !== null ? before - after : null;
    }
    return {
      interpretation: 'parameter_scenario_comparison',
      baseline,
      intervention,
      comparable,
      savingsSec: comparable ? baseline.totalSec - intervention.totalSec : null,
      componentSavingsSec,
      sameScheduledDeparture: baseline.nextTrain && intervention.nextTrain
        ? baseline.nextTrain.departureSec === intervention.nextTrain.departureSec
        : null
    };
  }

  function statistics(values, accessor) {
    const list = Array.isArray(values) ? values : [];
    const read = typeof accessor === 'function' ? accessor : typeof accessor === 'string' ? item => item && item[accessor] : item => item;
    const valid = list.map(read).filter(finiteNonnegative).sort((a, b) => a - b);
    const quantile = probability => {
      if (!valid.length) return null;
      const index = (valid.length - 1) * probability;
      const lower = Math.floor(index), upper = Math.ceil(index);
      return valid[lower] + (valid[upper] - valid[lower]) * (index - lower);
    };
    return {
      count: valid.length,
      excludedCount: list.length - valid.length,
      min: valid.length ? valid[0] : null,
      max: valid.length ? valid[valid.length - 1] : null,
      mean: valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : null,
      median: quantile(0.5),
      p90: quantile(0.9),
      quantileMethod: 'linear_interpolation_type_7'
    };
  }

  // Exact matching; null/undefined/empty filters mean no restriction. Arrays are OR.
  // The source bundle stores exitTags arrays; `exit` is a convenience alias.
  function filterObservations(records, filters) {
    if (!Array.isArray(records)) return [];
    filters = filters || {};
    return records.filter(record => record && Object.entries(filters).every(([key, expected]) => {
      if (isMissing(expected)) return true;
      const field = key === 'exit' && !has(record, 'exit') ? 'exitTags' : key;
      if (!has(record, field)) return false;
      const actualValues = Array.isArray(record[field]) ? record[field] : [record[field]];
      const expectedValues = Array.isArray(expected) ? expected : [expected];
      return expectedValues.some(value => actualValues.includes(value));
    }));
  }

  return Object.freeze({ parseClock, formatClock, nextDeparture, computeJourney, compareJourneys, statistics, filterObservations });
});
