(() => {
  const root = document.getElementById("station-3d"),
    $ = (id) => root.querySelector("#s3-" + id),
    D = JSON.parse(document.getElementById("s3-data").textContent),
    c = $("canvas"),
    ctx = c.getContext("2d"),
    byId = Object.fromEntries(D.objects.map((o) => [o.id, o]));
  let editEnabled = false,
    researchOverlay = null;
  let yaw = -0.62,
    pitch = 0.42,
    selected = "E3",
    reviews = {},
    draft = [],
    hits = [],
    labelBoxes = [],
    lastProjection = null,
    drag = null,
    colors = {};
  const option = (el, v, t) => {
    const o = document.createElement("option");
    o.value = v;
    o.textContent = t;
    el.append(o);
    return o;
  };

  const J = JSON.parse(document.getElementById("s3-journey-data").textContent);
  for (const part of J.prefixes.concat(J.suffixes)) {
    for (const key of ["nodes", "edges"]) {
      const table = part[key];
      part[key] = table.rows.map((row) =>
        Object.fromEntries(table.fields.map((field, i) => [field, row[i]])),
      );
    }
  }
  const copyJourney = (x) => JSON.parse(JSON.stringify(x));
  const journeyColors = { hypothesis: "#af7224", fbx: "#8452b4", csv: "#287ea8" };
  let journeyPrefix = null,
    journeySuffix = null,
    journeyNodes = [],
    journeyEdges = [],
    journeyIndex = 0,
    journeyHits = [];
  const displayY = (p) => (Math.abs(p[1] - 11.74) < 0.0001 ? 11.81 : p[1]);
  const journeyVisible = (n, i) => {
    const scene = $("scene").value,
      floor = $("floor").value;
    if ((scene === "rail" && i > 3) || (scene === "transfer" && i < 7)) return false;
    if (floor === "all") return true;
    if (floor === "NC" && i >= 3 && i <= 7) return true;
    return n.regional_floor_hint === floor;
  };
  function journeySnapshot() {
    return {
      dataset_version: J.dataset_version,
      scenario_id: $("journey-platform").value + "__" + journeySuffix.id,
      scenario_parameters: {
        platform_id: $("journey-platform").value,
        route_id: journeySuffix.id,
        alight_z: +$("journey-alight").value,
        alight_z_units: "schematic_not_measured_meters",
      },
      scope: J.scope,
      coordinate_space: J.coordinate_space,
      coordinate_frames: J.coordinate_frames,
      topology_revision: J.topology_revision,
      same_level_revision: J.same_level_revision,
      same_level_groups: J.same_level_groups,
      rendering_policy: J.rendering_policy,
      rendering_alignment: {
        source_y: 11.74,
        display_y: 11.81,
        scope: "drawing_only_at_exit_interface",
        coordinate_values_in_this_export_unchanged: true,
      },
      display_scope: "Public spatial visualization only; research records are not hosted.",
      metric_policy: J.metric_policy,
      verified_walkable: false,
      enabled_for_simulation: false,
      actual_total_distance_m: null,
      nodes: copyJourney(journeyNodes),
      edges: copyJourney(journeyEdges),
      evidence: J.evidence,
      assumptions: J.assumptions,
      service_events: journeySuffix.service_events,
      notes: (journeySuffix.notes || []).concat(journeyPrefix.warnings || []),
    };
  }
  function selectJourneyNode(index) {
    journeyIndex = Math.max(0, Math.min(journeyNodes.length - 1, index));
    const n = journeyNodes[journeyIndex];
    $("journey-node").textContent =
      String(journeyIndex + 1).padStart(2, "0") +
      " · " +
      n.label +
      " ｜ " +
      n.stage +
      " ｜ Y " +
      n.position[1].toFixed(2) +
      " ｜ " +
      (n.basis === "csv" ? "CSV 源路点" : n.basis === "fbx" ? "FBX 候选几何" : "推定显示位置") +
      (journeyIndex === 6 || journeyIndex === 7
        ? "。07出口与08接驳起点共址；两种语义不增加步行距离。"
        : "") +
      " 来源：" +
      (n.source_ref || "见研究包");
    [...$("journey-steps").children].forEach((b, i) =>
      b.setAttribute("aria-current", i === journeyIndex ? "step" : "false"),
    );
    $("journey-prev").disabled = journeyIndex === 0;
    $("journey-next").disabled = journeyIndex === journeyNodes.length - 1;
    draw();
  }
  function buildJourney(reset = true) {
    journeySuffix = J.suffixes.find((s) => s.id === $("journey-route").value);
    if ([...$("mode").options].some((o) => o.value === journeySuffix.mode))
      $("mode").value = journeySuffix.mode;
    journeyPrefix = J.prefixes.find(
      (p) => p.id === $("journey-platform").value + "-" + journeySuffix.exit_id,
    );
    journeyNodes = copyJourney(journeyPrefix.nodes.concat(journeySuffix.nodes));
    journeyNodes[0].position[2] = +$("journey-alight").value;
    journeyEdges = copyJourney(journeyPrefix.edges).concat(
      [
        {
          id: $("journey-platform").value + "__" + journeySuffix.id + "-JOIN",
          from: journeyPrefix.nodes.at(-1).id,
          to: journeySuffix.nodes[0].id,
          basis: "hypothesis",
          unit_status: "FRAME_LINK_UNVERIFIED",
          length_m: null,
          enabled_for_simulation: false,
          source_refs: [journeyPrefix.nodes.at(-1).source_ref, journeySuffix.nodes[0].source_ref],
        },
      ],
      copyJourney(journeySuffix.edges),
    );
    journeyEdges.forEach((e, i) => {
      const a = journeyNodes[i].position,
        b = journeyNodes[i + 1].position;
      e.display_length_units = Math.hypot(...a.map((v, k) => b[k] - v));
      if (e.basis === "hypothesis") {
        e.horizontal_length_units = Math.hypot(b[0] - a[0], b[2] - a[2]);
        e.height_delta_units = b[1] - a[1];
      }
    });
    $("journey-title").textContent =
      $("journey-platform").value +
      " 下车 → " +
      journeySuffix.exit_id.slice(4) +
      " → " +
      journeySuffix.destination +
      " ｜ " +
      journeySuffix.id +
      " · " +
      (journeySuffix.geometry === "source_csv" ? "接驳段有源路点" : "接驳段为补画");
    $("journey-alight-label").textContent =
      +$("journey-alight").value === 0
        ? "站台中部"
        : (+$("journey-alight").value < 0 ? "偏北 " : "偏南 ") +
          Math.abs(+$("journey-alight").value) +
          " 示意单位";
    $("journey-steps").replaceChildren();
    journeyNodes.forEach((n, i) => {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = String(i + 1).padStart(2, "0") + " " + n.label;
      b.onclick = () => selectJourneyNode(i);
      $("journey-steps").append(b);
    });
    if (reset) {
      $("scene").value = "assembly";
      $("floor").value = "all";
      refreshOptions();
      updateDetail();
    }
    researchOverlay?.update(journeySnapshot());
    selectJourneyNode(0);
    window.parent.postMessage(
      {
        type: "station-journey-selected",
        route: journeySuffix.id,
        platform: $("journey-platform").value,
        z: +$("journey-alight").value,
      },
      "*",
    );
  }
  function selectJourney(params) {
    if (J.suffixes.some((s) => s.id === params.route)) $("journey-route").value = params.route;
    if (J.platforms.some((p) => p.id === params.platform))
      $("journey-platform").value = params.platform;
    if (params.z !== undefined && Number.isFinite(Number(params.z)))
      $("journey-alight").value = String(
        Math.max(-200, Math.min(200, Math.round(Number(params.z) / 10) * 10)),
      );
    buildJourney();
  }

  const mid = (ps) => ps[0].map((_, i) => ps.reduce((s, p) => s + p[i], 0) / ps.length);
  const sceneAllows = (o) =>
    $("scene").value === "assembly" ||
    ($("scene").value === "rail" ? o.space === "FBX" : o.space !== "FBX");
  const objectVisible = (o) =>
    o &&
    sceneAllows(o) &&
    ($("floor").value === "all" ||
      o.id === $("floor").value ||
      o.floor === $("floor").value ||
      o.toFloor === $("floor").value);
  function refreshColors() {
    for (const n of [
      "foreground",
      "muted-foreground",
      "border",
      "background",
      ...Array.from({ length: 6 }, (_, i) => "viz-series-" + (i + 1)),
    ]) {
      const e = document.createElement("span");
      e.style.color = "var(--" + n + ")";
      root.append(e);
      colors[n] = getComputedStyle(e).color;
      e.remove();
    }
  }
  function refreshOptions() {
    const v = $("floor").value;
    $("floor").replaceChildren();
    option($("floor"), "all", "全部楼层");
    D.floors
      .filter(sceneAllows)
      .sort((a, b) => b.y - a.y)
      .forEach((f) => option($("floor"), f.id, f.name + " · Y " + f.y));
    if ([...$("floor").options].some((o) => o.value === v)) $("floor").value = v;
    $("object").replaceChildren();
    const groups = [
      ["楼层与区域", (o) => o.kind === "floor"],
      ["四个出站口", (o) => o.kind === "exit"],
      ["国铁站台候选", (o) => o.kind === "platform"],
      ["国铁楼扶梯候选", (o) => o.kind === "connector"],
      ["接驳楼扶梯与安检", (o) => ["device", "point"].includes(o.kind)],
      ["接驳终点", (o) => o.kind === "destination"],
      ["文档功能与设施 · 无坐标待定位", (o) => o.kind === "unlocated"],
    ];
    for (const [label, filter] of groups) {
      const os = D.objects.filter((o) => filter(o) && objectVisible(o));
      if (!os.length) continue;
      const group = document.createElement("optgroup");
      group.label = label;
      $("object").append(group);
      os.forEach((o) => option(group, o.id, o.name));
    }
    if (![...$("object").options].some((o) => o.value === selected))
      selected = $("object").options[0]?.value || "E3";
    $("object").value = selected;
  }
  D.chains.forEach((ch) => option($("mode"), ch.mode, ch.mode));
  function updateDetail() {
    const o = byId[selected],
      r = reviews[selected] || {};
    if (!o) return;
    $("object").value = selected;
    $("verdict").value = r.verdict || "pending";
    $("note").value = r.note || "";
    const ys = o.points
      ? [...new Set(o.points.map((p) => p[1]))].sort((a, b) => a - b)
      : o.pos
        ? [o.pos[1]]
        : [];
    $("detail").textContent =
      o.name +
      " ｜ " +
      (ys.length ? "Y " + ys.map((v) => v.toFixed(2)).join(" ↔ ") : "无坐标 · 图中不放置虚构点") +
      " ｜ " +
      o.basis +
      "。" +
      o.note;
    $("evidence").replaceChildren();
    for (const e of o.evidence || []) {
      $("evidence").append(document.createTextNode("公开资料：" + e.status + "。" + e.claim + " "));
      for (const key of e.sources) {
        const s = D.web_audit.sources[key],
          a = document.createElement("a");
        a.href = s.url;
        a.textContent = s.title;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        $("evidence").append(a, document.createTextNode(" "));
      }
    }
    $("flow").textContent = draft.length
      ? draft.map((id) => byId[id]?.short || id).join(" → ") + "（草稿直连线，未校验通行）"
      : "尚未画流线";
    $("undo").disabled = !editEnabled || !draft.length;
    $("add").disabled = !editEnabled;
    $("clear-draft").disabled = !editEnabled || !draft.length;
  }
  function save() {
    const state = {
      modelContent: { version: D.version },
      privateContent: {
        scene: $("scene").value,
        floor: $("floor").value,
        spacing: +$("spacing").value,
        camera: $("camera").value,
        yaw,
        pitch,
        view_revision: 6,
        reviews: { ...reviews },
        draft: [...draft],
        selected,
        stage: $("stage").value,
        mode: $("mode").value,
      },
    };
    try {
      localStorage.setItem("szb:station-reviews:v1", JSON.stringify(state));
    } catch {
      $("status").textContent = "浏览器未保存本次校对，请保留在本机研究记录中。";
    }
  }
  function choose(id) {
    if (!byId[id]) return;
    selected = id;
    updateDetail();
    draw();
    save();
  }
  function draw() {
    const w = c.clientWidth,
      h = c.clientHeight,
      dpr = window.devicePixelRatio || 1;
    c.width = w * dpr;
    c.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.font = getComputedStyle(root).fontSize + " " + getComputedStyle(root).fontFamily;
    const fs = parseFloat(getComputedStyle(root).fontSize),
      small = Math.max(11, fs * 0.857);
    ctx.font = small + "px " + getComputedStyle(root).fontFamily;
    const col = (n) => colors[n] || colors.foreground,
      series = (i) => col("viz-series-" + i),
      spread = 1 + +$("spacing").value * 0.08,
      cy = Math.cos(yaw),
      sy = Math.sin(yaw),
      cp = Math.cos(pitch),
      sp = Math.sin(pitch),
      view = $("scene").value;
    const project = (p) => [
      p[0] * cy - p[2] * sy,
      (p[0] * sy + p[2] * cy) * sp - displayY(p) * spread * cp,
      (p[0] * sy + p[2] * cy) * cp + displayY(p) * spread * sp,
    ];
    const floors = D.floors.filter(
      (f) => sceneAllows(f) && ($("floor").value === "all" || f.id === $("floor").value),
    );
    const visible = D.objects.filter((o) => o.kind !== "floor" && o.pos && objectVisible(o));
    let coords = floors
      .flatMap((f) => f.poly)
      .concat(visible.flatMap((o) => o.points || o.poly || [o.pos]));
    coords = coords.concat(journeyNodes.filter(journeyVisible).map((n) => n.position));
    if (!coords.length) return;
    const q = coords.map(project);
    let minx = Math.min(...q.map((p) => p[0])),
      maxx = Math.max(...q.map((p) => p[0])),
      miny = Math.min(...q.map((p) => p[1])),
      maxy = Math.max(...q.map((p) => p[1]));
    const margin = w < 480 ? 20 : 42,
      scale = Math.min(
        (w - 2 * margin) / Math.max(120, maxx - minx),
        (h - 120) / Math.max(100, maxy - miny),
      );
    const cx = (maxx + minx) / 2,
      my = (maxy + miny) / 2;
    const screen = (p) => {
      const t = project(p);
      return [w / 2 + (t[0] - cx) * scale, h / 2 - 5 + (t[1] - my) * scale, t[2]];
    };
    lastProjection = screen;
    hits = [];
    labelBoxes = [];
    function path(ps, color, width = 1, dash = [], alpha = 1, fill = false) {
      ctx.save();
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.globalAlpha = alpha;
      ctx.lineWidth = width;
      ctx.setLineDash(dash);
      ctx.beginPath();
      ps.map(screen).forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
      if (fill) {
        ctx.closePath();
        ctx.fill();
      } else ctx.stroke();
      ctx.restore();
    }
    function line2(a, b, color, alpha = 1) {
      ctx.save();
      ctx.strokeStyle = color;
      ctx.globalAlpha = alpha;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(...a);
      ctx.lineTo(...b);
      ctx.stroke();
      ctx.restore();
    }
    function mark(p, color, shape = "dot", size = 3) {
      const a = screen(p);
      ctx.fillStyle = color;
      ctx.beginPath();
      if (shape === "square") ctx.rect(a[0] - size, a[1] - size, 2 * size, 2 * size);
      else ctx.arc(a[0], a[1], size, 0, 2 * Math.PI);
      ctx.fill();
      return a;
    }
    function label(text, p, mandatory = false, dy = 0) {
      const a = screen(p),
        tw = ctx.measureText(text).width,
        lh = small + 7;
      let chosen = null;
      const offsets = mandatory ? [dy, -20, 20, -38, 38, 58, -58] : [dy, -18, 18, -34, 34];
      for (const oy of offsets) {
        const x = Math.min(w - tw / 2 - 6, Math.max(tw / 2 + 6, a[0])),
          y = Math.min(h - 43, Math.max(36, a[1] + oy));
        const box = [x - tw / 2 - 4, y - lh / 2, tw + 8, lh];
        if (
          !labelBoxes.some(
            (b) =>
              b[0] < box[0] + box[2] &&
              b[0] + b[2] > box[0] &&
              b[1] < box[1] + box[3] &&
              b[1] + b[3] > box[1],
          )
        ) {
          chosen = { x, y, box };
          break;
        }
      }
      if (!chosen) return;
      const { x, y, box } = chosen;
      labelBoxes.push(box);
      if (Math.hypot(x - a[0], y - a[1]) > 15)
        line2([a[0], a[1]], [x, y], col("muted-foreground"), 0.55);
      ctx.save();
      ctx.fillStyle = col("background");
      ctx.globalAlpha = 0.92;
      ctx.fillRect(...box);
      ctx.globalAlpha = 1;
      ctx.fillStyle = col("foreground");
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(text, x, y);
      ctx.restore();
    }
    const faces = [];
    function slab(poly, cat, id, alpha = 0.14) {
      const base = poly.map((p) => [p[0], p[1] - 0.4, p[2]]);
      for (let i = 0; i < poly.length; i++) {
        let j = (i + 1) % poly.length;
        const side = [base[i], base[j], poly[j], poly[i]];
        faces.push({ poly: side, cat, id, alpha: alpha * 1.1, depth: project(mid(side))[2] });
      }
      faces.push({ poly, cat, id, alpha, depth: project(mid(poly))[2] });
    }
    for (const f of floors) {
      if (f.id === "NP") continue;
      if (f.id === "NC") {
        const r = (x0, x1, z0, z1) => [
          [x0, 11.74, z0],
          [x1, 11.74, z0],
          [x1, 11.74, z1],
          [x0, 11.74, z1],
        ];
        for (const side of [1, 2]) {
          const z = side === 1 ? -100 : 100,
            ps = [
              byId["ExitB" + side].pos,
              [-132, 11.81, z],
              [132, 11.81, z],
              byId["ExitA" + side].pos,
            ];
          for (let i = 0; i < ps.length - 1; i++) {
            const a = ps[i],
              b = ps[i + 1],
              dx = b[0] - a[0],
              dz = b[2] - a[2],
              len = Math.hypot(dx, dz),
              nx = (-dz / len) * 9,
              nz = (dx / len) * 9;
            slab(
              [
                [a[0] + nx, 11.81, a[2] + nz],
                [b[0] + nx, 11.81, b[2] + nz],
                [b[0] - nx, 11.81, b[2] - nz],
                [a[0] - nx, 11.81, a[2] - nz],
              ],
              1,
              "NC",
              0.18,
            );
          }
        }
        slab(r(-120, 120, -67, 67), 0, "hall", 0.07);
      } else slab(f.poly, f.cat, f.id, f.id === selected ? 0.28 : 0.14);
    }
    visible
      .filter((o) => o.kind === "platform")
      .forEach((o) => slab(o.poly, 1, o.id, o.id === selected ? 0.45 : 0.2));
    faces
      .sort((a, b) => a.depth - b.depth)
      .forEach((f) => {
        const color = f.cat ? series(f.cat) : col("muted-foreground");
        path(f.poly, color, 1, [], f.alpha, true);
        path([...f.poly, f.poly[0]], col("border"), 0.8, [], 0.8);
      });
    const rails = visible.filter((o) => o.kind === "platform");
    for (const p of rails) {
      const zs = p.poly.map((t) => t[2]);
      for (const dx of [-9, 9])
        path(
          [
            [p.pos[0] + dx, p.pos[1] - 0.3, Math.min(...zs)],
            [p.pos[0] + dx, p.pos[1] - 0.3, Math.max(...zs)],
          ],
          col("border"),
          0.7,
          [],
          0.7,
        );
    }
    const selectedObj = byId[selected];
    const links = visible.filter((o) => ["connector", "device"].includes(o.kind));
    links
      .sort((a, b) => project(a.pos)[2] - project(b.pos)[2])
      .forEach((o) => {
        const on = o.id === selected || o.platform === selected,
          ps = o.points;
        if (o.ambiguous) {
          ps.forEach((p) => mark(p, series(o.cat), "square", on ? 4 : 2));
        } else {
          const low = ps[0],
            high = ps.at(-1);
          path(
            [low, high],
            on ? series(o.cat) : col("muted-foreground"),
            on ? 3 : 1.4,
            o.space === "FBX" ? [4, 3] : [],
            on ? 1 : 0.22,
          );
          if (on || view === "rail" || $("floor").value !== "all") {
            const steps = Math.max(3, Math.round(Math.abs(high[1] - low[1])));
            for (let i = 0; i <= steps; i++) {
              const p = low.map((v, k) => v + ((high[k] - v) * i) / steps);
              const a = screen(p);
              line2(
                [a[0] - 3, a[1]],
                [a[0] + 3, a[1]],
                on ? series(o.cat) : col("muted-foreground"),
                0.6,
              );
            }
          }
          mark(low, series(o.cat), "dot", on ? 4 : 1.3);
          mark(high, series(o.cat), "square", on ? 4 : 1.3);
        }
        hits.push({ id: o.id, p: screen(o.pos) });
      });
    journeyHits = [];
    if (researchOverlay?.showRoutes() !== false) {
      for (let i = 0; i < journeyEdges.length; i++) {
        if (!journeyVisible(journeyNodes[i], i) || !journeyVisible(journeyNodes[i + 1], i + 1))
          continue;
        const a = journeyNodes[i].position,
          b = journeyNodes[i + 1].position,
          e = journeyEdges[i];
        path([a, b], col("background"), 6, [], 0.95);
        path(
          [a, b],
          journeyColors[e.basis] || journeyColors.hypothesis,
          3,
          e.basis === "hypothesis" ? [6, 4] : [],
          1,
        );
        const aa = screen(a),
          bb = screen(b),
          dx = bb[0] - aa[0],
          dy = bb[1] - aa[1],
          len = Math.hypot(dx, dy);
        if (len > 42) {
          const tx = aa[0] + dx * 0.65,
            ty = aa[1] + dy * 0.65,
            ux = dx / len,
            uy = dy / len;
          ctx.fillStyle = journeyColors[e.basis] || journeyColors.hypothesis;
          ctx.beginPath();
          ctx.moveTo(tx + ux * 5, ty + uy * 5);
          ctx.lineTo(tx - ux * 4 - uy * 3.5, ty - uy * 4 + ux * 3.5);
          ctx.lineTo(tx - ux * 4 + uy * 3.5, ty - uy * 4 - ux * 3.5);
          ctx.closePath();
          ctx.fill();
        }
      }
      journeyNodes.forEach((n, i) => {
        if (!journeyVisible(n, i)) return;
        const p = mark(
          n.position,
          journeyColors[n.basis] || journeyColors.hypothesis,
          i === 6 ? "square" : "dot",
          i === journeyIndex ? 5 : i === 6 ? 4 : 2.5,
        );
        journeyHits.push({ index: i, p });
      });
      if (journeyNodes.length) {
        const current = journeyNodes[journeyIndex];
        if (journeyVisible(current, journeyIndex)) {
          const a = screen(current.position);
          ctx.strokeStyle = col("foreground");
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.arc(a[0], a[1], 8, 0, Math.PI * 2);
          ctx.stroke();
          label(
            String(journeyIndex + 1).padStart(2, "0") + " " + current.label,
            current.position,
            true,
            -22,
          );
        }
        const keys =
          w < 480 ? [0, 6, journeyNodes.length - 1] : [0, 3, 4, 6, journeyNodes.length - 1];
        for (const i of keys) {
          if (i === journeyIndex || !journeyVisible(journeyNodes[i], i)) continue;
          label(
            i === 0
              ? "下车 · " + $("journey-platform").value
              : i === 3
                ? "04 上端"
                : i === 4
                  ? "05 出站闸机"
                  : i === 6
                    ? "07/08 " + journeySuffix.exit_id.slice(4) + " 同层接续"
                    : "到达 · " + journeySuffix.destination,
            journeyNodes[i].position,
            i === 6,
            -17,
          );
        }
      }
    } // Optional route layer; facility geometry is independent.
    if (editEnabled && draft.length) {
      for (let i = 1; i < draft.length; i++) {
        const a = byId[draft[i - 1]],
          b = byId[draft[i]];
        if (objectVisible(a) && objectVisible(b)) path([a.pos, b.pos], series(6), 2.5, [6, 4]);
      }
    }
    const points = visible.filter((o) => ["exit", "point", "destination"].includes(o.kind));
    points.forEach((o) => {
      if (o.kind !== "exit" && o.id !== selected) return;
      mark(
        o.pos,
        series(o.cat),
        o.kind === "exit" ? "square" : "dot",
        o.id === selected ? 6 : o.kind === "exit" ? 4 : 2.5,
      );
      hits.push({ id: o.id, p: screen(o.pos) });
    });
    floors.forEach((f) => hits.push({ id: f.id, p: screen(f.pos) }));
    rails.forEach((p) => hits.push({ id: p.id, p: screen(p.pos) }));
    if (objectVisible(selectedObj) && selectedObj.pos) {
      if (selectedObj.poly)
        path([...selectedObj.poly, selectedObj.poly[0]], series(selectedObj.cat), 2, [], 0.85);
      const a = mark(selectedObj.pos, series(selectedObj.cat), "dot", 4);
      ctx.strokeStyle = series(selectedObj.cat);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(a[0], a[1], 8, 0, Math.PI * 2);
      ctx.stroke();
      label(selectedObj.short, selectedObj.pos, true, -22);
    }
    // Always prioritize the four exit labels; show detailed device labels only for the selected object.
    points
      .filter((o) => o.kind === "exit" && o.id !== selected)
      .forEach((o) => label(o.short, o.pos, true, -12));
    if (floors.some((f) => f.id === "NC") && w > 480) label("候车室 · 示意", [0, 11.74, 0], false);
    const activeFloors = new Set([
      "NP",
      "NC",
      "E3",
      "WX",
      ...journeyNodes.map((n) => n.regional_floor_hint),
    ]);
    floors
      .filter((f) => f.id !== selected && (activeFloors.has(f.id) || $("floor").value !== "all"))
      .sort((a, b) => b.y - a.y)
      .forEach((f) => {
        if (
          w < 480 &&
          $("floor").value === "all" &&
          !["E3", "WX", "NP", "M46P", "M5", "E1"].includes(f.id)
        )
          return;
        let p = f.pos;
        if (f.id === "NP") p = [0, f.y, Math.max(...f.poly.map((p) => p[2]))];
        else if (f.id === "NC") p = [0, f.y, -86];
        else p = mid([f.poly[0], f.poly[1]]);
        label(f.short, p, false, 0);
      });
    if (view === "rail" || $("floor").value === "NP") {
      rails
        .filter((p) => p.id !== selected)
        .forEach((p) => {
          const end = [p.pos[0], p.pos[1], Math.max(...p.poly.map((q) => q[2]))];
          label(p.id, end, false, 15);
        });
    }
    if ($("floor").value !== "all" && w > 480)
      points
        .filter((o) => o.kind === "destination")
        .forEach((o) => label(o.short, o.pos, false, 15));
    researchOverlay?.render({ ctx, screen, path, label });
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = col("foreground");
    ctx.fillText(
      view === "assembly"
        ? "整体关系 · 国铁位置为待核拼合"
        : view === "rail"
          ? "国铁真实几何 · 编号为候选编号"
          : "接驳层级 · 原始路线坐标",
      8,
      20,
    );
    const ox = w - 56,
      oy = h - 30;
    for (const [name, dx, dz] of [
      [view === "rail" ? "横" : "东", 1, 0],
      [view === "rail" ? "纵" : "南", 0, 1],
    ]) {
      const end = [ox + (dx * cy - dz * sy) * 22, oy + (dx * sy + dz * cy) * sp * 22];
      line2([ox, oy], end, col("muted-foreground"));
      ctx.fillStyle = col("foreground");
      ctx.textAlign = "center";
      ctx.fillText(name, end[0] + (dx * cy - dz * sy) * 9, end[1] + 12);
    }
    ctx.textAlign = "left";
    ctx.fillStyle = col("muted-foreground");
    ctx.fillText(view === "rail" ? "方向未与地理方位配准" : "方向按 A/B 出口关系建立", 8, h - 15);
    $("spacing-value").textContent = spread.toFixed(1);
    $("caption").textContent =
      (spread === 1
        ? "三轴等比例 · 层高未放大。"
        : "分层展开 · 竖向 " + spread.toFixed(1) + "×，仅供看清楼层。") +
      " 连廊末端即出站口，与城市端同层接续。";
    $("scale-note").textContent =
      view === "rail"
        ? "国铁模型内长度单位为米；不代表现场实测。"
        : "地图保持源坐标；上方米数为初步情景估计，CSV 尺度及跨模型位置仍待现场校准。";
    $("true-scale").setAttribute("aria-pressed", String(spread === 1));
    $("explode").setAttribute("aria-pressed", String(spread !== 1));
    if (view === "rail" && $("camera").value === "top") {
      const x = 20,
        y = h - 44,
        L = 50 * scale;
      line2([x, y], [x + L, y], col("foreground"));
      line2([x, y - 4], [x, y + 4], col("foreground"));
      line2([x + L, y - 4], [x + L, y + 4], col("foreground"));
      ctx.textAlign = "left";
      ctx.fillText("50 模型米", x, y - 8);
    }
  }

  $("edit-enabled").addEventListener("change", () => {
    editEnabled = $("edit-enabled").checked;
    updateDetail();
    draw();
    $("status").textContent = editEnabled
      ? "草稿模式已开启，草稿不属于完整出行链。"
      : "草稿已隐藏，仅显示选定完整出行链。";
  });
  $("clear-draft").addEventListener("click", () => {
    if (!editEnabled) return;
    draft = [];
    updateDetail();
    draw();
    save();
  });
  function resetView() {
    yaw = -0.62;
    pitch = 0.42;
    $("spacing").value = 0;
    $("camera").value = "oblique";
    $("scene").value = "assembly";
    $("floor").value = "all";
    editEnabled = false;
    $("edit-enabled").checked = false;
    refreshOptions();
    updateDetail();
    draw();
    save();
  }
  $("reset-view").addEventListener("click", resetView);
  $("true-scale").addEventListener("click", () => {
    $("spacing").value = 0;
    draw();
    save();
  });
  $("explode").addEventListener("click", () => {
    $("spacing").value = 37.5;
    draw();
    save();
  });
  $("top-view").addEventListener("click", () => {
    $("spacing").value = 0;
    $("camera").value = "top";
    yaw = 0;
    pitch = Math.PI / 2;
    draw();
    save();
  });

  function changeScene() {
    refreshOptions();
    updateDetail();
    draw();
    save();
  }
  $("scene").addEventListener("change", changeScene);
  $("floor").addEventListener("change", () => {
    if ($("floor").value !== "all") selected = $("floor").value;
    changeScene();
  });
  $("object").addEventListener("change", () => choose($("object").value));
  for (const [name, step] of [
    ["prev", -1],
    ["next", 1],
  ])
    $(name).addEventListener("click", () => {
      const opts = [...$("object").options];
      const i = opts.findIndex((o) => o.value === selected);
      choose(opts[(i + step + opts.length) % opts.length].value);
    });
  $("spacing").addEventListener("input", draw);
  $("spacing").addEventListener("change", save);
  $("camera").addEventListener("change", () => {
    const v = $("camera").value;
    [yaw, pitch] =
      v === "top"
        ? [0, Math.PI / 2]
        : v === "east"
          ? [Math.PI / 2, 0.22]
          : v === "west"
            ? [-Math.PI / 2, 0.22]
            : [-0.62, 0.42];
    draw();
    save();
  });
  const record = () => {
    reviews[selected] = { verdict: $("verdict").value, note: $("note").value };
    save();
  };
  $("verdict").addEventListener("change", record);
  $("note").addEventListener("change", record);
  $("add").addEventListener("click", () => {
    if (!editEnabled) return;
    if (!byId[selected].pos) {
      $("status").textContent = "此设施尚无坐标，先核对位置后再接入空间流线。";
      return;
    }
    if (draft.length >= 24) {
      $("status").textContent = "当前草稿最多24处，可分段核对。";
      return;
    }
    if (draft.at(-1) !== selected) draft.push(selected);
    updateDetail();
    draw();
    save();
  });
  $("undo").addEventListener("click", () => {
    if (!editEnabled) return;
    draft.pop();
    updateDetail();
    draw();
    save();
  });
  c.addEventListener("pointerdown", (e) => {
    drag = { x: e.clientX, y: e.clientY, yaw, pitch, moved: false };
    c.setPointerCapture(e.pointerId);
  });
  c.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x,
      dy = e.clientY - drag.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
    if (!drag.moved) return;
    yaw = drag.yaw + dx * 0.008;
    pitch = Math.max(0.05, Math.min(1.53, drag.pitch + dy * 0.006));
    $("camera").value = "oblique";
    draw();
  });
  c.addEventListener("pointerup", (e) => {
    if (!drag) return;
    if (!drag.moved) {
      const r = c.getBoundingClientRect(),
        x = e.clientX - r.left,
        y = e.clientY - r.top;
      if (researchOverlay?.hit(x, y)) {
        drag = null;
        return;
      }
      const j = journeyHits
        .map((o) => ({ ...o, d: Math.hypot(o.p[0] - x, o.p[1] - y) }))
        .sort((a, b) => a.d - b.d)[0];
      if (j?.d < 13) selectJourneyNode(j.index);
      else {
        const hit = hits
          .map((o) => ({ ...o, d: Math.hypot(o.p[0] - x, o.p[1] - y) }))
          .sort((a, b) => a.d - b.d)[0];
        if (hit?.d < 22 && [...$("object").options].some((o) => o.value === hit.id)) choose(hit.id);
      }
    } else save();
    drag = null;
  });
  c.addEventListener("pointercancel", () => {
    drag = null;
  });

  function stageSelect() {
    const mode = $("mode").value,
      stage = $("stage").value;
    if (stage === "overview") return;
    if (journeySuffix?.mode !== mode) {
      const s = J.suffixes.find((s) => s.mode === mode);
      if (s) {
        $("journey-route").value = s.id;
        buildJourney();
      }
    }
    $("scene").value = "assembly";
    $("floor").value = "all";
    refreshOptions();
    updateDetail();
    const indexes = {
      alight: 0,
      upper: 3,
      gate: 4,
      corridor: 5,
      exit: 6,
      handoff: 7,
      destination: journeyNodes.length - 1,
    };
    const facility = journeyNodes.findIndex((n, i) => i >= 8 && n.facility_id);
    selectJourneyNode(stage === "facility" ? Math.max(8, facility) : (indexes[stage] ?? 0));
    $("status").textContent =
      "当前完整链 " + journeySuffix.id + "；04上端→05闸机→06连廊→07/08出口与CSV同层接续。";
    save();
  }
  $("stage").addEventListener("change", stageSelect);
  $("mode").addEventListener("change", stageSelect);
  function restore(state) {
    const p = state?.privateContent || {};
    if (state?.modelContent?.version && state.modelContent.version !== D.version) return;
    if (p.view_revision === 6 && ["assembly", "transfer", "rail"].includes(p.scene))
      $("scene").value = p.scene;
    selected = byId[p.selected] ? p.selected : "E3";
    reviews = { ...(p.reviews || {}) };
    draft = Array.isArray(p.draft) ? p.draft.filter((id) => byId[id]?.pos).slice(0, 24) : [];
    if ([...$("stage").options].some((o) => o.value === p.stage)) $("stage").value = p.stage;
    if (D.chains.some((ch) => ch.mode === p.mode)) $("mode").value = p.mode;
    if (p.view_revision === 6 && Number.isFinite(p.spacing))
      $("spacing").value = Math.max(0, Math.min(100, p.spacing));
    if (p.view_revision === 6 && Number.isFinite(p.yaw)) yaw = p.yaw;
    if (p.view_revision === 6 && Number.isFinite(p.pitch))
      pitch = Math.max(0.05, Math.min(Math.PI / 2, p.pitch));
    if (p.view_revision === 6 && ["oblique", "east", "west", "top"].includes(p.camera))
      $("camera").value = p.camera;
    refreshOptions();
    if (p.view_revision === 6 && [...$("floor").options].some((o) => o.value === p.floor)) {
      $("floor").value = p.floor;
      refreshOptions();
    }
    updateDetail();
    refreshColors();
    draw();
  }

  J.platforms.forEach((p) => option($("journey-platform"), p.id, p.id + " · 站台候选"));
  J.suffixes.forEach((s) =>
    option(
      $("journey-route"),
      s.id,
      s.id +
        " · " +
        s.exit_id.slice(4) +
        " → " +
        s.destination +
        (s.geometry === "source_csv" ? "" : " · 补画"),
    ),
  );
  $("journey-platform").value = "P06";
  $("journey-route").value = "M01-01";
  $("journey-platform").addEventListener("change", () => buildJourney());
  $("journey-route").addEventListener("change", () => buildJourney());
  $("journey-alight").addEventListener("input", () => buildJourney(false));
  $("journey-prev").onclick = () => selectJourneyNode(journeyIndex - 1);
  $("journey-next").onclick = () => selectJourneyNode(journeyIndex + 1);
  researchOverlay = window.StationResearchOverlay?.create({
    root,
    D,
    J,
    redraw: draw,
    selectNode: selectJourneyNode,
  });
  window.stationJourney = {
    getCurrentPath: () => copyJourney(journeySnapshot()),
    getSummary: () => copyJourney(J.summary),
    select: selectJourney,
    getResearchSnapshot: () => researchOverlay?.getResearchSnapshot(),
    selectFacility: (id) => researchOverlay?.selectFacility(id),
  };
  buildJourney(false);

  new ResizeObserver(draw).observe(root);
  new MutationObserver(() => {
    refreshColors();
    draw();
  }).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["class", "style", "data-theme"],
  });
  window.addEventListener("message", (e) => {
    if (e.source !== window.parent) return;
    if (e.data?.type === "station-review-restore") restore(e.data.state);
    if (e.data?.type === "station-review-save-error")
      $("status").textContent = "当前浏览器未能保存本次校对，请保留在本机研究记录中。";
  });
  let saved = null;
  try {
    const raw =
      localStorage.getItem("szb:station-reviews:v1") ||
      localStorage.getItem("codex:visualization-widget-state-v2:" + JSON.stringify(["/", ""])) ||
      localStorage.getItem(
        "codex:visualization-widget-state-v2:" + JSON.stringify(["/index.html", ""]),
      );
    saved = raw ? JSON.parse(raw) : null;
  } catch {}
  restore(saved);
  const params = new URLSearchParams(location.search);
  selectJourney({
    route: params.get("route") || "M01-01",
    platform: params.get("platform") || "P06",
    z: params.get("z") || 0,
  });
  if (saved?.privateContent?.view_revision !== 6 && saved)
    $("status").textContent = "已恢复等比例视图并隐藏历史草稿；校对备注与草稿记录仍保留。";
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.type !== "station-journey-selected") return;
    const d = e.data;
    if (!/^[A-Z]\d{2}-\d{2}$/.test(d.route) || !/^P\d{2}$/.test(d.platform)) return;
    const u = new URL(location.href);
    u.searchParams.set("route", d.route);
    u.searchParams.set("platform", d.platform);
    u.searchParams.set("z", d.z);
    history.replaceState(null, "", u);
  });
})();
