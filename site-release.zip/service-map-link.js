(function () {
  "use strict";
  const link = document.getElementById("s3-service-entry");
  if (!link) return;
  function sync() {
    const q = new URLSearchParams(location.search),
      p = new URLSearchParams({
        route: q.get("route") || "M01-01",
        platform: q.get("platform") || "P06",
        z: q.get("z") || "0",
      });
    link.href = "service-lab.html?" + p;
  }
  window.addEventListener("message", (e) => {
    if (
      e.source === window &&
      e.origin === location.origin &&
      e.data?.type === "station-journey-selected"
    )
      setTimeout(sync, 0);
  });
  sync();
})();
