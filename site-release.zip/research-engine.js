/*
 * Route recommendation and evidence checks for the local research workbench.
 * Distances are model estimates. Time inputs describe a scenario, not a forecast.
 * This module performs no I/O and never persists the locally loaded dataset.
 */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  }
  if (root) {
    root.StationResearch = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '1.0.0';
  const COMPONENT_KEYS = [
    'walkSec', 'verticalSec', 'queueSec',
    'processingSec', 'wayfindingSec', 'waitSec'
  ];
  const WEIGHT_KEYS = ['time', 'distance', 'vertical', 'uncertainty'];
  const ROAD_MODES = new Set([
    '公交', '出租车', '网约车', '私家车', '低空',
    'bus', 'taxi', 'ride-hailing', 'car', 'air'
  ]);
  const METRO_MODES = new Set(['地铁', 'metro']);
  const has = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
  const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const finite = value => typeof value === 'number' && Number.isFinite(value);
  const nonnegative = value => finite(value) && value >= 0;
  const positive = value => finite(value) && value > 0;
  const text = value => typeof value === 'string' && value.trim() ? value.trim() : null;
  const unique = values => [...new Set(values)];
  const safeMap = () => Object.create(null);

  function sumOrNull(values) {
    if (!values.every(nonnegative)) return null;
    const total = values.reduce((sum, value) => sum + value, 0);
    return nonnegative(total) ? total : null;
  }

  // Hours are deliberately unbounded: 24:10 belongs to the same service plan.
  function parseClock(value) {
    if (nonnegative(value)) return value;
    if (typeof value !== 'string') return null;
    const match = /^\s*(\d+):([0-5]\d)(?::([0-5]\d)(\.\d{1,3})?)?\s*$/.exec(value);
    if (!match) return null;
    const seconds = Number(match[1]) * 3600 + Number(match[2]) * 60
      + Number(match[3] || 0) + Number(match[4] || 0);
    return nonnegative(seconds) ? seconds : null;
  }

  function normalizeLine(value) {
    if (Number.isInteger(value) && value > 0) return value;
    if (typeof value !== 'string' || !/^\d+$/.test(value.trim())) return null;
    const line = Number(value);
    return Number.isSafeInteger(line) && line > 0 ? line : null;
  }

  function routeLine(route) {
    if (!route) return null;
    const explicit = normalizeLine(route.line);
    const destination = text(route.destination) || '';
    const match = /^(\d+)号线$/.exec(destination)
      || /^(?:Metro\s+)?Line\s+(\d+)$/i.exec(destination);
    const named = match ? normalizeLine(match[1]) : null;
    if (explicit !== null && named !== null && explicit !== named) return null;
    return explicit !== null ? explicit : named;
  }

  function makeAudit() {
    const issues = [];
    const byCode = safeMap();
    return {
      issues,
      counts: safeMap(),
      add(severity, code, message, ref) {
        let issue = byCode[code];
        if (!issue) {
          issue = { severity, code, message, count: 0, examples: [] };
          byCode[code] = issue;
          issues.push(issue);
        }
        issue.count += 1;
        if (text(ref) && issue.examples.length < 6 && !issue.examples.includes(ref)) {
          issue.examples.push(ref);
        }
      }
    };
  }

  function indexRecords(input, idField, audit, kind) {
    const result = [];
    const index = safeMap();
    if (!Array.isArray(input)) {
      audit.add('error', kind + '_array_missing', kind + ' 应为记录数组。');
      return { result, index };
    }
    for (const record of input) {
      const id = isObject(record) ? text(record[idField]) : null;
      if (!id) {
        audit.add('error', kind + '_id_missing', kind + ' 存在缺少标识的记录。');
        continue;
      }
      if (has(index, id)) {
        audit.add('error', kind + '_id_duplicate', kind + ' 存在重复标识；保留第一条。', id);
        continue;
      }
      index[id] = record;
      result.push(record);
    }
    return { result, index };
  }

  function indexObject(input, idField, audit, kind) {
    const index = safeMap();
    if (!isObject(input)) {
      audit.add('error', kind + '_object_missing', kind + ' 应为按标识索引的对象。');
      return index;
    }
    for (const [key, record] of Object.entries(input)) {
      if (!isObject(record) || !text(record[idField]) || record[idField] !== key) {
        audit.add('error', kind + '_key_mismatch', kind + ' 对象键与记录标识不一致。', key);
        continue;
      }
      index[key] = record;
    }
    return index;
  }

  function orderedRange(estimate, lower, upper) {
    return nonnegative(estimate) && nonnegative(lower) && nonnegative(upper)
      && lower <= estimate && estimate <= upper;
  }

  function validateEdge(edge, audit) {
    const errors = [];
    if (!text(edge.from_node) || !text(edge.to_node)) errors.push('edge_endpoints_missing');
    if (!nonnegative(edge.estimated_length_m)) errors.push('edge_distance_missing');
    if (!nonnegative(edge.walk_length_m)) errors.push('edge_walk_missing');
    if (!['walk', 'vertical', 'semantic'].includes(edge.time_component)) {
      errors.push('edge_component_unknown');
    }
    if (nonnegative(edge.estimated_length_m)
      && !orderedRange(edge.estimated_length_m, edge.lower_m, edge.upper_m)) {
      audit.add('warning', 'edge_interval_invalid', '部分边缺少有效距离区间。', edge.edge_id);
    }
    if (nonnegative(edge.walk_length_m)
      && !orderedRange(edge.walk_length_m, edge.walk_lower_m, edge.walk_upper_m)) {
      audit.add('warning', 'edge_walk_interval_invalid', '部分步行边缺少有效距离区间。', edge.edge_id);
    }
    if (!nonnegative(edge.measured_length_m)) {
      audit.add('info', 'distance_not_measured', '部分距离为模型估计，尚无实测长度。', edge.edge_id);
    }
    for (const code of errors) {
      audit.add('error', code, '部分边的必要几何或时间分类字段无效。', edge.edge_id);
    }
    return errors;
  }

  function validateChain(chain, dataset, audit) {
    const errors = [];
    const route = dataset.routeById[chain.route_id];
    if (chain.chain_id !== chain.platform_id + '__' + chain.route_id) {
      errors.push('chain_identity_mismatch');
    }
    if (!route) errors.push('chain_route_missing');
    if (!dataset.platformById[chain.platform_id]) errors.push('chain_platform_missing');
    if (route && route.exit_id !== chain.exit_id) errors.push('chain_exit_mismatch');
    if (!Array.isArray(chain.edge_ids) || chain.edge_ids.length === 0) {
      errors.push('chain_edges_missing');
    } else {
      if (new Set(chain.edge_ids).size !== chain.edge_ids.length) errors.push('chain_repeated_edge');
      let previous = null;
      for (const edgeId of chain.edge_ids) {
        const edge = dataset.edges[edgeId];
        if (!edge) {
          errors.push('chain_edge_missing');
          previous = null;
          continue;
        }
        if (dataset.edgeIssues[edgeId].length) errors.push('chain_edge_invalid');
        if (previous && previous.to_node !== edge.from_node) errors.push('chain_disconnected');
        previous = edge;
      }
    }
    const distance = isObject(chain.distance) ? chain.distance : {};
    const walk = isObject(chain.walk) ? chain.walk : {};
    const vertical = isObject(chain.vertical) ? chain.vertical : {};
    if (!nonnegative(distance.estimate_m)) errors.push('chain_distance_missing');
    if (!nonnegative(walk.estimate_m)) errors.push('chain_walk_missing');
    if (!Number.isInteger(vertical.count) || vertical.count < 0) errors.push('chain_vertical_missing');
    if (distance.complete_as_estimate !== true
      || (Array.isArray(distance.unresolved) && distance.unresolved.length > 0)) {
      errors.push('chain_distance_incomplete');
    }
    if (!orderedRange(distance.estimate_m, distance.lower_m, distance.upper_m)) {
      audit.add('warning', 'chain_interval_invalid', '部分完整链缺少有效距离区间。', chain.chain_id);
    }
    if (!orderedRange(walk.estimate_m, walk.lower_m, walk.upper_m)) {
      audit.add('warning', 'chain_walk_interval_invalid', '部分完整链缺少有效步行距离区间。', chain.chain_id);
    }
    if (Array.isArray(chain.edge_ids) && !errors.includes('chain_edge_missing')) {
      const selected = chain.edge_ids.map(id => dataset.edges[id]);
      const edgeDistance = sumOrNull(selected.map(edge => edge.estimated_length_m));
      const edgeWalk = sumOrNull(selected.map(edge => edge.walk_length_m));
      // Imported totals are rounded to four decimals; a centimetre tolerates that rounding.
      if (edgeDistance !== null && nonnegative(distance.estimate_m)
        && Math.abs(edgeDistance - distance.estimate_m) > 0.01) {
        errors.push('chain_distance_sum_mismatch');
      }
      if (edgeWalk !== null && nonnegative(walk.estimate_m)
        && Math.abs(edgeWalk - walk.estimate_m) > 0.01) {
        errors.push('chain_walk_sum_mismatch');
      }
      const verticalCount = selected.filter(edge => edge.time_component === 'vertical').length;
      if (verticalCount !== vertical.count) errors.push('chain_vertical_count_mismatch');
      const adjustment = chain.alight_adjustment;
      if (isObject(adjustment)) {
        const first = dataset.edges[adjustment.first_edge_id];
        if (!first || chain.edge_ids[0] !== adjustment.first_edge_id || first.time_component !== 'walk') {
          errors.push('chain_alight_edge_mismatch');
        } else if (!nonnegative(adjustment.first_edge_default_m)
          || Math.abs(first.estimated_length_m - adjustment.first_edge_default_m) > 0.01
          || Math.abs(first.walk_length_m - adjustment.first_edge_default_m) > 0.01) {
          errors.push('chain_alight_default_mismatch');
        }
      }
    }
    if (chain.conflict === true) {
      audit.add('warning', 'geometry_conflict', '部分出行链具有待核实的空间冲突。', chain.chain_id);
    }
    if (chainAccessibility(chain, dataset.edges) === 'unknown') {
      audit.add('warning', 'accessibility_unverified', '无障碍连续可达性尚未获得完整证据。', chain.chain_id);
    }
    for (const code of unique(errors)) {
      audit.add('error', code, '完整链的引用、连通性或汇总数据需要核对。', chain.chain_id);
    }
    return unique(errors);
  }

  function normalizePlans(input, audit) {
    const indexed = indexRecords(input, 'id', audit, 'plans');
    const plans = [];
    const planById = safeMap();
    for (const source of indexed.result) {
      const line = normalizeLine(source.line);
      if (line === null) {
        audit.add('error', 'plan_line_missing', '运行计划缺少有效线路号。', source.id);
        continue;
      }
      if (!Array.isArray(source.events)) {
        audit.add('error', 'plan_events_missing', '运行计划缺少时刻记录数组。', source.id);
        continue;
      }
      const events = [];
      const duplicateTimes = new Set();
      for (const event of source.events) {
        if (!isObject(event) || !nonnegative(event.departureSec)) {
          audit.add('warning', 'plan_departure_invalid', '已跳过缺少有效出发时间的记录。', source.id);
          continue;
        }
        if (event.arrivalSec !== null && event.arrivalSec !== undefined
          && (!nonnegative(event.arrivalSec) || event.arrivalSec > event.departureSec)) {
          audit.add('warning', 'plan_arrival_invalid', '已跳过到达时间晚于出发时间等异常记录。', source.id);
          continue;
        }
        if (duplicateTimes.has(event.departureSec)) {
          audit.add('warning', 'plan_duplicate_departure', '同一计划出现重复发车时刻，需核对原表。', source.id);
        }
        duplicateTimes.add(event.departureSec);
        events.push(event);
      }
      events.sort((left, right) => left.departureSec - right.departureSec);
      const plan = Object.assign({}, source, { line, events });
      plans.push(plan);
      planById[plan.id] = plan;
      if (!text(source.validFrom) || !text(source.validTo)) {
        audit.add('warning', 'plan_applicability_unverified', '计划适用日期不完整，需手动确认；不自动跨日重复。', source.id);
      }
      if (!events.length) audit.add('warning', 'plan_empty', '运行计划没有有效发车时刻。', source.id);
    }
    return { plans, planById };
  }

  function normalizeBundle(bundle) {
    const audit = makeAudit();
    const source = isObject(bundle) ? bundle : {};
    const context = isObject(source.routeContext) ? source.routeContext : {};
    if (!isObject(source.routeContext)) {
      audit.add('error', 'route_context_missing', '本机研究包缺少 routeContext。');
    }
    const routes = indexRecords(context.routes, 'id', audit, 'routes');
    const platforms = indexRecords(context.platforms, 'id', audit, 'platforms');
    const edges = indexObject(context.edges, 'edge_id', audit, 'edges');
    const chains = indexObject(context.chains, 'chain_id', audit, 'chains');
    const metro = isObject(source.serviceData) && isObject(source.serviceData.metro)
      ? source.serviceData.metro : {};
    const timetables = normalizePlans(metro.plans, audit);
    const dataset = {
      routes: routes.result,
      routeById: routes.index,
      platforms: platforms.result,
      platformById: platforms.index,
      edges,
      chains,
      plans: timetables.plans,
      planById: timetables.planById,
      edgeIssues: safeMap(),
      chainIssues: safeMap(),
      audit: { issues: audit.issues, counts: audit.counts }
    };
    for (const route of dataset.routes) {
      if (!text(route.destination) || !text(route.mode) || !text(route.exit_id)) {
        audit.add('error', 'route_fields_missing', '路线缺少目的地、接驳方式或出口字段。', route.id);
      }
    }
    for (const edge of Object.values(edges)) {
      dataset.edgeIssues[edge.edge_id] = validateEdge(edge, audit);
    }
    for (const chain of Object.values(chains)) {
      dataset.chainIssues[chain.chain_id] = validateChain(chain, dataset, audit);
    }
    const chainList = Object.values(chains);
    Object.assign(audit.counts, {
      routes: dataset.routes.length,
      platforms: dataset.platforms.length,
      chains: chainList.length,
      edges: Object.keys(edges).length,
      plans: dataset.plans.length,
      events: dataset.plans.reduce((sum, plan) => sum + plan.events.length, 0),
      invalidChains: chainList.filter(chain => dataset.chainIssues[chain.chain_id].length).length,
      conflictChains: chainList.filter(chain => chain.conflict === true).length,
      measuredEdges: Object.values(edges).filter(edge => nonnegative(edge.measured_length_m)).length,
      verifiedAccessibleChains: chainList.filter(chain => chainAccessibility(chain, edges) === 'verified').length,
      missingPlatformRoutePairs: Math.max(0, dataset.routes.length * dataset.platforms.length - chainList.length),
      errors: audit.issues.filter(issue => issue.severity === 'error').reduce((sum, issue) => sum + issue.count, 0),
      warnings: audit.issues.filter(issue => issue.severity === 'warning').reduce((sum, issue) => sum + issue.count, 0)
    });
    return dataset;
  }

  function defaultOptions() {
    return {
      platformId: null,
      routeId: null,
      startSec: 8 * 3600,
      alightZ: 0,
      speedMps: 1.2,
      verticalPerTransitionSec: 45,
      queueSec: 30,
      processingSec: 30,
      wayfindingSec: 20,
      roadWaitSec: 180,
      bufferSec: 30,
      metroPlanId: null,
      wheelchair: false,
      excludeConflicts: true,
      blockedExits: [],
      blockedEdges: [],
      maxWalkM: null,
      weights: { time: 0.55, distance: 0.25, vertical: 0.1, uncertainty: 0.1 },
      distanceChoice: 'estimate',
      walkDistanceOverrideM: null
    };
  }

  function mergeOptions(input) {
    const defaults = defaultOptions();
    const supplied = isObject(input) ? input : {};
    const options = Object.assign({}, defaults, supplied);
    options.weights = Object.assign({}, defaults.weights, isObject(supplied.weights) ? supplied.weights : {});
    return options;
  }

  function emptyMetrics(reason) {
    return {
      walkM: null, walkLowerM: null, walkUpperM: null,
      distanceM: null, distanceLowerM: null, distanceUpperM: null,
      verticalCount: null, conflict: false,
      missing: [reason], warnings: [], edgeIds: [], chainId: null
    };
  }

  function chainMetrics(dataset, platformId, routeId, alightZ) {
    if (!dataset || !dataset.chains) return emptyMetrics('dataset_missing');
    const key = String(platformId) + '__' + String(routeId);
    const chain = dataset.chains[key];
    if (!chain) return emptyMetrics('chain_missing');
    const structural = dataset.chainIssues[key] || [];
    const walk = chain.walk || {};
    const distance = chain.distance || {};
    const result = {
      walkM: nonnegative(walk.estimate_m) ? walk.estimate_m : null,
      walkLowerM: nonnegative(walk.lower_m) ? walk.lower_m : null,
      walkUpperM: nonnegative(walk.upper_m) ? walk.upper_m : null,
      distanceM: nonnegative(distance.estimate_m) ? distance.estimate_m : null,
      distanceLowerM: nonnegative(distance.lower_m) ? distance.lower_m : null,
      distanceUpperM: nonnegative(distance.upper_m) ? distance.upper_m : null,
      verticalCount: chain.vertical && Number.isInteger(chain.vertical.count) && chain.vertical.count >= 0
        ? chain.vertical.count : null,
      conflict: chain.conflict === true,
      missing: structural.slice(),
      warnings: [],
      edgeIds: Array.isArray(chain.edge_ids) ? chain.edge_ids.slice() : [],
      chainId: key,
      metricStatus: text(chain.metric_status),
      rangeKind: text(chain.range_kind)
    };
    if (!orderedRange(result.walkM, result.walkLowerM, result.walkUpperM)) {
      result.walkLowerM = null;
      result.walkUpperM = null;
      result.warnings.push('步行距离上下界不完整或顺序无效。');
    }
    if (!orderedRange(result.distanceM, result.distanceLowerM, result.distanceUpperM)) {
      result.distanceLowerM = null;
      result.distanceUpperM = null;
      result.warnings.push('总距离上下界不完整或顺序无效。');
    }
    const adjustment = chain.alight_adjustment;
    const z = alightZ === undefined ? 0 : alightZ;
    if (!finite(z)) {
      result.missing.push('alight_position_invalid');
    } else if (isObject(adjustment)) {
      const valid = finite(adjustment.target_platform_z)
        && positive(adjustment.metres_per_z_unit)
        && nonnegative(adjustment.first_edge_default_m)
        && nonnegative(adjustment.lower_multiplier)
        && nonnegative(adjustment.upper_multiplier)
        && adjustment.lower_multiplier <= 1 && adjustment.upper_multiplier >= 1;
      if (!valid) {
        result.missing.push('alight_adjustment_invalid');
      } else if ((finite(adjustment.platform_z_min) && z < adjustment.platform_z_min)
        || (finite(adjustment.platform_z_max) && z > adjustment.platform_z_max)) {
        result.missing.push('alight_position_outside_platform');
      } else {
        const first = Math.abs(adjustment.target_platform_z - z) * adjustment.metres_per_z_unit;
        const change = first - adjustment.first_edge_default_m;
        for (const keyName of ['walkM', 'distanceM']) {
          if (result[keyName] !== null) result[keyName] += change;
        }
        for (const keyName of ['walkLowerM', 'distanceLowerM']) {
          if (result[keyName] !== null) result[keyName] += change * adjustment.lower_multiplier;
        }
        for (const keyName of ['walkUpperM', 'distanceUpperM']) {
          if (result[keyName] !== null) result[keyName] += change * adjustment.upper_multiplier;
        }
        result.warnings.push('下车位置为模型纵向坐标，尚未对应真实车厢或车门。');
      }
    } else if (z !== 0) {
      result.missing.push('alight_adjustment_missing');
    }
    for (const name of ['walkM', 'distanceM', 'verticalCount']) {
      if (!nonnegative(result[name])) result.missing.push(name + '_missing');
    }
    if (result.missing.length) {
      // Invalid or disconnected geometry cannot yield an apparently complete time.
      result.walkM = null;
      result.walkLowerM = null;
      result.walkUpperM = null;
      result.distanceM = null;
      result.distanceLowerM = null;
      result.distanceUpperM = null;
    }
    result.missing = unique(result.missing);
    result.warnings.push('距离区间用于敏感性分析，不是统计置信区间。');
    return result;
  }

  /* Optional future evidence schema: accessibility.wheelchair + evidence.
   * An elevator symbol, a facility name, or absence of a stairs label is not proof.
   */
  function explicitAccessibility(record) {
    if (!isObject(record)) return 'unknown';
    const value = isObject(record.accessibility) ? record.accessibility : {};
    if (value.wheelchair === 'blocked' || record.wheelchair_accessible === false) return 'blocked';
    if (['stairs', 'stair', '楼梯'].includes(record.facility_type)) return 'blocked';
    if (value.wheelchair === 'verified' && text(value.evidence)) return 'verified';
    if (record.wheelchair_accessible === true && text(record.wheelchair_evidence)) return 'verified';
    return 'unknown';
  }

  function chainAccessibility(chain, edges) {
    if (!isObject(chain) || !Array.isArray(chain.edge_ids) || !chain.edge_ids.length) return 'unknown';
    const statuses = chain.edge_ids.map(id => explicitAccessibility(edges[id]));
    if (explicitAccessibility(chain) === 'blocked' || statuses.includes('blocked')) return 'blocked';
    if (chain.edge_ids.some(id => !edges[id])) return 'unknown';
    if (explicitAccessibility(chain) === 'verified') return 'verified';
    return statuses.every(status => status === 'verified') ? 'verified' : 'unknown';
  }

  function validateOptions(options) {
    const reasons = [];
    for (const key of [
      'startSec', 'verticalPerTransitionSec', 'queueSec', 'processingSec',
      'wayfindingSec', 'roadWaitSec', 'bufferSec'
    ]) {
      if (!nonnegative(options[key])) reasons.push(key + ' 必须是非负有限数值。');
    }
    if (!positive(options.speedMps)) reasons.push('步行速度必须大于零。');
    if (!finite(options.alightZ)) reasons.push('下车位置必须是有限坐标。');
    if (!['estimate', 'lower', 'upper'].includes(options.distanceChoice)) reasons.push('距离口径无效。');
    if (options.maxWalkM !== null && !nonnegative(options.maxWalkM)) reasons.push('最大步行距离无效。');
    if (options.walkDistanceOverrideM !== null && !nonnegative(options.walkDistanceOverrideM)) {
      reasons.push('模拟步行距离无效。');
    }
    if (!Array.isArray(options.blockedExits) || !Array.isArray(options.blockedEdges)) {
      reasons.push('封闭出口和封闭边应为标识数组。');
    }
    if (typeof options.wheelchair !== 'boolean' || typeof options.excludeConflicts !== 'boolean') {
      reasons.push('无障碍及冲突筛选项必须为布尔值。');
    }
    return reasons;
  }

  function nextDeparture(events, readySec, bufferSec) {
    if (!Array.isArray(events) || !nonnegative(readySec) || !nonnegative(bufferSec)) return null;
    const threshold = readySec + bufferSec;
    if (!nonnegative(threshold)) return null;
    let chosen = null;
    for (const event of events) {
      if (!event || !nonnegative(event.departureSec) || event.departureSec < threshold) continue;
      if (chosen === null || event.departureSec < chosen) chosen = event.departureSec;
    }
    return chosen;
  }

  function uncertaintyPenalty(dataset, metrics, accessibility) {
    const edgeList = metrics.edgeIds.map(id => dataset.edges[id]).filter(Boolean);
    const unmeasured = edgeList.length
      ? edgeList.filter(edge => !nonnegative(edge.measured_length_m)).length / edgeList.length : 1;
    const width = nonnegative(metrics.distanceM) && metrics.distanceM > 0
      && nonnegative(metrics.distanceLowerM) && nonnegative(metrics.distanceUpperM)
      ? (metrics.distanceUpperM - metrics.distanceLowerM) / metrics.distanceM : 1;
    // This is an explanatory cost, not a calibrated risk or probability.
    return unmeasured + Math.min(2, Math.max(0, width)) + (metrics.conflict ? 1 : 0)
      + (accessibility === 'unknown' ? 0.25 : 0);
  }

  function evaluateRoute(dataset, routeId, input) {
    const options = mergeOptions(input);
    const route = dataset && dataset.routeById && dataset.routeById[routeId];
    const metrics = chainMetrics(dataset, options.platformId, routeId, options.alightZ);
    const chain = dataset && dataset.chains && dataset.chains[metrics.chainId];
    const accessibility = chain ? chainAccessibility(chain, dataset.edges) : 'unknown';
    const result = {
      routeId,
      destination: route ? route.destination : null,
      exitId: route ? route.exit_id : null,
      mode: route ? route.mode : null,
      metrics,
      feasible: false,
      status: 'partial',
      reasons: [],
      warnings: metrics.warnings.slice(),
      components: Object.fromEntries(COMPONENT_KEYS.map(key => [key, null])),
      readySec: null,
      totalSec: null,
      departureSec: null,
      evidencePenalty: dataset ? uncertaintyPenalty(dataset, metrics, accessibility) : null,
      accessibility,
      selectedWalkM: null,
      boardingSlackSec: null,
      startSec: nonnegative(options.startSec) ? options.startSec : null
    };
    if (!route) {
      result.status = 'invalid';
      result.reasons.push('路线标识不存在。');
      return result;
    }
    const invalid = validateOptions(options);
    if (invalid.length) {
      result.status = 'invalid';
      result.reasons.push(...invalid);
      return result;
    }
    if (!text(route.destination) || !text(route.mode) || !text(route.exit_id)) {
      result.reasons.push('路线的目的地、方式或出口字段缺失。');
    }
    if (metrics.missing.length) result.reasons.push('空间数据不完整：' + metrics.missing.join('、'));
    const choiceKey = { estimate: 'walkM', lower: 'walkLowerM', upper: 'walkUpperM' }[options.distanceChoice];
    result.selectedWalkM = options.walkDistanceOverrideM !== null
      ? options.walkDistanceOverrideM : metrics[choiceKey];
    if (options.walkDistanceOverrideM !== null) result.warnings.push('步行时间使用随机试验抽样距离。');
    if (!nonnegative(result.selectedWalkM)) result.reasons.push('所选口径缺少有效步行距离。');
    if (nonnegative(result.selectedWalkM)) {
      result.components.walkSec = result.selectedWalkM / options.speedMps;
    }
    if (nonnegative(metrics.verticalCount)) {
      result.components.verticalSec = metrics.verticalCount * options.verticalPerTransitionSec;
    }
    for (const name of ['queueSec', 'processingSec', 'wayfindingSec']) {
      result.components[name] = options[name];
    }
    const preWait = sumOrNull(COMPONENT_KEYS.filter(key => key !== 'waitSec').map(key => result.components[key]));
    result.readySec = preWait === null ? null : sumOrNull([options.startSec, preWait]);
    if (METRO_MODES.has(route.mode)) {
      const plan = dataset.planById[options.metroPlanId];
      if (!plan) {
        result.reasons.push('请选择适用于该线路的运行计划。');
      } else if (routeLine(route) === null || routeLine(route) !== plan.line) {
        result.reasons.push('所选运行计划与接驳地铁线路不一致。');
      } else {
        result.warnings.push('运行计划的日期及方向需人工确认；未自动匹配运营日。');
        if (result.readySec !== null) {
          result.departureSec = nextDeparture(plan.events, result.readySec, options.bufferSec);
          if (result.departureSec === null) {
            result.status = 'unavailable';
            result.reasons.push('所选计划中没有满足准备时间及缓冲时间的后续班次。');
          } else {
            result.components.waitSec = result.departureSec - result.readySec;
            result.boardingSlackSec = result.departureSec - result.readySec - options.bufferSec;
          }
        }
      }
    } else if (ROAD_MODES.has(route.mode)) {
      result.components.waitSec = options.roadWaitSec;
      result.warnings.push('接驳候车时间为用户场景参数。');
    } else {
      result.reasons.push('接驳方式未定义，无法选择候车模型。');
    }
    const constraints = [];
    if (options.blockedExits.includes(route.exit_id)) constraints.push('出口已设为封闭：' + route.exit_id);
    const blocked = metrics.edgeIds.filter(id => options.blockedEdges.includes(id));
    if (blocked.length) constraints.push('路线包含封闭边：' + blocked.join('、'));
    if (options.maxWalkM !== null && nonnegative(result.selectedWalkM)
      && result.selectedWalkM > options.maxWalkM) constraints.push('超过所选距离口径的最大步行限制。');
    if (options.excludeConflicts && metrics.conflict) constraints.push('空间冲突尚未核实。');
    if (options.wheelchair && accessibility !== 'verified') {
      constraints.push(accessibility === 'blocked' ? '已知设施条件不满足轮椅通行。' : '缺少连续无障碍通行证据，严格筛选不予通过。');
    }
    const total = sumOrNull(Object.values(result.components));
    result.totalSec = result.reasons.length === 0 ? total : null;
    if (total === null && result.reasons.length === 0) result.reasons.push('时间计算包含缺失值或超出数值范围。');
    if (constraints.length) {
      result.reasons.push(...constraints);
      result.status = 'excluded';
    } else if (result.reasons.length === 0 && result.totalSec !== null) {
      result.feasible = true;
      result.status = 'complete';
    }
    result.warnings.push('排队、办理、垂直设施及寻路时间是场景假设，未使用容量或拥挤度模型。');
    result.warnings = unique(result.warnings);
    return result;
  }

  function normalizeWeights(input) {
    if (!isObject(input)) return null;
    const weights = {};
    for (const key of WEIGHT_KEYS) {
      if (!nonnegative(input[key])) return null;
      weights[key] = input[key];
    }
    const total = sumOrNull(Object.values(weights));
    if (total === null || total === 0) return null;
    for (const key of WEIGHT_KEYS) weights[key] /= total;
    return weights;
  }

  function objectives(result) {
    return {
      time: result.totalSec,
      distance: result.selectedWalkM,
      vertical: result.metrics.verticalCount,
      uncertainty: result.evidencePenalty
    };
  }

  function dominates(left, right) {
    const leftValues = objectives(left);
    const rightValues = objectives(right);
    return WEIGHT_KEYS.every(key => leftValues[key] <= rightValues[key])
      && WEIGHT_KEYS.some(key => leftValues[key] < rightValues[key]);
  }

  function recommend(dataset, input) {
    const options = mergeOptions(input);
    const selected = dataset && dataset.routeById && dataset.routeById[options.routeId];
    const response = { results: [], candidates: [], excluded: [], warnings: [] };
    if (!selected || !text(selected.destination) || !text(selected.mode)) {
      response.warnings.push('请选择具有明确目的地和接驳方式的基准路线。');
      return response;
    }
    const routes = dataset.routes.filter(route => route.destination === selected.destination && route.mode === selected.mode);
    response.candidates = routes.map(route => evaluateRoute(dataset, route.id, options));
    response.excluded = response.candidates.filter(result => !result.feasible);
    const feasible = response.candidates.filter(result => result.feasible);
    const weights = normalizeWeights(options.weights);
    if (!weights) {
      response.warnings.push('权重必须为非负有限数值且总和大于零。');
      return response;
    }
    if (!feasible.length) {
      response.warnings.push(options.wheelchair
        ? '当前约束下没有具有完整无障碍证据的可推荐路线。'
        : '当前数据、运行计划及约束下没有可完整计算的候选路线。');
      return response;
    }
    const extents = {};
    for (const key of WEIGHT_KEYS) {
      const values = feasible.map(result => objectives(result)[key]);
      extents[key] = { min: Math.min(...values), max: Math.max(...values) };
    }
    for (const result of feasible) {
      const values = objectives(result);
      const normalized = {};
      for (const key of WEIGHT_KEYS) {
        const extent = extents[key];
        normalized[key] = extent.max === extent.min ? 0 : (values[key] - extent.min) / (extent.max - extent.min);
      }
      result.score = 100 * WEIGHT_KEYS.reduce((sum, key) => sum + weights[key] * normalized[key], 0);
      result.pareto = !feasible.some(other => other !== result && dominates(other, result));
      result.scoreDetails = { objectives: values, normalized, weights: Object.assign({}, weights), extents };
    }
    feasible.sort((left, right) => left.score - right.score
      || left.totalSec - right.totalSec || left.routeId.localeCompare(right.routeId));
    feasible.forEach((result, index) => { result.rank = index + 1; });
    response.results = feasible;
    response.warnings.push('只比较相同目的地及接驳方式。综合成本为 0–100，越低越优；权重由用户设定。');
    response.warnings.push('Pareto 标记表示在时间、步行距离、垂直转换及证据成本上未被其他候选全面超越。');
    response.warnings.push('成本按本次候选集归一化，不宜跨不同目的地或不同候选集合直接比较。');
    return response;
  }

  return Object.freeze({
    VERSION,
    normalizeBundle,
    defaultOptions,
    chainMetrics,
    evaluateRoute,
    recommend,
    parseClock,
    nextDeparture,
    routeLine,
    chainAccessibility
  });
});
