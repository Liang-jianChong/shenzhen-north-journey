/* Research tools consume only the user's in-memory local bundle. */
(function () {
  'use strict';

  const host = document.getElementById('research-workbench');
  if (!host) return;

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const componentNames = [
    ['walkSec', '水平步行', '#307b88'],
    ['verticalSec', '垂直交通', '#749c9b'],
    ['queueSec', '设施排队', '#c69a64'],
    ['processingSec', '检查办理', '#9c8fa8'],
    ['wayfindingSec', '寻路停顿', '#9badaf'],
    ['waitSec', '接驳候车', '#d0b778']
  ];

  let dataset = null;
  let context = {};
  let controls = {};
  let panels = {};
  let tabs = {};
  let recommendation = null;
  let simulation = null;
  let sensitivity = null;
  let selectedRoute = null;
  let simulationRoutes = new Set();
  let activeView = 'recommend';
  let generation = 0;
  let busy = false;
  let statusNode = null;
  let contextNode = null;
  let recommendationOutput = null;
  let simulationOutput = null;
  let auditOutput = null;
  let routeChoiceNode = null;
  let sourceCounts = {};
  let pendingExperiment = null;
  const simulationFields = new Set([
    'iterations', 'seed', 'targetDeparture', 'speedCv', 'timeCv',
    'sampleDistance', 'queueReductionSec', 'wayfindingReductionSec'
  ]);

  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined && text !== null) element.textContent = String(text);
    return element;
  }

  function append(parent, children) {
    children.flat().forEach(child => {
      if (child !== null && child !== undefined) parent.append(child);
    });
    return parent;
  }

  function finite(value) {
    return typeof value === 'number' && Number.isFinite(value);
  }

  function number(value, digits = 0) {
    if (!finite(value)) return '—';
    return value.toLocaleString('zh-CN', {maximumFractionDigits: digits});
  }

  function minutes(value) {
    return finite(value) ? number(value / 60, 1) + ' 分钟' : '未确定';
  }

  function meters(value) {
    return finite(value) ? number(value) + ' m' : '未确定';
  }

  function percent(value) {
    return finite(value) ? number(value * 100, 1) + '%' : '未计算';
  }

  function statusLabel(value) {
    return {
      complete: '可完整计算',
      partial: '资料不完整',
      excluded: '条件不满足',
      unavailable: '所选计划内无后续班次',
      invalid: '输入或结构无效'
    }[value] || '待核查';
  }

  function targetReason(value) {
    return {
      not_specified: '未指定目标班次',
      route_or_plan_missing: '缺少路线或运行图',
      not_scheduled_metro_route: '当前不是采用地铁运行图的路线',
      line_not_verified: '路线与运行图的线路无法对应',
      departure_not_in_selected_plan: '指定发车时刻不在所选运行图中'
    }[value] || '尚未核验目标班次';
  }

  function clock(value) {
    if (!finite(value) || value < 0) return '未确定';
    const total = Math.round(value);
    const hours = Math.floor(total / 3600);
    const mins = Math.floor(total % 3600 / 60);
    const secs = total % 60;
    return [hours, mins, secs].map(part => String(part).padStart(2, '0')).join(':');
  }

  function parseClock(value) {
    if (!String(value).trim()) return null;
    const match = /^(\d{1,3}):([0-5]\d)(?::([0-5]\d))?$/.exec(String(value).trim());
    if (!match) return NaN;
    return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3] || 0);
  }

  function list(value) {
    if (Array.isArray(value)) return value;
    if (value && typeof value === 'object') return Object.values(value);
    return [];
  }

  function routeId(route) {
    return String(route.routeId || route.id || route.route_id || '');
  }

  function routeName(route) {
    return route.name || route.title || route.destination || routeId(route);
  }

  function routeById(id) {
    return list(dataset && dataset.routes).find(route => routeId(route) === String(id));
  }

  function notice(message, kind = 'info') {
    const element = node('p', 'rw-notice rw-notice-' + kind, message);
    if (kind === 'error') element.setAttribute('role', 'alert');
    return element;
  }

  function heading(title, text) {
    return append(node('div', 'rw-section-heading'), [
      node('h3', '', title),
      text ? node('p', '', text) : null
    ]);
  }

  function emptyResult(title, detail) {
    return append(node('div', 'rw-result-empty'), [
      node('strong', '', title),
      node('p', '', detail)
    ]);
  }

  function setStatus(message, error = false) {
    if (!statusNode) return;
    statusNode.textContent = message;
    statusNode.classList.toggle('rw-status-error', error);
  }

  function metric(label, value, detail, tone = '') {
    return append(node('div', 'rw-metric ' + tone), [
      node('span', 'rw-metric-label', label),
      node('strong', '', value),
      node('small', '', detail || '')
    ]);
  }

  function badge(text, kind = '') {
    return node('span', 'rw-badge ' + (kind ? 'rw-badge-' + kind : ''), text);
  }

  function makeButton(text, action, className = '') {
    const button = node('button', className, text);
    button.type = 'button';
    button.addEventListener('click', action);
    return button;
  }

  function field(key, label, value, options = {}) {
    const wrapper = node('label', 'rw-field');
    const title = node('span', 'rw-field-title', label);
    const input = node('input');
    input.id = 'rw-' + key;
    input.name = key;
    input.type = options.type || 'number';
    input.value = value === null || value === undefined ? '' : String(value);
    if (options.min !== undefined) input.min = String(options.min);
    if (options.max !== undefined) input.max = String(options.max);
    if (options.step !== undefined) input.step = String(options.step);
    if (options.placeholder) input.placeholder = options.placeholder;
    if (options.required) input.required = true;
    if (input.type === 'text') input.autocomplete = 'off';
    wrapper.htmlFor = input.id;
    append(wrapper, [title, input]);
    if (options.help) append(wrapper, [node('small', '', options.help)]);
    controls[key] = input;
    input.addEventListener('input', () => {
      if (simulationFields.has(key)) invalidateSimulation('实验参数已修改，请重新运行。');
      else invalidateResults('参数已修改，请重新计算。');
    });
    return wrapper;
  }

  function selectField(key, label, choices, value) {
    const wrapper = node('label', 'rw-field');
    const select = node('select');
    select.id = 'rw-' + key;
    wrapper.htmlFor = select.id;
    choices.forEach(([id, title]) => {
      const option = node('option', '', title);
      option.value = id;
      select.append(option);
    });
    select.value = String(value || choices[0][0]);
    controls[key] = select;
    select.addEventListener('change', () => invalidateResults('参数已修改，请重新计算。'));
    return append(wrapper, [node('span', 'rw-field-title', label), select]);
  }

  function checkbox(key, label, checked, detail) {
    const wrapper = node('label', 'rw-checkbox');
    const input = node('input');
    input.type = 'checkbox';
    input.id = 'rw-' + key;
    input.checked = Boolean(checked);
    const text = node('span');
    text.append(node('strong', '', label));
    if (detail) text.append(node('small', '', detail));
    controls[key] = input;
    input.addEventListener('change', () => {
      if (simulationFields.has(key)) invalidateSimulation('抽样条件已修改，请重新运行。');
      else invalidateResults('筛选条件已修改，请重新计算。');
    });
    return append(wrapper, [input, text]);
  }

  function details(title, content, open = false) {
    const element = node('details', 'rw-details');
    element.open = open;
    return append(element, [node('summary', '', title), content]);
  }

  function table(headers, rows, caption) {
    const scroll = node('div', 'rw-table-scroll');
    scroll.tabIndex = 0;
    scroll.setAttribute('role', 'region');
    scroll.setAttribute('aria-label', caption);
    const element = node('table', 'rw-table');
    element.append(node('caption', 'rw-sr-only', caption));
    const header = node('tr');
    headers.forEach(text => {
      const cell = node('th', '', text);
      cell.scope = 'col';
      header.append(cell);
    });
    element.append(append(node('thead'), [header]));
    const body = node('tbody');
    rows.forEach(cells => {
      const row = node('tr');
      cells.forEach(content => {
        const cell = node('td');
        if (content instanceof Node) cell.append(content);
        else cell.textContent = String(content === undefined || content === null ? '—' : content);
        row.append(cell);
      });
      body.append(row);
    });
    element.append(body);
    scroll.append(element);
    return scroll;
  }

  function messageList(messages, className = '') {
    const container = node('ul', 'rw-message-list ' + className);
    [...new Set(messages.filter(Boolean).map(message =>
      typeof message === 'string' ? message : message.message || message.code || String(message)
    ))].forEach(text => container.append(node('li', '', text)));
    return container;
  }

  function svgElement(tag, attributes = {}) {
    const element = document.createElementNS(SVG_NS, tag);
    Object.entries(attributes).forEach(([key, value]) => element.setAttribute(key, String(value)));
    return element;
  }

  function svgText(svg, text, x, y, attributes = {}) {
    const label = svgElement('text', Object.assign({x, y}, attributes));
    label.textContent = String(text);
    svg.append(label);
    return label;
  }

  function chart(label, height) {
    const svg = svgElement('svg', {
      viewBox: '0 0 600 ' + height,
      role: 'img',
      'aria-label': label,
      class: 'rw-chart'
    });
    const title = svgElement('title');
    title.textContent = label;
    svg.append(title);
    return svg;
  }

  function invalidateResults(message) {
    generation += 1;
    recommendation = null;
    simulation = null;
    sensitivity = null;
    selectedRoute = null;
    if (recommendationOutput) {
      recommendationOutput.replaceChildren(emptyResult('等待更新', message));
    }
    if (simulationOutput) {
      simulationOutput.replaceChildren(emptyResult('等待实验', '使用当前推荐参数运行可重复的情景实验。'));
    }
    if (dataset) setStatus(message);
    updateRouteChoices();
  }

  function invalidateSimulation(message) {
    generation += 1;
    simulation = null;
    sensitivity = null;
    if (simulationOutput) simulationOutput.replaceChildren(emptyResult('等待更新实验', message));
    if (dataset) setStatus(message);
  }

  function clear() {
    generation += 1;
    if (pendingExperiment !== null) window.clearTimeout(pendingExperiment);
    pendingExperiment = null;
    dataset = null;
    context = {};
    controls = {};
    panels = {};
    tabs = {};
    recommendation = null;
    simulation = null;
    sensitivity = null;
    selectedRoute = null;
    simulationRoutes.clear();
    activeView = 'recommend';
    busy = false;
    statusNode = null;
    contextNode = null;
    recommendationOutput = null;
    simulationOutput = null;
    auditOutput = null;
    routeChoiceNode = null;
    sourceCounts = {};
    host.replaceChildren(emptyResult(
      '先加载本机研究包',
      '路线比较、情景实验和数据核查将在加载后启用。数据仅留在本次页面内存中。'
    ));
  }

  function buildTabs(container) {
    const tablist = node('div', 'rw-tabs');
    tablist.setAttribute('role', 'tablist');
    tablist.setAttribute('aria-label', '科研工作台功能');
    const entries = [
      ['recommend', '01', '出行链推荐'],
      ['simulate', '02', '时间与措施实验'],
      ['audit', '03', '数据准备度']
    ];
    entries.forEach(([id, index, label]) => {
      const button = makeButton('', () => activateView(id), 'rw-tab');
      button.id = 'rw-tab-' + id;
      button.setAttribute('role', 'tab');
      button.setAttribute('aria-controls', 'rw-panel-' + id);
      append(button, [node('span', 'rw-tab-index', index), node('span', '', label)]);
      tabs[id] = button;
      tablist.append(button);
      const panel = node('section', 'rw-view');
      panel.id = 'rw-panel-' + id;
      panel.setAttribute('role', 'tabpanel');
      panel.setAttribute('aria-labelledby', button.id);
      panels[id] = panel;
    });
    tablist.addEventListener('keydown', event => {
      const names = entries.map(entry => entry[0]);
      const current = names.indexOf(activeView);
      let next = current;
      if (event.key === 'ArrowRight') next = (current + 1) % names.length;
      else if (event.key === 'ArrowLeft') next = (current + names.length - 1) % names.length;
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = names.length - 1;
      else return;
      event.preventDefault();
      activateView(names[next]);
      tabs[names[next]].focus();
    });
    append(container, [tablist, ...Object.values(panels)]);
  }

  function activateView(name) {
    activeView = name;
    Object.keys(tabs).forEach(id => {
      const active = id === name;
      tabs[id].setAttribute('aria-selected', String(active));
      tabs[id].tabIndex = active ? 0 : -1;
      panels[id].hidden = !active;
    });
    if (name === 'audit') renderAudit();
  }

  function buildRecommendation() {
    const defaults = window.StationResearch.defaultOptions();
    const panel = panels.recommend;
    const form = node('form', 'rw-card');
    form.id = 'rw-recommend-form';
    form.addEventListener('submit', event => {
      event.preventDefault();
      runRecommendation();
    });
    append(form, [heading(
      '比较同一接驳目的地的可选路线',
      '沿用页面上方的站台、下车位置和起始时刻。下方时间参数是工作台独立假设。只比较同一目的地和接驳方式的路线。'
    )]);
    const filters = node('div', 'rw-grid rw-grid-three');
    append(filters, [
      field('maxWalkM', '最大水平步行距离 / m', '', {
        min: 0, max: 10000, step: 10, placeholder: '留空表示不限制'
      }),
      selectField('distanceChoice', '距离情景', [
        ['estimate', '标定估计值'],
        ['lower', '距离下界'],
        ['upper', '距离上界']
      ], defaults.distanceChoice),
      field('speedMps', '步行速度 / m·s⁻¹', defaults.speedMps, {
        min: 0.2, max: 3, step: 0.05, required: true,
        help: '情景假设，不代表个人实测速度'
      })
    ]);
    const checks = node('div', 'rw-check-grid');
    append(checks, [
      checkbox('wheelchair', '严格无障碍核验', defaults.wheelchair,
        '仅保留已有完整无障碍证据的路线；证据未知不会视为可用'),
      checkbox('excludeConflicts', '排除空间冲突', defaults.excludeConflicts,
        '移除已标记的楼层或连接关系冲突')
    ]);
    append(form, [filters, checks]);

    const closureBody = node('div', 'rw-detail-body');
    const exitGroup = node('fieldset', 'rw-fieldset');
    exitGroup.append(node('legend', '', '关闭出站口（情景设置）'));
    const exitChecks = node('div', 'rw-exit-checks');
    ['A1', 'A2', 'B1', 'B2'].forEach(exit => {
      exitChecks.append(checkbox('exit-' + exit, exit, false));
    });
    exitGroup.append(exitChecks);
    append(closureBody, [
      exitGroup,
      field('blockedEdges', '关闭路段编号', '', {
        type: 'text', placeholder: '多个编号用逗号或空格分隔',
        help: '仅使用数据中的精确边编号；不存在的编号会提示核查'
      })
    ]);
    form.append(details('设施关闭与受限通行', closureBody));

    const assumptions = node('div', 'rw-grid rw-grid-three rw-detail-body');
    append(assumptions, [
      field('verticalPerTransitionSec', '每次垂直转换 / 秒', defaults.verticalPerTransitionSec,
        {min: 0, max: 1800, step: 5, required: true}),
      field('queueSec', '设施排队合计 / 秒', defaults.queueSec,
        {min: 0, max: 7200, step: 10, required: true}),
      field('processingSec', '安检及闸机办理合计 / 秒', defaults.processingSec,
        {min: 0, max: 1800, step: 5, required: true}),
      field('wayfindingSec', '寻路停顿合计 / 秒', defaults.wayfindingSec,
        {min: 0, max: 3600, step: 5, required: true}),
      field('roadWaitSec', '地面接驳候车 / 秒', defaults.roadWaitSec,
        {min: 0, max: 7200, step: 30, required: true, help: '仅用于公交、出租车等非地铁路线'}),
      field('bufferSec', '地铁登乘预留 / 秒', defaults.bufferSec,
        {min: 0, max: 900, step: 5, required: true, help: '从到达站台到计划发车之间的预留'})
    ]);
    form.append(details('时间参数：均为可调整的实验假设', assumptions));

    const weights = node('div', 'rw-grid rw-grid-four rw-detail-body');
    [
      ['time', '时间权重'],
      ['distance', '步行距离权重'],
      ['vertical', '换层次数权重'],
      ['uncertainty', '证据不确定性权重']
    ].forEach(([key, title]) => weights.append(field('weight-' + key, title,
      defaults.weights && defaults.weights[key] !== undefined ? defaults.weights[key] : 1,
      {min: 0, max: 100, step: 0.01, required: true}
    )));
    form.append(details('推荐偏好：调整比较权重', weights));
    const actions = node('div', 'rw-actions');
    const run = node('button', 'rw-primary', '计算可选路线');
    run.type = 'submit';
    run.dataset.rwRun = 'true';
    append(actions, [run, makeButton('恢复默认假设', resetAssumptions, 'rw-quiet')]);
    append(form, [actions, notice(
      '这里的距离、排队、速度和服务时间用于情景比较。地铁候车仅使用你主动选定、且线路匹配的运行图；不推断日期适用性或列车是否有余量。'
    )]);
    recommendationOutput = node('div', 'rw-output');
    recommendationOutput.append(emptyResult('尚未计算', '确认假设后，生成同一接驳目的地的路线比较。'));
    append(panel, [form, recommendationOutput]);
  }

  function resetAssumptions() {
    const defaults = window.StationResearch.defaultOptions();
    [
      'speedMps', 'verticalPerTransitionSec', 'queueSec', 'processingSec',
      'wayfindingSec', 'roadWaitSec', 'bufferSec', 'distanceChoice'
    ].forEach(key => { controls[key].value = String(defaults[key]); });
    ['wheelchair', 'excludeConflicts'].forEach(key => {
      controls[key].checked = Boolean(defaults[key]);
    });
    ['time', 'distance', 'vertical', 'uncertainty'].forEach(key => {
      controls['weight-' + key].value = String(defaults.weights[key]);
    });
    ['A1', 'A2', 'B1', 'B2'].forEach(exit => { controls['exit-' + exit].checked = false; });
    controls.blockedEdges.value = '';
    controls.maxWalkM.value = '';
    invalidateResults('已恢复默认假设；请重新计算。');
  }

  function readNumber(key, optional = false) {
    const input = controls[key];
    const value = input ? input.value.trim() : '';
    if (optional && value === '') return null;
    if (value === '' || !finite(Number(value))) throw new Error('请填写有效参数：' + key);
    if (input && !input.checkValidity()) {
      input.reportValidity();
      throw new Error('参数超出允许范围，请检查已标记的输入框。');
    }
    return Number(value);
  }

  function currentOptions() {
    const options = Object.assign({}, window.StationResearch.defaultOptions(), context);
    [
      'speedMps', 'verticalPerTransitionSec', 'queueSec', 'processingSec',
      'wayfindingSec', 'roadWaitSec', 'bufferSec'
    ].forEach(key => { options[key] = readNumber(key); });
    options.maxWalkM = readNumber('maxWalkM', true);
    options.distanceChoice = controls.distanceChoice.value;
    options.wheelchair = controls.wheelchair.checked;
    options.excludeConflicts = controls.excludeConflicts.checked;
    options.blockedExits = ['A1', 'A2', 'B1', 'B2']
      .filter(exit => controls['exit-' + exit].checked)
      .map(exit => 'Exit' + exit);
    options.blockedEdges = controls.blockedEdges.value.split(/[\s,，;；]+/).filter(Boolean);
    const unknownEdges = options.blockedEdges.filter(id =>
      !Object.prototype.hasOwnProperty.call(dataset.edges || {}, id));
    if (unknownEdges.length) {
      throw new Error('关闭路段编号未在当前数据中找到：' + unknownEdges.slice(0, 5).join('、'));
    }
    options.weights = {};
    ['time', 'distance', 'vertical', 'uncertainty'].forEach(key => {
      options.weights[key] = readNumber('weight-' + key);
    });
    if (!options.routeId || !options.platformId) throw new Error('请先在页面上方选择路线和站台。');
    if (!finite(options.startSec)) throw new Error('请先在页面上方填写有效起始时刻。');
    return options;
  }

  function setBusy(value, message) {
    busy = value;
    host.setAttribute('aria-busy', String(value));
    host.querySelectorAll('[data-rw-run]').forEach(button => { button.disabled = value; });
    if (message) setStatus(message);
  }

  function runRecommendation() {
    if (!dataset || busy) return;
    try {
      const options = currentOptions();
      invalidateSimulation('推荐已更新，请重新运行情景实验。');
      recommendation = window.StationResearch.recommend(dataset, options);
      selectedRoute = recommendation.results.length ? recommendation.results[0].routeId : null;
      simulationRoutes = new Set(recommendation.results.slice(0, 3).map(result => String(result.routeId)));
      renderRecommendation();
      updateRouteChoices();
      setStatus('路线比较完成：' + recommendation.results.length + ' 条可计算路线。');
    } catch (error) {
      recommendation = null;
      recommendationOutput.replaceChildren(notice(error.message || '路线计算失败，请核查输入。', 'error'));
      setStatus('路线比较未完成。', true);
    }
  }

  function accessibility(value) {
    if (value === 'verified') return badge('证据已核验', 'good');
    if (value === 'blocked') return badge('存在障碍', 'error');
    return badge('无障碍待核验', 'warning');
  }

  function mapLink(id) {
    const link = node('a', 'rw-map-link', '在三维地图查看 ↗');
    const params = new URLSearchParams();
    params.set('route', String(id));
    params.set('platform', String(context.platformId || ''));
    params.set('z', String(finite(context.alightZ) ? context.alightZ : 0));
    link.href = 'index.html?' + params.toString();
    link.target = '_blank';
    link.rel = 'noopener';
    return link;
  }

  function renderRecommendation() {
    if (!recommendation) return;
    const results = list(recommendation.results);
    const candidates = list(recommendation.candidates);
    const excluded = candidates.filter(candidate => !candidate.feasible);
    const container = node('div');
    const stats = node('div', 'rw-metrics');
    append(stats, [
      metric('同一目的地候选', String(candidates.length), '保持接驳方式与目的地一致'),
      metric('满足条件且可计算', String(results.length), '按当前约束和计划核验'),
      metric('不被全面优于的路线', String(results.filter(result => result.pareto).length), 'Pareto 候选不等于唯一最优'),
      metric('被排除或信息不足', String(excluded.length), '下方保留具体原因')
    ]);
    container.append(stats);
    const warnings = list(recommendation.warnings);
    if (warnings.length) container.append(details('当前比较需留意的事项', messageList(warnings), true));
    if (!results.length) {
      container.append(notice(
        controls.wheelchair.checked
          ? '当前没有能够通过严格无障碍核验的路线。请补充电梯连续可达、设备可用状态和障碍情况证据；不能把未知路线标为无障碍。'
          : '当前条件下没有可比较的完整路线。请查看排除原因，核对目的地、运行图与缺失字段。',
        'warning'
      ));
    } else {
      const rows = results.map(result => {
        const selection = makeButton(result.routeId, () => {
          selectedRoute = result.routeId;
          renderRecommendation();
          const detail = host.querySelector('#rw-selected-route');
          if (detail) detail.focus({preventScroll: true});
        }, selectedRoute === result.routeId ? 'rw-selected-button' : 'rw-route-button');
        selection.setAttribute('aria-pressed', String(selectedRoute === result.routeId));
        const routeCell = append(node('div'), [selection, node('small', '', result.exitId || '出口待核验')]);
        return [
          result.rank || results.indexOf(result) + 1,
          routeCell,
          meters(result.selectedWalkM),
          minutes(result.totalSec),
          minutes(result.components && result.components.waitSec),
          number(result.score, 3),
          result.pareto ? badge('Pareto', 'good') : '—',
          accessibility(result.accessibility)
        ];
      });
      container.append(table(
        ['排序', '路线 / 出口', '水平步行', '全链时间', '接驳候车', '偏好得分', '多目标比较', '无障碍证据'],
        rows, '同目的地路线比较结果'
      ));
      container.append(node('p', 'rw-footnote',
        '偏好得分仅用于当前候选之间的相对比较；数值小者优先。Pareto 表示没有其他路线在所有比较维度上均不差、且至少一项更优。'
      ));
      const selected = results.find(result => result.routeId === selectedRoute) || results[0];
      container.append(renderRouteDetail(selected));
    }
    if (excluded.length) {
      container.append(details('查看 ' + excluded.length + ' 条未入选路线及原因', table(
        ['路线', '状态', '原因'],
        excluded.map(result => [
          result.routeId,
          statusLabel(result.status),
          messageList(list(result.reasons).concat(list(result.warnings)))
        ]), '未入选路线及数据缺口'
      ), !results.length));
    }
    recommendationOutput.replaceChildren(container);
  }

  function renderRouteDetail(result) {
    const card = node('section', 'rw-card rw-detail-card');
    card.id = 'rw-selected-route';
    card.tabIndex = -1;
    const top = node('div', 'rw-result-heading');
    append(top, [heading('路线 ' + result.routeId + ' · 时间分解', result.destination || ''), mapLink(result.routeId)]);
    card.append(top);
    const bars = node('div', 'rw-time-bars');
    const components = result.components || {};
    const positive = componentNames.map(([key]) => components[key]).filter(value => finite(value) && value >= 0);
    const largest = Math.max(1, ...positive);
    componentNames.forEach(([key, label, color]) => {
      const value = components[key];
      const track = node('div', 'rw-bar-track');
      const fill = node('span', 'rw-bar-fill');
      fill.style.width = finite(value) ? Math.min(100, Math.max(0, value / largest * 100)) + '%' : '0%';
      fill.style.backgroundColor = color;
      track.append(fill);
      append(bars, [append(node('div', 'rw-time-row'), [node('span', '', label), track, node('strong', '', minutes(value))])]);
    });
    const summary = node('dl', 'rw-facts');
    const metrics = result.metrics || {};
    [
      ['到达接驳点', clock(result.readySec)],
      ['选用计划发车', finite(result.departureSec) ? clock(result.departureSec) : '不适用 / 未确定'],
      ['水平步行距离范围', meters(metrics.walkLowerM) + ' – ' + meters(metrics.walkUpperM)],
      ['垂直交通转换', finite(metrics.verticalCount) ? number(metrics.verticalCount) + ' 次' : '待核验'],
      ['证据惩罚指标', number(result.evidencePenalty, 3)]
    ].forEach(([label, value]) => append(summary, [node('dt', '', label), node('dd', '', value)]));
    append(card, [append(node('div', 'rw-detail-grid'), [bars, summary])]);
    if (result.scoreDetails) card.append(scoreExplanation(result.scoreDetails));
    if (list(metrics.edgeIds).length) card.append(edgeEvidence(metrics.edgeIds));
    const warnings = list(result.warnings).concat(list(metrics.warnings));
    if (warnings.length) card.append(details('这条路线的假设和证据缺口', messageList(warnings)));
    return card;
  }

  function scoreExplanation(detail) {
    const descriptors = [
      ['time', '全链时间', minutes],
      ['distance', '水平步行', meters],
      ['vertical', '垂直转换次数', value => number(value) + ' 次'],
      ['uncertainty', '证据不确定性', value => number(value, 3)]
    ];
    const body = node('div');
    body.append(table(
      ['比较维度', '本路线数值', '归一化成本', '归一化权重', '得分贡献'],
      descriptors.map(([key, label, format]) => {
        const normalized = detail.normalized && detail.normalized[key];
        const weight = detail.weights && detail.weights[key];
        const contribution = finite(normalized) && finite(weight) ? normalized * weight * 100 : null;
        return [label, format(detail.objectives && detail.objectives[key]),
          number(normalized, 3), percent(weight), number(contribution, 3)];
      }), '路线偏好得分的计算解释'
    ));
    body.append(node('p', 'rw-footnote rw-detail-body',
      '每个维度在本次候选范围内缩放至 0–1，再按归一化权重加权并乘以 100。若该维度所有候选数值相同，贡献记为零。该得分不能跨不同候选集合直接比较。'
    ));
    return details('为什么推荐这条路线：得分构成', body);
  }

  function edgeEvidence(edgeIds) {
    const body = node('div');
    const rows = edgeIds.map(id => {
      const edge = dataset.edges && dataset.edges[id];
      if (!edge) return [id, '资料缺失', '—', '—', '—'];
      const close = makeButton('设为关闭', () => {
        const ids = controls.blockedEdges.value.split(/[\s,，;；]+/).filter(Boolean);
        if (!ids.includes(id)) ids.push(id);
        controls.blockedEdges.value = ids.join(', ');
        invalidateResults('已在情景中关闭路段 ' + id + '；请重新计算。');
        const disclosure = controls.blockedEdges.closest('details');
        if (disclosure) disclosure.open = true;
        controls.blockedEdges.focus();
      }, 'rw-quiet');
      return [
        id,
        {walk: '水平步行', vertical: '垂直交通', semantic: '同点语义连接'}[edge.time_component] || '分类待核验',
        meters(edge.walk_length_m),
        finite(edge.measured_length_m) ? badge('有实测长度', 'good') : badge('模型估计', 'warning'),
        close
      ];
    });
    body.append(table(['路段编号', '时间分类', '原始水平距离', '距离证据', '关闭情景'], rows,
      '所选出行链的路段标定值与关闭设置'));
    body.append(node('p', 'rw-footnote rw-detail-body',
      '这里保留原始路段标定值；所选下车位置对起始步行段的修正在完整出行链中计算。关闭仅影响本次实验假设，不改变实际设施状态。'
    ));
    return details('路段证据与关闭情景', body);
  }

  function buildSimulation() {
    const panel = panels.simulate;
    const form = node('form', 'rw-card');
    form.addEventListener('submit', event => {
      event.preventDefault();
      runSimulation();
    });
    append(form, [heading(
      '固定随机种子，比较时间与服务措施',
      '从当前可计算候选中选取路线。相同随机样本用于措施前后比较，便于重复实验；这里不会拟合个人行为或预测实际客流。'
    )]);
    routeChoiceNode = node('div', 'rw-route-choices');
    form.append(routeChoiceNode);
    const grid = node('div', 'rw-grid rw-grid-three');
    append(grid, [
      field('iterations', '每条路线实验次数', 200, {min: 20, max: 1000, step: 1, required: true}),
      field('seed', '随机种子', 20261017, {min: 0, max: 4294967295, step: 1, required: true}),
      field('targetDeparture', '指定计划发车时刻', '', {
        type: 'text', placeholder: '可选，例如 08:35 或 24:10',
        help: '必须是所选地铁运行图的一班；留空不计算未赶上概率'
      })
    ]);
    form.append(grid);
    const uncertainty = node('div', 'rw-detail-body');
    const uncertaintyGrid = node('div', 'rw-grid');
    append(uncertaintyGrid, [
      field('speedCv', '步行速度变异系数', 0.15, {min: 0, max: 0.5, step: 0.05, required: true}),
      field('timeCv', '服务时间变异系数', 0.25, {
        min: 0, max: 1, step: 0.05, required: true,
        help: '排队、办理、寻路、垂直交通及地面候车的情景波动'
      })
    ]);
    append(uncertainty, [uncertaintyGrid,
      checkbox('sampleDistance', '在距离标定区间内抽样', true,
        '采用以下界、估计值和上界定义的三角分布；这不代表实测误差分布')
    ]);
    form.append(details('不确定性参数', uncertainty));
    const measures = node('div', 'rw-grid rw-detail-body');
    append(measures, [
      field('queueReductionSec', '措施：减少排队 / 秒', 30, {
        min: 0, max: 7200, step: 5, required: true, help: '先减少基础排队假设，再使用相同随机波动'
      }),
      field('wayfindingReductionSec', '措施：减少寻路停顿 / 秒', 15, {
        min: 0, max: 3600, step: 5, required: true, help: '从基础寻路假设中扣减，最低为零'
      })
    ]);
    form.append(details('服务改善措施', measures, true));
    const run = node('button', 'rw-primary', '运行情景实验');
    run.type = 'submit';
    run.dataset.rwRun = 'true';
    append(form, [append(node('div', 'rw-actions'), [run]), notice(
      '“未赶上指定班次概率”只表示到达时刻加登乘预留超过该计划发车时刻，不是拒载率、满载率或真实漏乘率。措施收益是模型情景差异，不是因果结论。'
    )]);
    simulationOutput = node('div', 'rw-output');
    simulationOutput.append(emptyResult('尚未运行实验', '先完成出行链推荐，再选择最多 6 条可计算路线。'));
    append(panel, [form, simulationOutput]);
    updateRouteChoices();
  }

  function updateRouteChoices() {
    if (!routeChoiceNode) return;
    routeChoiceNode.replaceChildren();
    const results = recommendation ? list(recommendation.results) : [];
    if (!results.length) {
      const entry = makeButton('先计算可选路线', () => {
        activateView('recommend');
        runRecommendation();
      }, 'rw-quiet');
      append(routeChoiceNode, [node('p', 'rw-footnote', '尚无可计算候选。沿用推荐页的约束与时间参数。'), entry]);
      return;
    }
    const fieldset = node('fieldset', 'rw-fieldset');
    fieldset.append(node('legend', '', '实验路线（最多 6 条）'));
    const choices = node('div', 'rw-route-options');
    results.forEach(result => {
      const label = node('label', 'rw-route-option');
      const input = node('input');
      input.type = 'checkbox';
      input.checked = simulationRoutes.has(String(result.routeId));
      input.addEventListener('change', () => {
        const id = String(result.routeId);
        if (input.checked && simulationRoutes.size >= 6) {
          input.checked = false;
          setStatus('最多同时比较 6 条路线。', true);
          return;
        }
        if (input.checked) simulationRoutes.add(id);
        else simulationRoutes.delete(id);
        invalidateSimulation('路线选择已更新，请重新运行情景实验。');
      });
      append(label, [input, node('span', '', result.routeId + ' · ' + minutes(result.totalSec))]);
      choices.append(label);
    });
    fieldset.append(choices);
    routeChoiceNode.append(fieldset);
  }

  function simulationSettings() {
    const target = parseClock(controls.targetDeparture.value);
    if (Number.isNaN(target)) throw new Error('指定发车时刻请填写 HH:MM 或 HH:MM:SS，可使用 24:10 等运营日时间。');
    const iterations = readNumber('iterations');
    const seed = readNumber('seed');
    if (!Number.isInteger(iterations) || !Number.isInteger(seed)) throw new Error('实验次数和随机种子必须是整数。');
    if (!simulationRoutes.size) throw new Error('请至少选择一条可计算路线。');
    return {
      routeIds: [...simulationRoutes],
      iterations,
      seed,
      speedCv: readNumber('speedCv'),
      timeCv: readNumber('timeCv'),
      sampleDistance: controls.sampleDistance.checked,
      targetDepartureSec: target,
      measure: {
        queueReductionSec: readNumber('queueReductionSec'),
        wayfindingReductionSec: readNumber('wayfindingReductionSec')
      }
    };
  }

  function runSimulation() {
    if (!dataset || busy) return;
    try {
      const options = currentOptions();
      if (!recommendation) {
        runRecommendation();
        if (!recommendation || !recommendation.results.length) {
          throw new Error('当前没有可计算路线，请先检查推荐页中的数据缺口。');
        }
      }
      const settings = simulationSettings();
      const currentGeneration = generation;
      setBusy(true, '正在计算情景样本与措施对照……');
      pendingExperiment = window.setTimeout(() => {
        pendingExperiment = null;
        if (!dataset || currentGeneration !== generation) {
          setBusy(false);
          return;
        }
        try {
          simulation = window.StationSimulation.runBatch(dataset, options, settings);
          const sensitivityOptions = Object.assign({}, options, {
            routeId: simulation.paired && simulation.paired.routeId || options.routeId
          });
          sensitivity = window.StationSimulation.sensitivity(dataset, sensitivityOptions, settings);
          renderSimulation(settings);
          setStatus('实验完成。随机种子 ' + settings.seed + '，每条路线 ' + settings.iterations + ' 次。');
        } catch (error) {
          simulation = null;
          sensitivity = null;
          simulationOutput.replaceChildren(notice(error.message || '实验失败，请核查参数和运行图。', 'error'));
          setStatus('情景实验未完成。', true);
        } finally {
          setBusy(false);
        }
      }, 0);
    } catch (error) {
      simulationOutput.replaceChildren(notice(error.message || '实验参数无效。', 'error'));
      setStatus('请检查实验参数。', true);
    }
  }

  function renderSimulation(settings) {
    const container = node('div');
    const routes = list(simulation.routes);
    const pair = simulation.paired || {};
    const header = node('div', 'rw-experiment-summary');
    append(header, [
      badge('种子 ' + simulation.seed),
      badge('每条 ' + simulation.iterations + ' 次'),
      badge('选中 ' + routes.length + ' 条路线'),
      settings.targetDepartureSec === null
        ? badge('未指定目标班次')
        : badge('目标班次 ' + clock(settings.targetDepartureSec))
    ]);
    container.append(header);
    if (list(simulation.warnings).length) {
      container.append(details('实验参数与计算提示', messageList(simulation.warnings), true));
    }
    const rows = routes.map(result => [
      result.routeId,
      number(result.validTrials) + ' / ' + number(result.trials),
      minutes(result.meanSec),
      minutes(result.medianSec),
      minutes(result.p90Sec),
      append(node('div'), [
        node('span', '', percent(result.targetMissRate)),
        node('small', '', finite(result.targetEvidenceTrials) && settings.targetDepartureSec !== null
          ? '基于 ' + number(result.targetEvidenceTrials) + ' 次到达时刻'
          : settings.targetDepartureSec !== null ? '目标班次未核验' : '未指定目标')
      ]),
      number(result.unavailableTrials || 0)
    ]);
    container.append(table(
      ['路线', '有效 / 总次数', '平均全链时间', '中位数', 'P90', '未赶上目标班次', '计划内不可计算'],
      rows, '随机情景实验结果'
    ));
    container.append(node('p', 'rw-footnote',
      'P90 表示 90% 的有效时间样本不超过该值。无后续计划班次等不可计算样本单列，不作为零时间统计；目标班次概率使用可确定到达时刻的样本，可能与时间均值的分母不同。'
    ));
    const diagnostics = routes.filter(result => result.unavailableTrials > 0 ||
      (settings.targetDepartureSec !== null && !result.targetValidated));
    if (diagnostics.length) {
      container.append(details('不可计算样本与目标班次核查', table(
        ['路线', '计划末班之后', '条件排除', '无效输入', '目标班次状态'],
        diagnostics.map(result => [
          result.routeId,
          number(result.censoredTrials || 0),
          number(result.excludedTrials || 0),
          number(result.invalidTrials || 0),
          node('span', 'rw-wrap', result.targetValidated ? '目标班次已在所选计划中核验' : targetReason(result.targetReason))
        ]), '实验样本可用性核查'
      ), true));
    }
    const first = routes[0];
    if (first) {
      const distribution = node('section', 'rw-card');
      append(distribution, [
        heading('时间分布 · ' + first.routeId, '仅展示第一条实验路线的有效全链时间样本。'),
        histogram(first.samples)
      ]);
      container.append(distribution);
    }
    const pairedCard = node('section', 'rw-card');
    append(pairedCard, [heading('同样本措施前后比较' + (pair.routeId ? ' · ' + pair.routeId : ''),
      '优先使用页面所选主路线；若主路线未勾选，则使用第一条实验路线。同一随机场景同时计算基线与措施。')]);
    const stats = node('div', 'rw-metrics');
    append(stats, [
      metric('基线平均时间', minutes(pair.baselineMeanSec), '仅对可配对样本统计'),
      metric('措施后平均时间', minutes(pair.measureMeanSec), '扣减排队和寻路停顿'),
      metric('平均节约', minutes(pair.meanSavingSec), '可能包含赶上更早班次的变化', 'rw-metric-accent'),
      metric('可配对样本', number(pair.pairedTrials), '计划内不可计算样本不计入均值')
    ]);
    pairedCard.append(stats);
    const notes = [];
    if (finite(pair.p90SavingSec)) notes.push('节约时间 P90：' + minutes(pair.p90SavingSec));
    if (finite(pair.sameDepartureRate)) notes.push('配对样本选中同一发车班次：' + percent(pair.sameDepartureRate));
    if (finite(pair.baselineOnlyTrials)) notes.push('仅基线可计算：' + number(pair.baselineOnlyTrials) + ' 次');
    if (finite(pair.measureOnlyTrials)) notes.push('仅措施后可计算：' + number(pair.measureOnlyTrials) + ' 次');
    if (notes.length) pairedCard.append(node('p', 'rw-footnote', notes.join('；')));
    container.append(pairedCard);
    if (list(sensitivity).length) container.append(renderSensitivity());
    if (list(simulation.assumptions).length) {
      container.append(details('本次实验的分布、抽样与解释边界', messageList(simulation.assumptions), true));
    }
    simulationOutput.replaceChildren(container);
  }

  function sampleTime(sample) {
    if (finite(sample)) return sample;
    if (!sample || typeof sample !== 'object') return null;
    if (finite(sample.totalSec)) return sample.totalSec;
    if (finite(sample.baselineSec)) return sample.baselineSec;
    return null;
  }

  function histogram(samples) {
    const values = list(samples).map(sampleTime).filter(value => finite(value) && value >= 0).map(value => value / 60);
    if (!values.length) return notice('没有可用于绘制分布的有效时间样本。', 'warning');
    const minimum = Math.min(...values);
    const maximum = Math.max(...values);
    const span = Math.max(0.5, maximum - minimum);
    const low = maximum === minimum ? Math.max(0, minimum - span / 2) : minimum;
    const high = Math.max(low + span, maximum);
    const bins = Array.from({length: Math.min(16, Math.max(6, Math.ceil(Math.sqrt(values.length))))}, () => 0);
    values.forEach(value => {
      const index = Math.min(bins.length - 1, Math.max(0, Math.floor((value - low) / (high - low) * bins.length)));
      bins[index] += 1;
    });
    const maxCount = Math.max(...bins, 1);
    const svg = chart('全链时间直方图：' + values.length + ' 个有效样本，范围 ' + number(minimum, 1) + ' 至 ' + number(maximum, 1) + ' 分钟', 230);
    const left = 42;
    const top = 14;
    const width = 535;
    const height = 165;
    for (let tick = 0; tick <= 4; tick += 1) {
      const y = top + height - tick / 4 * height;
      svg.append(svgElement('line', {x1: left, x2: left + width, y1: y, y2: y, stroke: '#e4ecec'}));
      svgText(svg, Math.round(tick / 4 * maxCount), left - 9, y + 4, {'text-anchor': 'end'});
    }
    bins.forEach((count, index) => {
      const barWidth = width / bins.length;
      const barHeight = count / maxCount * height;
      const rect = svgElement('rect', {
        x: left + index * barWidth + 2,
        y: top + height - barHeight,
        width: Math.max(1, barWidth - 4),
        height: barHeight,
        fill: '#367e88', rx: 3
      });
      const title = svgElement('title');
      title.textContent = number(low + index / bins.length * (high - low), 1) + '–' +
        number(low + (index + 1) / bins.length * (high - low), 1) + ' 分钟：' + count + ' 次';
      rect.append(title);
      svg.append(rect);
    });
    for (let tick = 0; tick <= 4; tick += 1) {
      svgText(svg, number(low + tick / 4 * (high - low), 1), left + tick / 4 * width,
        top + height + 21, {'text-anchor': 'middle'});
    }
    svgText(svg, '全链时间 / 分钟', left + width / 2, 224, {'text-anchor': 'middle'});
    return svg;
  }

  function renderSensitivity() {
    const card = node('section', 'rw-card');
    const pairRouteId = simulation && simulation.paired && simulation.paired.routeId;
    append(card, [heading('单参数敏感性' + (pairRouteId ? ' · ' + pairRouteId : ''),
      '每次只改变一个参数，其他条件保持固定；这张表是确定性情景差异，不是统计置信区间。')]);
    const rows = list(sensitivity);
    const maxSpan = Math.max(1, ...rows.map(row => finite(row.spanSec) ? Math.abs(row.spanSec) : 0));
    card.append(table(
      ['参数', '较低输入', '较高输入', '低值情景时间', '高值情景时间', '时间差范围'],
      rows.map(row => {
        const track = node('div', 'rw-sensitivity-cell');
        if (finite(row.spanSec)) {
          const bar = node('span', 'rw-sensitivity-bar');
          bar.style.width = Math.max(2, Math.abs(row.spanSec) / maxSpan * 100) + '%';
          append(track, [node('strong', '', minutes(Math.abs(row.spanSec))), bar]);
        } else track.append(node('span', '', '信息不足'));
        return [
          row.label || row.parameter,
          number(row.lowValue, 2) + (row.unit ? ' ' + row.unit : ''),
          number(row.highValue, 2) + (row.unit ? ' ' + row.unit : ''),
          minutes(row.lowTotalSec),
          minutes(row.highTotalSec),
          track
        ];
      }), '单参数敏感性分析'
    ));
    return card;
  }

  function buildAudit() {
    auditOutput = node('div', 'rw-audit-output');
    panels.audit.append(auditOutput);
    renderAudit();
  }

  function countEntries(value) {
    if (Array.isArray(value)) return value.length;
    if (value && typeof value === 'object') return Object.keys(value).length;
    return 0;
  }

  function auditRows() {
    const issues = list(dataset && dataset.audit && dataset.audit.issues);
    const chosen = controls.auditSeverity ? controls.auditSeverity.value : 'all';
    return issues.filter(issue => chosen === 'all' || String(issue.severity) === chosen);
  }

  function auditStatus(kind, summary) {
    return append(node('div', 'rw-readiness-item'), [badge(kind === 'good' ? '可用' : '需核验', kind), node('span', '', summary)]);
  }

  function renderAudit() {
    if (!auditOutput || !dataset) return;
    const audit = dataset.audit || {};
    const issues = list(audit.issues);
    const output = node('div');
    const overview = node('section', 'rw-card');
    append(overview, [heading('先确认数据能够支持哪些结论',
      '数据准备度只报告当前研究包的结构、证据缺口和适用范围，不把缺失资料自动补成真实值。')]);
    const stats = node('div', 'rw-metrics');
    append(stats, [
      metric('空间路线', number(countEntries(dataset.routes)), '公开空间框架'),
      metric('国铁站台', number(countEntries(dataset.platforms)), '用于完整下车出行链'),
      metric('地铁运行图', number(countEntries(dataset.plans)), '仅从本机研究包读取'),
      metric('核查事项', number(issues.length), '包括结构、证据和适用性')
    ]);
    overview.append(stats);
    const readiness = node('div', 'rw-readiness');
    append(readiness, [
      auditStatus(countEntries(dataset.routes) && countEntries(dataset.edges) &&
        !(audit.counts && audit.counts.invalidChains) ? 'good' : 'warning',
        audit.counts && audit.counts.invalidChains
          ? '距离与拓扑：部分出行链存在结构问题，需先查看下方核查项目，再选择可计算路线。'
          : '距离与拓扑：空间框架可用于路线比较；标定区间仍需实测距离和楼层连接证据校正。'),
      auditStatus('warning', '无障碍：设备存在不等于连续无障碍通行，需逐段核验电梯、出入口和设备状态。'),
      auditStatus('warning', '计划适用性：线路匹配只是必要条件，运营日期、运行方向与版本仍需人工确认。'),
      auditStatus('warning', '服务时间：排队、办理、寻路和个体速度目前是情景输入，不能替代视频标注或实测样本。')
    ]);
    overview.append(readiness);
    output.append(overview);
    const scope = renderCurrentScope();
    if (scope) output.append(scope);
    if (audit.counts && Object.keys(audit.counts).length) {
      const translated = {
        routes: '路线', platforms: '站台', chains: '全出行链', edges: '空间路段',
        plans: '地铁运行图', sources: '数据来源', facilities: '设施',
        provenance: '数据来源记录', afcDays: 'AFC 日期', hsrDays: '高铁客流日期',
        videos: '视频索引', videoRecords: '视频索引记录', metroPlans: '地铁运行图',
        events: '计划时刻记录', invalidChains: '存在结构问题的出行链',
        conflictChains: '存在冲突的出行链', measuredEdges: '已有实测长度的路段',
        verifiedAccessibleChains: '完整无障碍证据已核验的出行链',
        missingPlatformRoutePairs: '缺失的站台与路线组合', errors: '错误实例',
        warnings: '提醒实例', sourceFiles: '来源文件记录', sourceSheets: '来源工作表记录'
      };
      const rows = Object.entries(Object.assign({}, audit.counts, sourceCounts))
        .filter(([, value]) => finite(value) || typeof value === 'string')
        .map(([key, value]) => [translated[key] || key, finite(value) ? number(value) : value]);
      output.append(details('研究包的结构与来源计数', table(['类别', '数量'], rows, '研究包数据计数')));
    }
    const issuesCard = node('section', 'rw-card');
    const top = node('div', 'rw-result-heading');
    const previous = controls.auditSeverity ? controls.auditSeverity.value : 'all';
    const filter = node('label', 'rw-audit-filter');
    filter.append(node('span', '', '显示级别'));
    const select = node('select');
    select.setAttribute('aria-label', '核查事项级别');
    const severities = [...new Set(issues.map(issue => String(issue.severity)))];
    [['all', '全部事项'], ...severities.map(severity => [severity, {
      error: '错误', warning: '提醒', info: '说明'
    }[severity] || severity])].forEach(([value, title]) => {
      const option = node('option', '', title);
      option.value = value;
      select.append(option);
    });
    select.value = severities.includes(previous) ? previous : 'all';
    controls.auditSeverity = select;
    select.addEventListener('change', renderAudit);
    filter.append(select);
    append(top, [heading('证据与质量核查', ''), filter]);
    issuesCard.append(top);
    const visible = auditRows();
    if (visible.length) {
      issuesCard.append(table(['级别', '项目', '涉及条目', '需要处理的事项'], visible.map(issue => [
        badge({error: '错误', warning: '提醒', info: '说明'}[issue.severity] || issue.severity,
          issue.severity === 'error' ? 'error' : issue.severity === 'warning' ? 'warning' : ''),
        issue.code || '—',
        finite(issue.count) ? number(issue.count) : '—',
        append(node('div', 'rw-wrap'), [
          node('span', '', issue.message || '未提供说明'),
          list(issue.examples).length ? node('small', '', '示例：' + issue.examples.join('、')) : null
        ])
      ]), '当前数据核查事项'));
    } else {
      issuesCard.append(notice(issues.length ? '该级别下没有核查事项。' : '未检出结构问题；这不代表空间和服务参数已经实测验证。'));
    }
    output.append(issuesCard);
    auditOutput.replaceChildren(output);
  }

  function renderCurrentScope() {
    if (!context.routeId) return null;
    const card = node('section', 'rw-card');
    append(card, [heading('当前实验范围', '沿用页面上方的路线、日期与运行图选择。')]);
    const summary = node('dl', 'rw-facts rw-facts-wide');
    const selected = routeById(context.routeId);
    const plans = list(dataset.plans);
    const plan = plans.find(item => String(item.id || item.planId) === String(context.metroPlanId));
    [
      ['当前路线', context.routeId + (selected ? ' · ' + routeName(selected) : '')],
      ['国铁站台', context.platformId || '未选择'],
      ['起始时刻', clock(context.startSec)],
      ['实验日期', context.date || '未提供'],
      ['选用运行图', plan ? [plan.line ? plan.line + ' 号线' : '', plan.version, plan.dayType, plan.direction].filter(Boolean).join(' · ') : '未选择 / 不适用'],
      ['日期适用性', '不自动认定，需与原始运行图和实际运营日期核对']
    ].forEach(([label, value]) => append(summary, [node('dt', '', label), node('dd', '', value)]));
    card.append(summary);
    return card;
  }

  function updateContextLabel() {
    if (!contextNode || !dataset) return;
    const route = routeById(context.routeId);
    const destination = route ? route.destination || routeName(route) : '以页面所选路线为准';
    contextNode.replaceChildren();
    append(contextNode, [
      node('span', '', '当前范围'),
      node('strong', '', (context.routeId || '未选择路线') + ' · ' + (context.platformId || '未选择站台')),
      node('small', '', String(destination) + ' · 起始 ' + clock(context.startSec))
    ]);
  }

  function mount() {
    controls = {};
    panels = {};
    tabs = {};
    const wrapper = node('div', 'rw-workbench');
    const header = node('header', 'rw-header');
    const introduction = node('div');
    append(introduction, [
      node('p', 'rw-eyebrow', 'RESEARCH WORKBENCH'),
      node('h2', '', '枢纽出行链研究工作台'),
      node('p', 'rw-subtitle', '比较可达路线 · 检验时间假设 · 追踪数据缺口')
    ]);
    contextNode = node('div', 'rw-context');
    append(header, [introduction, contextNode]);
    wrapper.append(header);
    statusNode = node('p', 'rw-status', '本机研究包已载入。调整参数后开始计算。');
    statusNode.setAttribute('role', 'status');
    statusNode.setAttribute('aria-live', 'polite');
    wrapper.append(statusNode);
    buildTabs(wrapper);
    buildRecommendation();
    buildSimulation();
    buildAudit();
    wrapper.append(node('p', 'rw-privacy-note',
      '本机数据仅在本次页面内存中计算；刷新、清空或离开页面后清除。工作台不会上传数据，也不提供研究数据下载。'
    ));
    host.replaceChildren(wrapper);
    updateContextLabel();
    activateView(activeView);
  }

  window.addEventListener('station:bundle-loaded', event => {
    clear();
    if (!window.StationResearch || !window.StationSimulation) {
      host.replaceChildren(notice('研究模块未完整加载，请刷新页面后重试。', 'error'));
      return;
    }
    try {
      dataset = window.StationResearch.normalizeBundle(event.detail && event.detail.bundle);
      const service = event.detail && event.detail.bundle && event.detail.bundle.serviceData || {};
      const sources = list(service.provenance);
      sourceCounts = {
        sourceFiles: sources.length,
        sourceSheets: sources.reduce((sum, source) => sum + list(source.sheetRanges).length, 0),
        afcDays: countEntries(service.afc && service.afc.days),
        hsrDays: countEntries(service.hsr && service.hsr.days),
        videoRecords: countEntries(service.videos && service.videos.records)
      };
      mount();
    } catch (error) {
      clear();
      host.replaceChildren(notice(error.message || '研究包无法用于工作台，请检查数据格式。', 'error'));
    }
  });

  window.addEventListener('station:context-changed', event => {
    if (!dataset) return;
    const next = event.detail && typeof event.detail === 'object' ? event.detail : {};
    const keys = ['routeId', 'platformId', 'alightZ', 'startSec', 'date', 'metroPlanId'];
    const changed = keys.some(key => context[key] !== next[key]);
    context = {};
    keys.forEach(key => { context[key] = next[key]; });
    updateContextLabel();
    if (changed) {
      invalidateResults('实验范围已更新，请重新计算。');
      if (activeView === 'audit') renderAudit();
    }
  });

  window.addEventListener('station:bundle-cleared', clear);
  window.addEventListener('pagehide', clear);
  clear();
})();
